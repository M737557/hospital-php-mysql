<?php
// ==================== HOSPITAL PATIENT MANAGEMENT SYSTEM ====================
// CONFIGURATION FILE - Version 2.1 (Марла гына)
// ============================================================================

// ==================== HOSPITAL INFORMATION ====================
define('HOSPITAL_NAME', 'ОЛАН ТӰҤ БОЛЬНИЦЕ');
define('HOSPITAL_ADDRESS', '123 Medical Center Blvd, Тазалык ола');
define('HOSPITAL_PHONE', '+1 (555) 123-4567');
define('HOSPITAL_WEBSITE', 'www.citygeneral.org');
define('HOSPITAL_LOGO', 'logo.png');

// ==================== APPLICATION SETTINGS ====================
define('APP_NAME', 'Черле-влакым виктарыме система');
define('APP_VERSION', '2.1.0');
define('DATE_FORMAT', 'Y-m-d H:i:s');
define('DATE_SHORT', 'Y-m-d');
define('DATE_DISPLAY', 'M d, Y H:i');
define('TIME_FORMAT', 'H:i:s');
define('LOG_DATE_FORMAT', 'Y-m-d H:i:s');

// Time zone for PHP AND the MySQL session (db.php sets the same offset on every connection).
// The MySQL event scheduler uses the server's own time zone, so set that to the same zone:
//   my.cnf: default-time-zone = 'Europe/Amsterdam'   (needs the tz tables: mysql_tzinfo_to_sql)
define('APP_TIMEZONE', 'Europe/Amsterdam');
date_default_timezone_set(APP_TIMEZONE);

// ==================== GENDER CONFIGURATION ====================
// Configure gender options for the system
// Format: 'code' => 'Display Name'
$genders = [
    'male' => 'Пӧръеҥ',
    'female' => 'Ӱдырамаш',
    'transgender_mtf' => 'Transgender (MTF)',
    'transgender_ftm' => 'Transgender (FTM)',
    'non_binary' => 'Бинарный огыл',
    'genderqueer' => 'Genderqueer',
    'intersex' => 'Intersex',
    'other' => 'Вес',
    'prefer_not_to_say' => 'Ойлынем огыл'
];

// Set which gender options are enabled by default
define('DEFAULT_GENDER', 'prefer_not_to_say');

// Gender display settings
define('GENDER_REQUIRED', true);                    // Make gender selection required
define('GENDER_SHOW_IN_PATIENT_LIST', true);        // Show gender in patient lists
define('GENDER_SHOW_IN_STATISTICS', true);          // Include gender in statistics

// Additional patient demographics (optional)
define('COLLECT_ETHNICITY', false);                  // Enable ethnicity collection
define('COLLECT_OCCUPATION', false);                 // Enable occupation collection
define('COLLECT_MARITAL_STATUS', false);              // Enable marital status collection

// ==================== MYSQL DATABASE ====================
// All application data (patients, de-attached patients, rooms, users, telephones,
// medications, statistics) is stored in MySQL. Create the tables with sql/schema.sql,
// or run `php migrate.php` once to create them AND import the old data/*.json files.
define('DB_HOST', getenv('HOSPITAL_DB_HOST') ?: '127.0.0.1');
define('DB_PORT', (int)(getenv('HOSPITAL_DB_PORT') ?: 3306));
define('DB_NAME', getenv('HOSPITAL_DB_NAME') ?: 'hospital');
define('DB_USER', getenv('HOSPITAL_DB_USER') ?: 'root');
define('DB_PASS', getenv('HOSPITAL_DB_PASS') ?: '');   // set a real password (or the env var)
define('DB_CHARSET', 'utf8mb4');

// ==================== FILE PATHS ====================
// The *_FILE constants below are kept as identifiers: index.php still passes them to
// readJSONFile()/writeJSONFile(), which db.php maps to the matching MySQL table.
// Only the activity log, rate limit file, photos and PDFs are still real files.
define('DATA_DIR', __DIR__ . '/data/');
define('PATIENTS_FILE', DATA_DIR . 'patients.json');
define('ROOMS_FILE', DATA_DIR . 'rooms.json');
define('USERS_FILE', DATA_DIR . 'users.json');
define('TELEPHONES_FILE', DATA_DIR . 'telephones.json');
define('MEDICATIONS_FILE', DATA_DIR . 'medications.json');
define('STATISTICS_FILE', DATA_DIR . 'statistics.json');
define('ACTIVITY_LOG', DATA_DIR . 'activity.log');
define('RATE_LIMIT_FILE', DATA_DIR . 'rate_limit.json');
define('LAST_DETACH_FILE', DATA_DIR . 'last_detach.txt');
define('DISCHARGED_DIR', DATA_DIR . 'discharged/');
define('PHOTO_DIR', DATA_DIR . 'patient_photos/');

// ==================== CREATE DATA DIRECTORY ====================
if (!file_exists(DATA_DIR)) {
    mkdir(DATA_DIR, 0755, true);
}

// Default rooms: inserted into the MySQL table `rooms` when it is empty (first start)
function defaultRooms() {
    return [
        ['id' => 1, 'num' => '101', 'dept' => 'emergency', 'beds' => 4, 'occ' => 0],
        ['id' => 2, 'num' => '102', 'dept' => 'emergency', 'beds' => 4, 'occ' => 0],
        ['id' => 3, 'num' => '201', 'dept' => 'cardiology', 'beds' => 3, 'occ' => 0],
        ['id' => 4, 'num' => '202', 'dept' => 'cardiology', 'beds' => 3, 'occ' => 0],
        ['id' => 5, 'num' => '301', 'dept' => 'pediatrics', 'beds' => 4, 'occ' => 0],
        ['id' => 6, 'num' => '302', 'dept' => 'pediatrics', 'beds' => 4, 'occ' => 0],
        ['id' => 7, 'num' => '401', 'dept' => 'icu', 'beds' => 2, 'occ' => 0],
        ['id' => 8, 'num' => '402', 'dept' => 'icu', 'beds' => 2, 'occ' => 0],
        ['id' => 9, 'num' => '501', 'dept' => 'surgery', 'beds' => 3, 'occ' => 0],
        ['id' => 10, 'num' => '502', 'dept' => 'surgery', 'beds' => 3, 'occ' => 0],
    ];
}

// Default users: inserted into the MySQL table `users` when it is empty (first start)
function defaultUsers() {
    return [
        [
            'user' => 'admin',
            'pass' => password_hash('admin123', PASSWORD_DEFAULT, ['cost' => 12]),
            'role' => 'admin',
            'mfa' => 0,
            'secret' => '',
            'name' => 'Системын администраторжо',
            'email' => 'admin@hospital.org',
            'created' => date('Y-m-d H:i:s'),
            'last_login' => null,
            'active' => 1
        ],
        [
            'user' => 'doctor',
            'pass' => password_hash('doctor123', PASSWORD_DEFAULT, ['cost' => 12]),
            'role' => 'doctor',
            'mfa' => 0,
            'secret' => '',
            'name' => 'John Smith, MD',
            'email' => 'doctor@hospital.org',
            'created' => date('Y-m-d H:i:s'),
            'last_login' => null,
            'active' => 1
        ],
        [
            'user' => 'nurse',
            'pass' => password_hash('nurse123', PASSWORD_DEFAULT, ['cost' => 12]),
            'role' => 'nurse',
            'mfa' => 0,
            'secret' => '',
            'name' => 'Sarah Johnson, RN',
            'email' => 'nurse@hospital.org',
            'created' => date('Y-m-d H:i:s'),
            'last_login' => null,
            'active' => 1
        ],
        [
            'user' => 'reception',
            'pass' => password_hash('reception123', PASSWORD_DEFAULT, ['cost' => 12]),
            'role' => 'reception',
            'mfa' => 0,
            'secret' => '',
            'name' => 'Maria Garcia',
            'email' => 'reception@hospital.org',
            'created' => date('Y-m-d H:i:s'),
            'last_login' => null,
            'active' => 1
        ]
    ];
}

// ==================== ENCRYPTION SETTINGS ====================
// Patient records (tables `patients` and `detached_patients`) are ALWAYS stored ROT47-encoded
// in MySQL (column data_rot47). These flags are kept for older code paths.
define('ENCRYPT_PATIENTS', true);
define('ENCRYPT_ARCHIVES', true);

// ==================== AUTO ARCHIVE SETTINGS ====================
define('AUTO_ARCHIVE_ENABLED', true);
// Weekly de-attach: every DETACHMENT_WEEKDAY at DETACHMENT_HOUR:00 (0 = Sunday ... 6 = Saturday).
// All discharged patients are moved from the MySQL table `patients` to `detached_patients`.
// The MySQL event `ev_weekly_detach` does this on Sunday 00:00 (needs event_scheduler=ON).
// As a safety net, index.php runs the same procedure on the first page load after that
// moment when the event did not run. If you change these values, also change the event's
// schedule in sql/schema.sql.
define('DETACHMENT_WEEKDAY', 0);
define('DETACHMENT_HOUR', 0);
// Delete the patient photos of archived patients in the same weekly run
define('PHOTO_DELETE_ON_ARCHIVE', true);

// ==================== PHOTO SETTINGS ====================
define('MAX_PHOTO_SIZE', 5 * 1024 * 1024);
define('PHOTO_RETENTION_DAYS', 365);
define('PHOTO_CREATE_THUMBNAIL', true);
define('PHOTO_THUMB_SIZE', 150);
define('ALLOWED_PHOTO_TYPES', ['image/png', 'image/jpeg', 'image/webp']);  // non-PNG is converted to PNG on upload

// ==================== SECURITY SETTINGS ====================
define('SESSION_TIMEOUT', 3600);
define('SESSION_REGENERATE', 1800);
define('CSRF_TOKEN_LENGTH', 32);
define('BCRYPT_COST', 12);
define('PASSWORD_MIN_LENGTH', 8);
define('PASSWORD_REQUIRE_UPPER', true);
define('PASSWORD_REQUIRE_LOWER', true);
define('PASSWORD_REQUIRE_NUMBER', true);
define('PASSWORD_REQUIRE_SPECIAL', true);
define('RATE_LIMIT_ATTEMPTS', 5);
define('RATE_LIMIT_WINDOW', 900);
define('MFA_ISSUER', 'CityGeneral');
define('MFA_ENFORCE', false);
// Soft-token login: when true, the login page asks ONLY for the 6-digit authenticator
// (TOTP) code. No username or password. The code is matched against every active user's
// secret in the MySQL users table. Set to false to restore username + password login.
define('SOFTTOKEN_ONLY', true);

// ==================== LOGGING SETTINGS ====================
define('LOG_MAX_SIZE', 10 * 1024 * 1024);
define('LOG_RETENTION_DAYS', 30);

// ==================== PAGINATION SETTINGS ====================
define('MAX_PATIENTS_PER_PAGE', 20);
define('MAX_PHOTOS_PER_PAGE', 50);

// ==================== DEPARTMENT DEFINITIONS ====================
$depts = [
    'emergency' => 'Писе полыш отделений',
    'cardiology' => 'Кардиологий',
    'neurology' => 'Неврологий',
    'pediatrics' => 'Педиатрий',
    'oncology' => 'Онкологий',
    'orthopedics' => 'Ортопедий',
    'surgery' => 'Тӱҥ хирургий',
    'icu' => 'Интенсив терапий отделений',
    'nicu' => 'У шочшо йоча-влак ICU',
    'radiology' => 'Рентгенологий',
    'psychiatry' => 'Психиатрий',
    'obgyn' => 'Акушерство & гинекологий',
    'nephrology' => 'Нефрологий',
    'pulmonology' => 'Пульмонологий',
    'gastroenterology' => 'Гастроэнтерологий',
    'endocrinology' => 'Эндокринологий',
    'hematology' => 'Гематологий',
    'infectious' => 'Вончышо черле-влак',
    'rheumatology' => 'Ревматологий',
    'dermatology' => 'Дерматологий',
    'ophthalmology' => 'Офтальмологий',
    'ent' => 'Пылыш, нер & логар',
    'urology' => 'Урологий',
    'general' => 'Тӱҥ медицине',
    'rehab' => 'Реабилитаций',
    'palliative' => 'Паллиатив полыш'
];

// ==================== STANDARD DISCHARGE MEDICATIONS (SEED LIST) ====================
// Only used ONCE to fill data/medications.json the first time. After that the list is
// managed in the app (tab "Medications") and the discharge form reads it from that file.
// Format: 'Category' => [ 'Medication' => ['available strengths/forms', ...], ... ]
// Add or remove entries here; the dropdown updates automatically.
// NOTE: only name + available strengths are suggested. Dose, frequency and duration
// are always entered by the prescriber (patients range from infants to adults).
$standardMeds = [
    'Корштмо & шокшо' => [
        'Paracetamol'   => ['500 mg таблетке', '1000 mg таблетке', '120 mg/5 ml суспензий', '125 mg суппозиторий'],
        'Ibuprofen'     => ['200 mg таблетке', '400 mg таблетке', '100 mg/5 ml суспензий'],
        'Diclofenac'    => ['25 mg таблетке', '50 mg таблетке', '75 mg таблетке SR'],
        'Naproxen'      => ['250 mg таблетке', '500 mg таблетке'],
        'Tramadol'      => ['50 mg капсуле', '100 mg таблетке SR'],
        'Morphine'      => ['10 mg таблетке', '10 mg/5 ml йӱмӧ эм'],
    ],
    'Антибиотик-влак' => [
        'Amoxicillin'                 => ['250 mg капсуле', '500 mg капсуле', '250 mg/5 ml суспензий'],
        'Amoxicillin/Clavulanic acid' => ['500/125 mg таблетке', '875/125 mg таблетке'],
        'Flucloxacillin'              => ['500 mg капсуле', '250 mg/5 ml суспензий'],
        'Doxycycline'                 => ['100 mg капсуле'],
        'Azithromycin'                => ['250 mg таблетке', '500 mg таблетке'],
        'Nitrofurantoin'              => ['50 mg таблетке', '100 mg капсуле MR'],
        'Ciprofloxacin'               => ['250 mg таблетке', '500 mg таблетке'],
    ],
    'Шӱм да вӱр корно-влак' => [
        'Acetylsalicylic acid (Aspirin)' => ['80 mg таблетке', '100 mg таблетке'],
        'Clopidogrel'    => ['75 mg таблетке'],
        'Metoprolol'     => ['50 mg таблетке', '100 mg таблетке', '100 mg таблетке SR'],
        'Bisoprolol'     => ['2.5 mg таблетке', '5 mg таблетке', '10 mg таблетке'],
        'Lisinopril'     => ['5 mg таблетке', '10 mg таблетке', '20 mg таблетке'],
        'Amlodipine'     => ['5 mg таблетке', '10 mg таблетке'],
        'Furosemide'     => ['20 mg таблетке', '40 mg таблетке'],
        'Atorvastatin'   => ['10 mg таблетке', '20 mg таблетке', '40 mg таблетке'],
        'Simvastatin'    => ['20 mg таблетке', '40 mg таблетке'],
        'Apixaban'       => ['2.5 mg таблетке', '5 mg таблетке'],
        'Nitroglycerin (GTN) spray' => ['0.4 mg/доза spray'],
    ],
    'Мӱшкыр-шӱм' => [
        'Omeprazole'     => ['20 mg капсуле', '40 mg капсуле'],
        'Pantoprazole'   => ['20 mg таблетке', '40 mg таблетке'],
        'Metoclopramide' => ['10 mg таблетке'],
        'Ondansetron'    => ['4 mg таблетке', '8 mg таблетке'],
        'Lactulose'      => ['667 mg/ml сироп'],
        'Macrogol'       => ['пакет'],
    ],
    'Шӱлыш & аллергий' => [
        'Salbutamol inhaler' => ['100 mcg/доза'],
        'Budesonide inhaler' => ['200 mcg/доза'],
        'Prednisolone'       => ['5 mg таблетке', '20 mg таблетке'],
        'Cetirizine'         => ['10 mg таблетке', '5 mg/5 ml раствор'],
        'Loratadine'         => ['10 mg таблетке'],
    ],
    'Диабет & эндокрин' => [
        'Metformin'       => ['500 mg таблетке', '850 mg таблетке', '1000 mg таблетке'],
        'Gliclazide'      => ['30 mg таблетке MR', '80 mg таблетке'],
        'Инсулин (возымо семын)' => ['100 IU/ml'],
        'Levothyroxine'   => ['25 mcg таблетке', '50 mcg таблетке', '100 mcg таблетке'],
    ],
    'Нерв-влак & психике' => [
        'Diazepam'      => ['2 mg таблетке', '5 mg таблетке'],
        'Lorazepam'     => ['1 mg таблетке'],
        'Levetiracetam' => ['500 mg таблетке', '1000 mg таблетке'],
        'Sertraline'    => ['50 mg таблетке', '100 mg таблетке'],
    ],
    'Вес' => [
        'Potassium chloride' => ['600 mg таблетке SR'],
        'Folic acid'         => ['0.4 mg таблетке', '5 mg таблетке'],
        'Vitamin D3'         => ['800 IU таблетке', '25.000 IU ampoule'],
        'Iron (ferrous fumarate)' => ['200 mg таблетке'],
    ],
];

// Common choices offered as suggestions (the field stays editable)
$standardFrequencies = ['Кечыште ик гана', 'Кечыште кок гана', '3 гана кечыште', '4 гана кечыште', 'Кажне 4 шагат', 'Кажне 6 шагат', 'Кажне 8 шагат', 'Кажне 12 шагат', 'Йӱдым', 'Эрдене', 'Кӱлеш гын (PRN)', 'Ик доза'];
$standardDurations   = ['1 кече', '3 кече', '5 кече', '7 кече', '10 кече', '14 кече', '1 тылзе', '3 тылзе', 'Пытартымешке', 'Вес ончымешке', 'Шуйна / хронический'];

function getStandardMeds() {
    global $standardMeds;
    return $standardMeds;
}

// ==================== ROLE DEFINITIONS ====================
$roles = [
    'admin' => [
        'name' => 'Администратор',
        'perms' => ['view', 'admit', 'discharge', 'edit', 'move', 'manage', 'logs', 'admin', 'stats', 'telephone', 'mfa_admin', 'user_admin', 'meds']
    ],
    'doctor' => [
        'name' => 'Эмлызе',
        'perms' => ['view', 'admit', 'discharge', 'edit', 'move', 'logs', 'stats', 'telephone', 'meds']
    ],
    'nurse' => [
        'name' => 'Медсестра',
        'perms' => ['view', 'admit', 'edit', 'move', 'logs', 'telephone']
    ],
    'reception' => [
        'name' => 'Регистратор',
        'perms' => ['view', 'admit', 'telephone']
    ],
    'manager' => [
        'name' => 'Отделений вуйлатыше',
        'perms' => ['view', 'admit', 'discharge', 'edit', 'move', 'stats', 'logs', 'meds']
    ],
    'tech' => [
        'name' => 'Техник',
        'perms' => ['view', 'telephone']
    ],
    'auditor' => [
        'name' => 'Аудитор',
        'perms' => ['view', 'logs', 'stats']
    ]
];

// ==================== GENDER HELPER FUNCTION ====================
function getGenderName($code) {
    global $genders;
    return $genders[$code] ?? $code;
}

function getGenderOptions() {
    global $genders;
    return $genders;
}

function getDefaultGender() {
    return DEFAULT_GENDER;
}

function isGenderRequired() {
    return GENDER_REQUIRED;
}

function shouldShowGenderInList() {
    return GENDER_SHOW_IN_PATIENT_LIST;
}

function shouldIncludeGenderInStats() {
    return GENDER_SHOW_IN_STATISTICS;
}

// Helper functions for common lookups
function getDeptName($code) {
    global $depts;
    return $depts[$code] ?? $code;
}

function getRoleName($role) {
    global $roles;
    return $roles[$role]['name'] ?? $role;
}

function generatePatientId() {
    return 'P' . strtoupper(substr(uniqid(), -7));
}

function now() {
    return date(DATE_FORMAT);
}

function formatDate($date) {
    return date(DATE_DISPLAY, strtotime($date));
}

function formatDateShort($date) {
    return date(DATE_SHORT, strtotime($date));
}

function shouldRunAutoArchive() {
    return AUTO_ARCHIVE_ENABLED && (int)date('w') == DETACHMENT_WEEKDAY && (int)date('G') == DETACHMENT_HOUR;
}

// Human readable schedule, e.g. "every Sunday at 00:00"
function archiveScheduleText() {
    $days = ['Рушарня', 'Шочмо', 'Кушкыжмо', 'Вӱргече', 'Изарня', 'Кугарня', 'Шуматкече'];
    return 'кажне ' . $days[DETACHMENT_WEEKDAY % 7] . ' жапыште ' . sprintf('%02d:00', DETACHMENT_HOUR);
}

// Most recent scheduled archive moment at or before $now
function lastArchiveBoundary($now = null) {
    $now = $now ?? time();
    $back = ((int)date('w', $now) - DETACHMENT_WEEKDAY + 7) % 7;
    $b = mktime(DETACHMENT_HOUR, 0, 0, (int)date('n', $now), (int)date('j', $now) - $back, (int)date('Y', $now));
    if ($b > $now) {
        $b = mktime(DETACHMENT_HOUR, 0, 0, (int)date('n', $now), (int)date('j', $now) - $back - 7, (int)date('Y', $now));
    }
    return $b;
}

// Next scheduled archive moment after $now
function nextArchiveRun($now = null) {
    $b = lastArchiveBoundary($now);
    return mktime(DETACHMENT_HOUR, 0, 0, (int)date('n', $b), (int)date('j', $b) + 7, (int)date('Y', $b));
}

function iniBytes($v) {
    $v = trim((string)$v);
    if ($v === '') return 0;
    $unit = strtolower(substr($v, -1));
    $n = (float)$v;
    if ($unit === 'g') $n *= 1073741824;
    elseif ($unit === 'm') $n *= 1048576;
    elseif ($unit === 'k') $n *= 1024;
    return (int)$n;
}

// The real limit is the smallest of MAX_PHOTO_SIZE and the PHP server limits
// (upload_max_filesize / post_max_size). Uploads above the PHP limits are dropped silently by PHP.
function getEffectiveUploadLimit() {
    $limit = MAX_PHOTO_SIZE;
    $u = iniBytes(ini_get('upload_max_filesize'));
    $p = iniBytes(ini_get('post_max_size'));
    if ($u > 0) $limit = min($limit, $u);
    if ($p > 0) $limit = min($limit, (int)($p * 0.8));
    return max($limit, 100 * 1024);
}

function getMaxUploadSize() {
    $size = getEffectiveUploadLimit();
    if ($size >= 1048576) {
        return round($size / 1048576, 1) . ' MB';
    } elseif ($size >= 1024) {
        return round($size / 1024, 1) . ' KB';
    }
    return $size . ' bytes';
}

// ==================== MYSQL STORAGE LAYER ====================
require_once __DIR__ . '/db.php';

// ==================== ROT47 ENCRYPTION FUNCTIONS (TEMPORARY) ====================
function rot47_encrypt($text) {
    return str_rot47($text);
}

function rot47_decrypt($text) {
    return str_rot47($text);
}

if (!function_exists('str_rot47')) {
    function str_rot47($str) {
        return strtr($str, 
            '!"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~',
            'PQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~!"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNO'
        );
    }
}
?>