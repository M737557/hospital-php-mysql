
<?php
// ==================== FORECASTING (ADMINISTRATOR ONLY) ====================
// Included from index.php. Route: ?action=forecast   (CSV export: &export=csv)
//
// What it does
//  - Rebuilds daily history from the patient records (patients + detached_patients):
//    admissions, discharges, bed census (beds in use at the end of each day) and room moves.
//  - Forecasts admissions, discharges and room moves with Holt's damped-trend exponential
//    smoothing plus a weekday pattern (Mondays are not Sundays), with an 80% range.
//  - Projects bed occupancy (total and per department):
//        beds tomorrow = beds today + expected admissions - beds today / average length of stay
//  - Compares user accounts with patients (staff load) and shows day / week / month / year trends.
// Nothing is written to the database; every number is computed on page load.

const FC_HISTORY_DAYS = 730;   // maximum history used to build trends
const FC_FIT_DAYS     = 180;   // history used to fit the forecast (recent behaviour matters most)
const FC_Z80          = 1.2816; // 80% prediction range

// ---------- data collection ----------

function fcLoadPatients() {
    $out = [];
    $seen = [];
    $add = function ($pt) use (&$out, &$seen) {
        if (!is_array($pt) || empty($pt['id']) || empty($pt['admit_date'])) return;
        $k = $pt['id'] . '|' . $pt['admit_date'] . '|' . ($pt['discharge_date'] ?? '');
        if (isset($seen[$k])) return;
        $seen[$k] = true;
        $out[] = $pt;
    };
    foreach ((array)readJSONFile($GLOBALS['pF']) as $pt) $add($pt);
    try {
        foreach ((array)getDischargedPatients() as $pt) $add($pt);
    } catch (Throwable $e) {
        // archive unreachable: forecast from active patients only
    }
    return $out;
}

// One patient can have several stays (readmitted via "Take back to patients").
// Returns [[startTs, endTs|null], ...]
function fcStays(array $pt) {
    $start = strtotime($pt['admit_date'] ?? '');
    if (!$start) return [];
    $stays = [];
    $prev = is_array($pt['previous_discharges'] ?? null) ? $pt['previous_discharges'] : [];
    usort($prev, function ($a, $b) { return strcmp((string)($a['discharge_date'] ?? ''), (string)($b['discharge_date'] ?? '')); });
    foreach ($prev as $pd) {
        $d = strtotime((string)($pd['discharge_date'] ?? ''));
        $r = strtotime((string)($pd['returned_at'] ?? ''));
        if ($d && $d >= $start) {
            $stays[] = [$start, $d];
            if ($r && $r >= $d) $start = $r;
        }
    }
    $end = null;
    if (($pt['status'] ?? '') === 'discharged' && !empty($pt['discharge_date'])) {
        $end = strtotime($pt['discharge_date']) ?: null;
    }
    $stays[] = [$start, $end];
    return $stays;
}

// Room-move timestamps: patient timelines first, then the activity log for older patients.
function fcMoveTimes(array $patients) {
    $times = [];
    $seen = [];
    foreach ($patients as $pt) {
        foreach ((array)($pt['timeline'] ?? []) as $e) {
            if (($e['type'] ?? '') !== 'move' || empty($e['time'])) continue;
            $ts = strtotime($e['time']);
            if (!$ts) continue;
            $k = ($pt['id'] ?? '') . '|' . date('Y-m-d H:i', $ts);
            if (isset($seen[$k])) continue;
            $seen[$k] = true;
            $times[] = $ts;
        }
    }
    if (function_exists('db')) {
        try {
            foreach (db()->query("SELECT logged_at, patient_id FROM activity_log WHERE type = 'move'") as $r) {
                $ts = strtotime($r['logged_at']);
                if (!$ts) continue;
                $k = ($r['patient_id'] ?? '') . '|' . date('Y-m-d H:i', $ts);
                if (isset($seen[$k])) continue;
                $seen[$k] = true;
                $times[] = $ts;
            }
        } catch (Throwable $e) {
            // activity log unavailable
        }
    }
    return $times;
}

// Builds every daily series from the first admission (max FC_HISTORY_DAYS back) to today.
function fcBuildHistory() {
    $patients = fcLoadPatients();
    $rooms = (array)readJSONFile($GLOBALS['rF']);
    $today = strtotime(date('Y-m-d'));

    $first = $today;
    foreach ($patients as $pt) {
        $ts = strtotime($pt['admit_date'] ?? '');
        if ($ts && $ts < $first) $first = $ts;
    }
    $first = max(strtotime(date('Y-m-d', $first)), strtotime('-' . FC_HISTORY_DAYS . ' days', $today));
    $first = min($first, strtotime('-30 days', $today));   // always show at least 30 days

    $keys = [];
    $idx = [];
    for ($d = new DateTime(date('Y-m-d', $first)), $end = new DateTime(date('Y-m-d', $today)); $d <= $end; $d->modify('+1 day')) {
        $k = $d->format('Y-m-d');
        $idx[$k] = count($keys);
        $keys[] = $k;
    }
    $n = count($keys);
    $zero = array_fill(0, $n, 0);
    $adm = $dis = $moves = $diff = $zero;
    $base = 0;
    $admDept = [];
    $losAll = [];      // completed stays: [endTs, days, dept]
    $firstKey = $keys[0];

    foreach ($patients as $pt) {
        $dept = (string)($pt['department'] ?? 'general');
        if (!isset($admDept[$dept])) $admDept[$dept] = $zero;
        foreach (fcStays($pt) as [$s, $e]) {
            $sk = date('Y-m-d', $s);
            $ek = $e ? date('Y-m-d', $e) : null;
            if ($ek !== null && $ek < $firstKey) {
                $losAll[] = [$e, max(0.04, ($e - $s) / 86400), $dept];
                continue;
            }
            if (isset($idx[$sk])) {
                $adm[$idx[$sk]]++;
                $admDept[$dept][$idx[$sk]]++;
                $diff[$idx[$sk]]++;
            } elseif ($sk < $firstKey) {
                $base++;
            } else {
                continue;   // starts in the future (bad data)
            }
            if ($ek !== null) {
                if (isset($idx[$ek])) {
                    $dis[$idx[$ek]]++;
                    $diff[$idx[$ek]]--;
                }
                $losAll[] = [$e, max(0.04, ($e - $s) / 86400), $dept];
            }
        }
    }

    $census = $zero;
    $run = $base;
    for ($i = 0; $i < $n; $i++) {
        $run += $diff[$i];
        $census[$i] = max(0, $run);
    }

    foreach (fcMoveTimes($patients) as $ts) {
        $k = date('Y-m-d', $ts);
        if (isset($idx[$k])) $moves[$idx[$k]]++;
    }

    // Beds
    $beds = 0;
    $occ = 0;
    $deptBeds = [];
    foreach ($rooms as $rm) {
        if (!is_array($rm)) continue;
        $d = (string)($rm['dept'] ?? 'general');
        $deptBeds[$d] = $deptBeds[$d] ?? ['beds' => 0, 'occ' => 0, 'rooms' => 0];
        $deptBeds[$d]['beds'] += (int)($rm['beds'] ?? 0);
        $deptBeds[$d]['occ'] += (int)($rm['occ'] ?? 0);
        $deptBeds[$d]['rooms']++;
        $beds += (int)($rm['beds'] ?? 0);
        $occ += (int)($rm['occ'] ?? 0);
    }

    // Average length of stay (completed stays of the last 180 days, fallback: all)
    $cut = strtotime('-180 days', $today);
    $recent = array_filter($losAll, function ($r) use ($cut) { return $r[0] >= $cut; });
    if (count($recent) < 5) $recent = $losAll;
    $los = $recent ? array_sum(array_column($recent, 1)) / count($recent) : 3.0;
    $losDept = [];
    foreach ($recent as $r) $losDept[$r[2]][] = $r[1];
    foreach ($losDept as $d => $vals) {
        $losDept[$d] = count($vals) >= 3 ? array_sum($vals) / count($vals) : null;
    }
    $losVals = array_column($recent, 1);
    sort($losVals);
    $losMedian = $losVals ? $losVals[intdiv(count($losVals), 2)] : null;

    // Every completed stay by discharge day (for LOS trends)
    $losByDay = [];
    foreach ($losAll as $r) $losByDay[date('Y-m-d', $r[0])][] = $r[1];

    return [
        'patients' => $patients, 'keys' => $keys, 'adm' => $adm, 'dis' => $dis, 'census' => $census,
        'moves' => $moves, 'admDept' => $admDept, 'beds' => $beds, 'occ' => $occ, 'deptBeds' => $deptBeds,
        'los' => max(0.25, $los), 'losMedian' => $losMedian, 'losDept' => $losDept, 'losByDay' => $losByDay,
        'losCount' => count($recent), 'days' => $n,
    ];
}

// ---------- forecasting ----------

// Holt's damped-trend smoothing with a multiplicative weekday pattern.
// $y = daily counts (oldest first, last value = today). Returns fc/lo/hi arrays of length $h
// for the days after the last value.
function fcForecast(array $y, $h, $season = 7) {
    $y = array_values(array_slice($y, -FC_FIT_DAYS));
    $n = count($y);
    $zero = array_fill(0, $h, 0.0);
    if ($n === 0 || array_sum($y) == 0) return ['fc' => $zero, 'lo' => $zero, 'hi' => $zero, 'level' => 0, 'trend' => 0, 'idx' => array_fill(0, $season, 1.0)];

    // Weekday pattern from the last 8 weeks (needs two full weeks)
    $look = min($n, $season * 8);
    $idx = array_fill(0, $season, 1.0);
    if ($look >= $season * 2) {
        $sum = array_fill(0, $season, 0.0);
        $cnt = array_fill(0, $season, 0);
        for ($i = $n - $look; $i < $n; $i++) {
            $sum[$i % $season] += $y[$i];
            $cnt[$i % $season]++;
        }
        $mean = array_sum(array_slice($y, -$look)) / $look;
        if ($mean > 0) {
            for ($k = 0; $k < $season; $k++) {
                $idx[$k] = $cnt[$k] ? max(0.15, min(3.0, ($sum[$k] / $cnt[$k]) / $mean)) : 1.0;
            }
            $norm = array_sum($idx) / $season;
            foreach ($idx as &$v) $v /= $norm;
            unset($v);
        }
    }

    $alpha = 0.3; $beta = 0.05; $phi = 0.9;
    $L = $y[0] / $idx[0];
    $T = 0.0;
    $errs = [];
    for ($i = 1; $i < $n; $i++) {
        $s = $idx[$i % $season];
        $pred = ($L + $phi * $T) * $s;
        $errs[] = $y[$i] - $pred;
        $Lnew = $alpha * ($y[$i] / $s) + (1 - $alpha) * ($L + $phi * $T);
        $T = $beta * ($Lnew - $L) + (1 - $beta) * $phi * $T;
        $L = $Lnew;
    }
    $recentErr = array_slice($errs, -90);
    $sigma = $recentErr ? sqrt(array_sum(array_map(function ($e) { return $e * $e; }, $recentErr)) / count($recentErr)) : 0;

    $fc = $lo = $hi = [];
    $damp = 0;
    for ($k = 1; $k <= $h; $k++) {
        $damp += pow($phi, $k);
        $v = max(0, ($L + $damp * $T) * $idx[($n - 1 + $k) % $season]);
        $w = FC_Z80 * $sigma * sqrt(1 + ($k - 1) * $alpha * $alpha);
        $fc[] = $v;
        $lo[] = max(0, $v - $w);
        $hi[] = $v + $w;
    }
    return ['fc' => $fc, 'lo' => $lo, 'hi' => $hi, 'level' => $L, 'trend' => $T, 'idx' => $idx];
}

// Bed occupancy projection: beds(t+1) = beds(t) + admissions(t+1) - beds(t) / LOS
// The 80% range propagates the day-to-day admission uncertainty: surplus admissions stay in
// bed for a while, so variance builds up and then levels off as patients go home.
function fcProjectCensus($start, array $admFc, array $admLo, array $admHi, $los) {
    $c = $start;
    $var = 0.0;
    $keep = max(0, 1 - 1 / $los);
    $fc = $lo = $hi = $disc = [];
    foreach ($admFc as $k => $a) {
        $d = $c / $los;
        $c = max(0, $c + $a - $d);
        $sa = ($admHi[$k] - $a) / FC_Z80;           // admission std dev for this day
        $var = $var * $keep * $keep + $sa * $sa;
        $w = FC_Z80 * sqrt($var);
        $fc[] = $c; $lo[] = max(0, $c - $w); $hi[] = $c + $w; $disc[] = $d;
    }
    return ['fc' => $fc, 'lo' => $lo, 'hi' => $hi, 'discharges' => $disc];
}

// ---------- trends ----------

function fcPeriodKey($dayKey, $mode) {
    $ts = strtotime($dayKey);
    switch ($mode) {
        case 'week':  return date('o', $ts) . '-W' . date('W', $ts);
        case 'month': return date('Y-m', $ts);
        case 'year':  return date('Y', $ts);
        default:      return $dayKey;
    }
}

function fcPeriodLabel($key, $mode) {
    switch ($mode) {
        case 'week':  return 'Арн ' . (int)substr($key, 6) . " '" . substr($key, 2, 2);
        case 'month': return date('M Y', strtotime($key . '-01'));
        case 'year':  return $key;
        default:      return date('D d M', strtotime($key));
    }
}

function fcTrend(array $H, $mode) {
    $limit = ['day' => 30, 'week' => 26, 'month' => 12, 'year' => 10][$mode] ?? 30;
    $rows = [];
    foreach ($H['keys'] as $i => $k) {
        $p = fcPeriodKey($k, $mode);
        if (!isset($rows[$p])) $rows[$p] = ['adm' => 0, 'dis' => 0, 'moves' => 0, 'censusSum' => 0, 'days' => 0, 'peak' => 0, 'los' => []];
        $r = &$rows[$p];
        $r['adm'] += $H['adm'][$i];
        $r['dis'] += $H['dis'][$i];
        $r['moves'] += $H['moves'][$i];
        $r['censusSum'] += $H['census'][$i];
        $r['peak'] = max($r['peak'], $H['census'][$i]);
        $r['days']++;
        foreach ($H['losByDay'][$k] ?? [] as $l) $r['los'][] = $l;
        unset($r);
    }
    $rows = array_slice($rows, -$limit, null, true);
    $out = [];
    $prev = null;
    foreach ($rows as $p => $r) {
        $avg = $r['days'] ? $r['censusSum'] / $r['days'] : 0;
        $row = [
            'key' => $p, 'label' => fcPeriodLabel($p, $mode), 'adm' => $r['adm'], 'dis' => $r['dis'],
            'moves' => $r['moves'], 'avgCensus' => $avg, 'peak' => $r['peak'],
            'occPct' => $H['beds'] > 0 ? $avg / $H['beds'] * 100 : 0,
            'los' => $r['los'] ? array_sum($r['los']) / count($r['los']) : null,
            'partial' => ($mode !== 'day' && $p === fcPeriodKey(date('Y-m-d'), $mode)),
            'admDelta' => ($prev && $prev['adm'] > 0) ? ($r['adm'] - $prev['adm']) / $prev['adm'] * 100 : null,
        ];
        $out[] = $row;
        $prev = $row;
    }
    return $out;
}

// ---------- user accounts vs patients ----------

function fcUserSpread(array $H, $peakCensus) {
    global $roles;
    $users = (array)readJSONFile($GLOBALS['uF']);
    $active = array_values(array_filter($users, function ($u) { return is_array($u) && (!isset($u['active']) || $u['active']); }));
    $byRole = [];
    foreach ($active as $u) $byRole[$u['role'] ?? '?'] = ($byRole[$u['role'] ?? '?'] ?? 0) + 1;
    $clinical = ($byRole['doctor'] ?? 0) + ($byRole['nurse'] ?? 0);
    $current = 0;
    foreach ($H['patients'] as $pt) if (($pt['status'] ?? '') === 'admitted') $current++;

    // Workload per user over the last 90 days (from the patient timelines)
    $cut = strtotime('-90 days');
    $work = [];
    foreach ($H['patients'] as $pt) {
        foreach ((array)($pt['timeline'] ?? []) as $e) {
            $by = (string)($e['by'] ?? '');
            $ts = strtotime($e['time'] ?? '');
            if ($by === '' || $by === 'system' || !$ts || $ts < $cut) continue;
            $t = in_array($e['type'] ?? '', ['admit', 'move', 'discharge'], true) ? $e['type'] : 'other';
            $work[$by] = $work[$by] ?? ['admit' => 0, 'move' => 0, 'discharge' => 0, 'other' => 0];
            $work[$by][$t]++;
        }
    }
    $userIndex = [];
    foreach ($users as $u) if (is_array($u) && isset($u['user'])) $userIndex[$u['user']] = $u;
    $workRows = [];
    foreach ($work as $by => $w) {
        $u = $userIndex[$by] ?? null;
        $workRows[] = [
            'user' => $by, 'name' => $u['name'] ?? $by, 'role' => $u ? getRoleName($u['role'] ?? '') : 'Шӧрымӧ кучылтшо',
            'admit' => $w['admit'], 'move' => $w['move'], 'discharge' => $w['discharge'],
            'total' => $w['admit'] + $w['move'] + $w['discharge'] + $w['other'],
            'last_login' => $u['last_login'] ?? null,
        ];
    }
    usort($workRows, function ($a, $b) { return $b['total'] <=> $a['total']; });
    $totalActions = array_sum(array_column($workRows, 'total'));

    // Accounts (by creation date) vs average patients per month, last 12 months
    $monthly = [];
    foreach (fcTrend($H, 'month') as $m) {
        $monthEnd = strtotime(date('Y-m-t 23:59:59', strtotime($m['key'] . '-01')));
        $acc = 0;
        foreach ($active as $u) {
            $c = strtotime((string)($u['created'] ?? ''));
            if (!$c || $c <= $monthEnd) $acc++;
        }
        $monthly[] = ['label' => $m['label'], 'accounts' => $acc, 'avgCensus' => $m['avgCensus'],
                      'adm' => $m['adm'], 'ratio' => $acc > 0 ? $m['avgCensus'] / $acc : null];
    }

    return [
        'total' => count($users), 'active' => count($active), 'byRole' => $byRole, 'clinical' => $clinical,
        'current' => $current, 'perUser' => count($active) ? $current / count($active) : null,
        'perClinical' => $clinical ? $current / $clinical : null,
        'peakPerClinical' => $clinical ? $peakCensus / $clinical : null,
        'work' => $workRows, 'totalActions' => $totalActions, 'monthly' => $monthly,
    ];
}

// ---------- SVG charts (no external libraries) ----------

function fcNiceMax($v) {
    if ($v <= 0) return 1;
    $e = pow(10, floor(log10($v)));
    foreach ([1, 1.5, 2, 2.5, 3, 4, 5, 6, 8, 10] as $m) if ($m * $e >= $v) return $m * $e;
    return 10 * $e;
}

function fcNum($v, $dec = 1) {
    if ($v === null) return '–';
    return number_format((float)$v, abs($v) >= 100 ? 0 : $dec);
}

// $series: ['name','type'=>line|bar|band,'values'|'lo'+'hi','color','dash','width']
// $o: 'h' height, 'split' index where the forecast starts, 'ref' capacity line, 'refLabel', 'pct' (y axis in %)
function fcChart(array $labels, array $series, array $o = []) {
    $n = count($labels);
    if ($n === 0) return '<p class="text-muted">Эше данный-влак уке.</p>';
    $W = 960; $H = $o['h'] ?? 250; $pl = 44; $pr = 12; $pt = 14; $pb = 28;
    $iw = $W - $pl - $pr; $ih = $H - $pt - $pb;

    $max = 0;
    $bars = 0;
    foreach ($series as $s) {
        if (($s['type'] ?? 'line') === 'bar') $bars++;
        foreach (['values', 'hi'] as $f) foreach ($s[$f] ?? [] as $v) if ($v !== null && $v > $max) $max = $v;
    }
    if (isset($o['ref'])) $max = max($max, $o['ref']);
    $ymax = fcNiceMax(max($max * 1.08, $o['minMax'] ?? 1));
    $step = $bars ? $iw / $n : ($n > 1 ? $iw / ($n - 1) : $iw);
    $x = function ($i) use ($bars, $pl, $step, $n, $iw) { return $bars ? $pl + ($i + 0.5) * $step : $pl + ($n > 1 ? $i * $step : $iw / 2); };
    $y = function ($v) use ($pt, $ih, $ymax) { return $pt + $ih - ($v / $ymax) * $ih; };
    $f = function ($v) { return number_format($v, 1, '.', ''); };
    $suffix = !empty($o['pct']) ? '%' : '';

    $svg = '<svg class="fc-chart" viewBox="0 0 ' . $W . ' ' . $H . '" preserveAspectRatio="none" role="img" aria-label="' . htmlspecialchars($o['title'] ?? 'Диаграмме') . '">';

    if (isset($o['split']) && $o['split'] < $n) {
        $sx = $x($o['split']) - ($bars ? $step / 2 : 0);
        $svg .= '<rect x="' . $f($sx) . '" y="' . $pt . '" width="' . $f($W - $pr - $sx) . '" height="' . $ih . '" class="fc-fcarea"/>';
        $svg .= '<text x="' . $f($sx + 6) . '" y="' . ($pt + 12) . '" class="fc-ax">прогноз →</text>';
    }
    for ($t = 0; $t <= 4; $t++) {
        $v = $ymax * $t / 4;
        $gy = $y($v);
        $svg .= '<line x1="' . $pl . '" x2="' . ($W - $pr) . '" y1="' . $f($gy) . '" y2="' . $f($gy) . '" class="fc-grid"/>';
        $svg .= '<text x="' . ($pl - 6) . '" y="' . $f($gy + 4) . '" text-anchor="end" class="fc-ax">' . ($v == floor($v) ? (int)$v : number_format($v, 1)) . $suffix . '</text>';
    }

    $bi = 0;
    foreach ($series as $s) {
        $type = $s['type'] ?? 'line';
        $color = $s['color'] ?? 'var(--fc-ink)';
        if ($type === 'band') {
            $top = $bot = [];
            foreach ($s['hi'] as $i => $v) {
                if ($v === null || ($s['lo'][$i] ?? null) === null) continue;
                $top[] = $f($x($i)) . ',' . $f($y($v));
                array_unshift($bot, $f($x($i)) . ',' . $f($y($s['lo'][$i])));
            }
            if ($top) $svg .= '<polygon points="' . implode(' ', array_merge($top, $bot)) . '" class="fc-band"/>';
        } elseif ($type === 'bar') {
            $bw = $step * 0.78 / $bars;
            foreach ($s['values'] as $i => $v) {
                if ($v === null || $v <= 0) continue;
                $bx = $x($i) - $step * 0.39 + $bi * $bw;
                $svg .= '<rect x="' . $f($bx) . '" y="' . $f($y($v)) . '" width="' . $f(max(1, $bw - 1)) . '" height="' . $f($pt + $ih - $y($v)) . '" fill="' . $color . '"' . (!empty($s['fade']) ? ' opacity=".45"' : '') . '/>';
            }
            $bi++;
        } else {
            $d = '';
            $pen = false;
            foreach ($s['values'] as $i => $v) {
                if ($v === null) { $pen = false; continue; }
                $d .= ($pen ? 'L' : 'M') . $f($x($i)) . ' ' . $f($y($v));
                $pen = true;
            }
            if ($d !== '') {
                $svg .= '<path d="' . $d . '" fill="none" stroke="' . $color . '" stroke-width="' . ($s['width'] ?? 2) . '"'
                      . (!empty($s['dash']) ? ' stroke-dasharray="6 4"' : '') . ' stroke-linejoin="round" vector-effect="non-scaling-stroke"/>';
            }
        }
    }

    if (isset($o['ref'])) {
        $ry = $f($y($o['ref']));
        $svg .= '<line x1="' . $pl . '" x2="' . ($W - $pr) . '" y1="' . $ry . '" y2="' . $ry . '" class="fc-ref"/>';
        $svg .= '<text x="' . ($W - $pr - 4) . '" y="' . ($ry - 5) . '" text-anchor="end" class="fc-ax fc-refl">' . htmlspecialchars($o['refLabel'] ?? 'кертмаш') . '</text>';
    }

    $every = max(1, (int)ceil($n / 9));
    foreach ($labels as $i => $l) {
        if ($i % $every !== 0) continue;
        $svg .= '<text x="' . $f($x($i)) . '" y="' . ($H - 8) . '" text-anchor="middle" class="fc-ax">' . htmlspecialchars($l) . '</text>';
    }

    // hover targets with the values of every series
    $hw = $bars ? $step : ($n > 1 ? $step : $iw);
    foreach ($labels as $i => $l) {
        $tip = $l;
        foreach ($series as $s) {
            if (($s['type'] ?? 'line') === 'band') {
                if (($s['lo'][$i] ?? null) !== null) $tip .= "\n" . $s['name'] . ': ' . fcNum($s['lo'][$i]) . ' – ' . fcNum($s['hi'][$i]) . $suffix;
            } elseif (($s['values'][$i] ?? null) !== null) {
                $tip .= "\n" . $s['name'] . ': ' . fcNum($s['values'][$i]) . $suffix;
            }
        }
        $svg .= '<rect x="' . $f($x($i) - $hw / 2) . '" y="' . $pt . '" width="' . $f($hw) . '" height="' . $ih . '" class="fc-hit"><title>' . htmlspecialchars($tip) . '</title></rect>';
    }
    return $svg . '</svg>';
}

function fcLegend(array $items) {
    $h = '<div class="fc-legend">';
    foreach ($items as $it) {
        $h .= '<span><i class="fc-key fc-key-' . $it[1] . '"' . (isset($it[2]) ? ' style="background:' . $it[2] . ';border-color:' . $it[2] . '"' : '') . '></i>' . htmlspecialchars($it[0]) . '</span>';
    }
    return $h . '</div>';
}

// ---------- page ----------

function showForecast() {
    if (!can('admin')) {
        showError('Кертмаш чарыме');
        exit;
    }

    $horizon = (int)($_GET['h'] ?? 14);
    if (!in_array($horizon, [7, 14, 30, 60, 90], true)) $horizon = 14;
    $mode = $_GET['trend'] ?? 'week';
    if (!in_array($mode, ['day', 'week', 'month', 'year'], true)) $mode = 'week';

    $H = fcBuildHistory();
    $n = $H['days'];
    $los = $H['los'];

    // Day keys for the forecast horizon
    $fKeys = [];
    for ($k = 1; $k <= $horizon; $k++) $fKeys[] = date('Y-m-d', strtotime("+$k days", strtotime(date('Y-m-d'))));

    $A = fcForecast($H['adm'], $horizon);
    $D = fcForecast($H['dis'], $horizon);
    $M = fcForecast($H['moves'], $horizon);
    $C = fcProjectCensus($H['occ'], $A['fc'], $A['lo'], $A['hi'], $los);

    $beds = max(0, $H['beds']);
    $peakIdx = 0;
    foreach ($C['fc'] as $k => $v) if ($v > $C['fc'][$peakIdx]) $peakIdx = $k;
    $peak = $C['fc'][$peakIdx] ?? $H['occ'];
    $fullDay = null;
    foreach ($C['fc'] as $k => $v) if ($beds > 0 && $v >= 0.95 * $beds) { $fullDay = $k; break; }
    $fullDayHigh = null;
    foreach ($C['hi'] as $k => $v) if ($beds > 0 && $v >= 0.95 * $beds) { $fullDayHigh = $k; break; }

    // ---- CSV export ----
    if (($_GET['export'] ?? '') === 'csv') {
        logMsg("Admin: прогноз экспортлымо ($horizon кече)");
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="forecast_' . date('Y-m-d') . '_' . $horizon . 'd.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['кече', 'пуртымаш-влак', 'admissions_low', 'admissions_high', 'лукмаш-влак', 'room_moves',
                       'beds_in_use', 'beds_in_use_low', 'beds_in_use_high', 'total_beds', 'occupancy_pct']);
        foreach ($fKeys as $k => $day) {
            fputcsv($out, [$day, round($A['fc'][$k], 2), round($A['lo'][$k], 2), round($A['hi'][$k], 2),
                           round($D['fc'][$k], 2), round($M['fc'][$k], 2), round($C['fc'][$k], 1), round($C['lo'][$k], 1),
                           round($C['hi'][$k], 1), $beds, $beds ? round($C['fc'][$k] / $beds * 100, 1) : '']);
        }
        fclose($out);
        exit;
    }

    // ---- chart data: last 60 days of history + forecast ----
    $histN = min($n, 60);
    $hKeys = array_slice($H['keys'], -$histN);
    $labels = array_map(function ($k) { return date('d M', strtotime($k)); }, array_merge($hKeys, $fKeys));
    $nullsF = array_fill(0, $horizon, null);
    $nullsH = array_fill(0, $histN, null);
    $lastOf = function ($arr) use ($histN) { return array_slice($arr, -$histN); };

    // join the forecast to the last actual point so the lines connect
    $joinF = function ($hist, $fc) use ($histN) {
        $pad = array_fill(0, $histN - 1, null);
        return array_merge($pad, [end($hist)], $fc);
    };

    $histCensus = $lastOf($H['census']);
    $histCensus[$histN - 1] = $H['occ'];   // today: use the live room occupancy
    $censusChart = fcChart($labels, [
        ['name' => '80% кокласе', 'type' => 'band', 'lo' => array_merge($nullsH, $C['lo']), 'hi' => array_merge($nullsH, $C['hi'])],
        ['name' => 'Налме вакшыш-влак', 'values' => array_merge($histCensus, $nullsF)],
        ['name' => 'Прогноз', 'values' => $joinF($histCensus, $C['fc']), 'dash' => true],
    ], ['split' => $histN, 'ref' => $beds, 'refLabel' => "кертмаш $beds вакшыш", 'title' => 'Вакшыш-влакын тичмаш прогнозшо']);

    $flowChart = function ($hist, $F, $name) use ($labels, $histN, $nullsF, $nullsH) {
        return fcChart($labels, [
            ['name' => '80% кокласе', 'type' => 'band', 'lo' => array_merge($nullsH, $F['lo']), 'hi' => array_merge($nullsH, $F['hi'])],
            ['name' => $name, 'type' => 'bar', 'values' => array_merge($hist, $nullsF)],
            ['name' => 'Прогноз', 'type' => 'bar', 'values' => array_merge($nullsH, $F['fc']), 'fade' => true],
        ], ['split' => $histN, 'h' => 190, 'title' => $name]);
    };
    $admChart = $flowChart($lastOf($H['adm']), $A, 'Пуртымаш-влак');
    $disChart = $flowChart($lastOf($H['dis']), $D, 'Лукмаш-влак');
    $movChart = $flowChart($lastOf($H['moves']), $M, 'Палате вашталтыш-влак');

    // ---- weekday pattern (average admissions / discharges / moves per weekday, last 12 weeks) ----
    $wd = ['Шчм', 'Кшк', 'Вӱр', 'Иза', 'Куг', 'Шум', 'Руш'];
    $wdSum = ['adm' => array_fill(0, 7, 0), 'dis' => array_fill(0, 7, 0), 'moves' => array_fill(0, 7, 0)];
    $wdCnt = array_fill(0, 7, 0);
    foreach (array_slice($H['keys'], -84, null, true) as $i => $k) {
        $w = (int)date('N', strtotime($k)) - 1;
        $wdCnt[$w]++;
        foreach ($wdSum as $f => $_) $wdSum[$f][$w] += $H[$f][$i];
    }
    $wdAvg = [];
    foreach ($wdSum as $f => $vals) foreach ($vals as $w => $v) $wdAvg[$f][$w] = $wdCnt[$w] ? $v / $wdCnt[$w] : 0;
    $weekdayChart = fcChart($wd, [
        ['name' => 'Пуртымаш-влак', 'type' => 'bar', 'values' => $wdAvg['adm'], 'color' => 'var(--fc-ink)'],
        ['name' => 'Лукмаш-влак', 'type' => 'bar', 'values' => $wdAvg['dis'], 'color' => 'var(--fc-mid)'],
        ['name' => 'Палате вашталтыш-влак', 'type' => 'bar', 'values' => $wdAvg['moves'], 'color' => 'var(--fc-light)'],
    ], ['h' => 190, 'title' => 'Арня кече-влакын йӧнжӧ']);

    // ---- per department ----
    $deptRows = [];
    foreach ($H['deptBeds'] as $dept => $b) {
        $series = $H['admDept'][$dept] ?? array_fill(0, $n, 0);
        $DA = fcForecast($series, $horizon);
        $dLos = $H['losDept'][$dept] ?? null;
        $dLos = $dLos ? max(0.25, $dLos) : $los;
        $DC = fcProjectCensus($b['occ'], $DA['fc'], $DA['lo'], $DA['hi'], $dLos);
        $dPeak = $DC['fc'] ? max($DC['fc']) : $b['occ'];
        $dPeakHi = $DC['hi'] ? max($DC['hi']) : $b['occ'];
        $dFull = null;
        foreach ($DC['fc'] as $k => $v) if ($b['beds'] > 0 && $v >= $b['beds']) { $dFull = $k; break; }
        $at = function ($d) use ($DC, $horizon) { $d = min($d, $horizon); return $DC['fc'][$d - 1] ?? 0; };
        $deptRows[] = [
            'dept' => $dept, 'beds' => $b['beds'], 'rooms' => $b['rooms'], 'occ' => $b['occ'],
            'admPerDay' => array_sum(array_slice($series, -28)) / 28, 'admFc' => array_sum($DA['fc']),
            'los' => $dLos, 'losOwn' => isset($H['losDept'][$dept]) && $H['losDept'][$dept] !== null,
            'd7' => $at(7), 'dH' => $at($horizon), 'peak' => $dPeak, 'peakHi' => $dPeakHi,
            'peakPct' => $b['beds'] ? $dPeak / $b['beds'] * 100 : 0, 'full' => $dFull,
        ];
    }
    usort($deptRows, function ($a, $b) { return $b['peakPct'] <=> $a['peakPct']; });

    $U = fcUserSpread($H, $peak);
    $trend = fcTrend($H, $mode);

    $trendChart = fcChart(array_column($trend, 'label'), [
        ['name' => 'Пуртымаш-влак', 'type' => 'bar', 'values' => array_column($trend, 'adm'), 'color' => 'var(--fc-ink)'],
        ['name' => 'Лукмаш-влак', 'type' => 'bar', 'values' => array_column($trend, 'dis'), 'color' => 'var(--fc-mid)'],
        ['name' => 'Палате вашталтыш-влак', 'type' => 'bar', 'values' => array_column($trend, 'moves'), 'color' => 'var(--fc-light)'],
    ], ['h' => 220, 'title' => 'Тенденций']);
    $trendOccChart = fcChart(array_column($trend, 'label'), [
        ['name' => 'Покшел тичмаш', 'values' => array_map(function ($r) { return round($r['occPct'], 1); }, $trend)],
    ], ['h' => 170, 'pct' => true, 'ref' => 85, 'refLabel' => '85% шонымаш', 'minMax' => 10, 'title' => 'Покшел тичмаш']);

    $ratioChart = fcChart(array_column($U['monthly'], 'label'), [
        ['name' => 'Вакшышыште покшел черле', 'type' => 'bar', 'values' => array_column($U['monthly'], 'avgCensus'), 'color' => 'var(--fc-mid)'],
        ['name' => 'Ыштыше кучылтшо аккаунт-влак', 'values' => array_column($U['monthly'], 'accounts')],
    ], ['h' => 200, 'title' => 'Аккаунт-влак черле-влак дене']);

    $sumA = array_sum($A['fc']);
    $sumD = array_sum($D['fc']);
    $sumM = array_sum($M['fc']);
    $occPct = $beds ? $H['occ'] / $beds * 100 : 0;
    $peakPct = $beds ? $peak / $beds * 100 : 0;
    $histAvgAdm = array_sum(array_slice($H['adm'], -$horizon)) / max(1, min($n, $horizon));
    $fmtDay = function ($k) use ($fKeys) { return isset($fKeys[$k]) ? date('D d M', strtotime($fKeys[$k])) : ''; };
    $q = function ($extra) use ($horizon, $mode) {
        return '?' . http_build_query(array_merge(['action' => 'forecast', 'h' => $horizon, 'trend' => $mode], $extra));
    };
    $lowData = $H['losCount'] < 10 || array_sum(array_slice($H['adm'], -28)) < 7;

    showHeader();
?>
    <style>
        .fc-page { --fc-ink:#111; --fc-mid:#8a8a8a; --fc-light:#c9c9c9; --fc-warn:#c62828; }
        .fc-page .card { margin-bottom: 20px; }
        .fc-head { display:flex; justify-content:space-between; align-items:flex-end; gap:16px; flex-wrap:wrap; margin-bottom:16px; }
        .fc-head h2 { margin:0; }
        .fc-controls { display:flex; gap:8px; flex-wrap:wrap; align-items:center; }
        .fc-controls .btn { padding:4px 10px; }
        .fc-kpis { display:grid; grid-template-columns:repeat(auto-fit, minmax(170px, 1fr)); gap:12px; margin-bottom:20px; }
        .fc-kpi { border:1px solid var(--border-color, #ddd); border-radius:6px; padding:12px 14px; background:var(--bg-primary, #fff); }
        .fc-kpi .k { font-size:11px; text-transform:uppercase; letter-spacing:.5px; color:var(--text-muted, #666); }
        .fc-kpi .v { font-size:1.6rem; font-weight:700; line-height:1.2; margin:4px 0 2px; font-variant-numeric:tabular-nums; }
        .fc-kpi .s { font-size:12px; color:var(--text-muted, #666); }
        .fc-kpi.warn { border-left:4px solid var(--fc-warn); }
        .fc-chart { width:100%; height:auto; display:block; overflow:visible; }
        .fc-chart .fc-grid { stroke:#e6e6e6; stroke-width:1; }
        .fc-chart .fc-ax { font-size:11px; fill:#777; font-family:inherit; }
        .fc-chart .fc-band { fill:rgba(0,0,0,.10); }
        .fc-chart .fc-fcarea { fill:rgba(0,0,0,.035); }
        .fc-chart .fc-ref { stroke:var(--fc-warn); stroke-width:1.5; stroke-dasharray:4 3; }
        .fc-chart .fc-refl { fill:var(--fc-warn); }
        .fc-chart .fc-hit { fill:transparent; }
        .fc-chart .fc-hit:hover { fill:rgba(0,0,0,.05); }
        .fc-legend { display:flex; gap:16px; flex-wrap:wrap; font-size:12px; color:var(--text-muted, #555); margin:6px 0 8px; }
        .fc-key { display:inline-block; width:14px; height:10px; margin-right:6px; vertical-align:middle; border:1px solid var(--fc-ink); }
        .fc-key-line { height:0; border-width:2px 0 0; background:none; }
        .fc-key-dash { height:0; border-width:2px 0 0; border-style:dashed; background:none; }
        .fc-key-band { background:rgba(0,0,0,.12); border-color:transparent; }
        .fc-key-bar { background:var(--fc-ink); }
        .fc-key-fade { background:var(--fc-ink); opacity:.45; }
        .fc-key-ref { height:0; border-width:2px 0 0; border-style:dashed; border-color:var(--fc-warn); background:none; }
        .fc-grid2 { display:grid; grid-template-columns:repeat(auto-fit, minmax(420px, 1fr)); gap:20px; }
        .fc-grid2 .card { margin-bottom:0; }
        .fc-table { width:100%; border-collapse:collapse; font-size:13px; }
        .fc-table th, .fc-table td { padding:6px 8px; border-bottom:1px solid var(--border-light, #eee); text-align:right; white-space:nowrap; font-variant-numeric:tabular-nums; }
        .fc-table th:first-child, .fc-table td:first-child { text-align:left; }
        .fc-table th { font-size:11px; text-transform:uppercase; letter-spacing:.4px; color:var(--text-muted, #666); }
        .fc-bar { display:inline-block; width:80px; height:8px; background:#e6e6e6; border-radius:4px; overflow:hidden; vertical-align:middle; margin-right:6px; }
        .fc-bar span { display:block; height:100%; background:var(--fc-ink); }
        .fc-bar.hot span { background:var(--fc-warn); }
        .fc-hot { color:var(--fc-warn); font-weight:600; }
        .fc-up { color:#1a7f37; } .fc-down { color:var(--fc-warn); }
        .fc-note { font-size:12px; color:var(--text-muted, #666); margin-top:8px; }
        .fc-roles { display:flex; flex-wrap:wrap; gap:8px; margin:8px 0 12px; }
        .fc-roles span { border:1px solid var(--border-color, #ddd); border-radius:999px; padding:2px 10px; font-size:12px; }
        @media (max-width: 600px) { .fc-grid2 { grid-template-columns:1fr; } }
    </style>

    <div class="container fc-page">
        <div class="fc-head">
            <div>
                <h2><i class="fas fa-chart-line"></i> Прогноз</h2>
                <p class="text-muted" style="margin:4px 0 0;">Администратор-влаклан гына &middot; <?= $n ?>  кече историй негызеш &middot; шотлымо <?= date('d-m-Y H:i') ?></p>
            </div>
            <div class="fc-controls">
                <span class="text-muted">Горизонт:</span>
                <?php foreach ([7, 14, 30, 60, 90] as $hz): ?>
                    <a class="btn <?= $hz === $horizon ? 'btn-primary' : '' ?>" href="<?= htmlspecialchars($q(['h' => $hz])) ?>"><?= $hz ?> кече</a>
                <?php endforeach; ?>
                <a class="btn" href="<?= htmlspecialchars($q(['export' => 'csv'])) ?>"><i class="fas fa-download"></i> CSV</a>
            </div>
        </div>

        <?php if ($lowData): ?>
            <div class="alert alert-warning">Историй эше шагал (шагалрак 10 мучашлалтше кодмаш-влак але шагалрак 7 пуртымаш-влак пытартыш 4 арнялан). Ик-кок арня шотан пайдаланымек, прогноз-влак ӱшанле лийыт.</div>
        <?php endif; ?>

        <div class="fc-kpis">
            <div class="fc-kpi">
                <div class="k">Кызыт налме вакшыш-влак</div>
                <div class="v"><?= $H['occ'] ?> / <?= $beds ?></div>
                <div class="s"><?= fcNum($occPct) ?>% налме &middot; <?= max(0, $beds - $H['occ']) ?> яра</div>
            </div>
            <div class="fc-kpi <?= $peakPct >= 95 ? 'warn' : '' ?>">
                <div class="k">Вес <?= $horizon ?> кечылаште кӱшыл</div>
                <div class="v"><?= fcNum($peak) ?> вакшыш-влак</div>
                <div class="s"><?= fcNum($peakPct) ?>% кечын <?= $fmtDay($peakIdx) ?></div>
            </div>
            <div class="fc-kpi <?= $fullDay !== null ? 'warn' : '' ?>">
                <div class="k">Больнице ≥ 95% тич</div>
                <?php if ($fullDay !== null): ?>
                    <div class="v fc-hot"><?= $fmtDay($fullDay) ?></div>
                    <div class="s"><?= $fullDay + 1 ?>  кечын (вучымо)</div>
                <?php elseif ($fullDayHigh !== null): ?>
                    <div class="v">Лийын кертеш</div>
                    <div class="s"><?= $fmtDay($fullDayHigh) ?> гыч, шуко паша годым</div>
                <?php else: ?>
                    <div class="v">Вучымо огыл</div>
                    <div class="s"><?= $horizon ?>  кече кошт</div>
                <?php endif; ?>
            </div>
            <div class="fc-kpi">
                <div class="k">Вучымо пуртымаш-влак</div>
                <div class="v"><?= fcNum($sumA, 0) ?></div>
                <div class="s"><?= fcNum($sumA / $horizon) ?>/кече (пытартыш <?= $horizon ?> кече: <?= fcNum($histAvgAdm) ?>/кече)</div>
            </div>
            <div class="fc-kpi">
                <div class="k">Вучымо лукмаш-влак</div>
                <div class="v"><?= fcNum($sumD, 0) ?></div>
                <div class="s"><?= fcNum($sumD / $horizon) ?>/кече</div>
            </div>
            <div class="fc-kpi">
                <div class="k">Вучымо палате вашталтыш-влак</div>
                <div class="v"><?= fcNum($sumM, 0) ?></div>
                <div class="s"><?= fcNum($sumM / $horizon) ?>/кече</div>
            </div>
            <div class="fc-kpi">
                <div class="k">Кодмашын покшел кужытшо</div>
                <div class="v"><?= fcNum($los) ?> к</div>
                <div class="s">медиане <?= fcNum($H['losMedian']) ?> к &middot; <?= $H['losCount'] ?> кодмаш-влак</div>
            </div>
            <div class="fc-kpi <?= ($U['peakPerClinical'] ?? 0) > 6 ? 'warn' : '' ?>">
                <div class="k">Эмлызылан черле-влак</div>
                <div class="v"><?= fcNum($U['perClinical']) ?></div>
                <div class="s"><?= $U['clinical'] ?> эмлызе/медсестра аккаунт-влак &middot; кӱшылныже <?= fcNum($U['peakPerClinical']) ?></div>
            </div>
        </div>

        <!-- ===== BED FORECAST ===== -->
        <div class="card">
            <h3>Вакшыш-влакын прогнозшо</h3>
            <?= fcLegend([['Налме вакшыш-влак', 'line'], ['Прогноз', 'dash'], ['80% кокласе', 'band'], ['Кертмаш', 'ref']]) ?>
            <?= $censusChart ?>
            <p class="fc-note">Проекций: эрла налме вакшыш-влак = кызыт налме вакшыш-влак + вучымо пуртымаш-влак &minus; налме вакшыш-влак &divide; покшел кодмаш (<?= fcNum($los) ?> кече). Кокласе пуртымашын ӱлыл/кӱшыл прогнозшым кучылтеш. Таче чот — палате-влакын кызыт тичмашышт.</p>
        </div>

        <div class="card">
            <h3>Отделений-влак дене вакшыш прогноз</h3>
            <div class="table-container">
                <table class="fc-table">
                    <thead><tr>
                        <th>Отделений</th><th>Палате-влак</th><th>Вакшыш-влак</th><th>Кучылтмо</th><th>Пурт./кече (4 арня)</th>
                        <th>Покшел кодмаш</th><th>Вучымо пурт.</th><th>+7 кече</th><th>+<?= $horizon ?> кече</th><th>Кӱшыл</th><th>Тич лиеш</th>
                    </tr></thead>
                    <tbody>
                    <?php foreach ($deptRows as $d): $hot = $d['peakPct'] >= 95; ?>
                        <tr>
                            <td><?= htmlspecialchars(getDeptName($d['dept'])) ?></td>
                            <td><?= $d['rooms'] ?></td>
                            <td><?= $d['beds'] ?></td>
                            <td><?= $d['occ'] ?></td>
                            <td><?= fcNum($d['admPerDay'], 2) ?></td>
                            <td><?= fcNum($d['los']) ?> d<?= $d['losOwn'] ? '' : '*' ?></td>
                            <td><?= fcNum($d['admFc']) ?></td>
                            <td><?= fcNum($d['d7']) ?></td>
                            <td><?= fcNum($d['dH']) ?></td>
                            <td class="<?= $hot ? 'fc-hot' : '' ?>">
                                <span class="fc-bar <?= $hot ? 'hot' : '' ?>"><span style="width:<?= min(100, round($d['peakPct'])) ?>%"></span></span><?= fcNum($d['peakPct'], 0) ?>%
                            </td>
                            <td class="<?= $d['full'] !== null ? 'fc-hot' : '' ?>"><?= $d['full'] !== null ? $fmtDay($d['full']) : '–' ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (!$deptRows): ?><tr><td colspan="11" class="text-muted">Палате-влак палемдыме огыл.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
            <p class="fc-note">* тиде отделенийыште мучашлалтше кодмаш-влак ситыдымын; больницын покшел чотшо кучылтмо. Пуртымаш-влак пуртышо отделенийлан шотлалтыт.</p>
        </div>

        <!-- ===== PATIENT FLOW ===== -->
        <div class="fc-grid2">
            <div class="card">
                <h3>Черле-влакын прогнозышт &middot; пуртымаш-влак</h3>
                <?= fcLegend([['Чын', 'bar'], ['Прогноз', 'fade'], ['80% кокласе', 'band']]) ?>
                <?= $admChart ?>
            </div>
            <div class="card">
                <h3>Черле-влакын прогнозышт &middot; лукмаш-влак</h3>
                <?= fcLegend([['Чын', 'bar'], ['Прогноз', 'fade'], ['80% кокласе', 'band']]) ?>
                <?= $disChart ?>
            </div>
            <div class="card">
                <h3>Вакшыш вашталтыш-влак (палате вашталтыш-влак)</h3>
                <?= fcLegend([['Чын', 'bar'], ['Прогноз', 'fade'], ['80% кокласе', 'band']]) ?>
                <?= $movChart ?>
                <p class="fc-note">Черле-влакын жап корныштым, паша журналымат (аралыме <?= defined('LOG_RETENTION_DAYS') ? (int)LOG_RETENTION_DAYS : 30 ?> кече) жап корно лиймешке пуртымо черле-влаклан.</p>
            </div>
            <div class="card">
                <h3>Арня кече-влакын йӧнжӧ <small class="text-muted">(кечыште покшел, пытартыш 12 арня)</small></h3>
                <?= fcLegend([['Пуртымаш-влак', 'bar', 'var(--fc-ink)'], ['Лукмаш-влак', 'bar', 'var(--fc-mid)'], ['Палате вашталтыш-влак', 'bar', 'var(--fc-light)']]) ?>
                <?= $weekdayChart ?>
                <p class="fc-note">Прогноз-влак тиде йӧным кучылтыт, садлан шуко пашан кечылаште прогноз кӱшкырак.</p>
            </div>
        </div>

        <div class="card" style="margin-top:20px;">
            <h3>Кече-кече прогноз</h3>
            <div class="table-container" style="max-height:420px; overflow:auto;">
                <table class="fc-table">
                    <thead><tr><th>Кече</th><th>Пуртымаш-влак</th><th>Кокласе</th><th>Лукмаш-влак</th><th>Палате вашталтыш-влак</th><th>Налме вакшыш-влак</th><th>Кокласе</th><th>Тичмаш</th></tr></thead>
                    <tbody>
                    <?php foreach ($fKeys as $k => $day): $pct = $beds ? $C['fc'][$k] / $beds * 100 : 0; ?>
                        <tr>
                            <td><?= date('D d M Y', strtotime($day)) ?></td>
                            <td><?= fcNum($A['fc'][$k]) ?></td>
                            <td class="text-muted"><?= fcNum($A['lo'][$k]) ?> – <?= fcNum($A['hi'][$k]) ?></td>
                            <td><?= fcNum($D['fc'][$k]) ?></td>
                            <td><?= fcNum($M['fc'][$k]) ?></td>
                            <td><?= fcNum($C['fc'][$k]) ?></td>
                            <td class="text-muted"><?= fcNum($C['lo'][$k]) ?> – <?= fcNum($C['hi'][$k]) ?></td>
                            <td class="<?= $pct >= 95 ? 'fc-hot' : '' ?>"><span class="fc-bar <?= $pct >= 95 ? 'hot' : '' ?>"><span style="width:<?= min(100, round($pct)) ?>%"></span></span><?= fcNum($pct, 0) ?>%</td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- ===== USER ACCOUNTS VS PATIENTS ===== -->
        <div class="card">
            <h3>Кучылтшо аккаунт-влак черле-влак дене</h3>
            <div class="fc-roles">
                <span><strong><?= $U['active'] ?></strong> ыштыше аккаунт-влак<?= $U['total'] > $U['active'] ? ' (' . ($U['total'] - $U['active']) . ' ыштыдыме)' : '' ?></span>
                <?php foreach ($U['byRole'] as $role => $cnt): ?>
                    <span><?= htmlspecialchars(getRoleName($role)) ?>: <strong><?= $cnt ?></strong></span>
                <?php endforeach; ?>
                <span><strong><?= $U['current'] ?></strong> пуртымо черле-влак</span>
                <span><strong><?= fcNum($U['perUser'], 2) ?></strong> аккаунтлан черле-влак</span>
            </div>
            <div class="fc-grid2">
                <div>
                    <?= fcLegend([['Вакшышыште покшел черле', 'bar', 'var(--fc-mid)'], ['Ыштыше кучылтшо аккаунт-влак', 'line']]) ?>
                    <?= $ratioChart ?>
                    <p class="fc-note">Аккаунт-влак ыштыме кече гыч шотлалтыт; шӧрымӧ аккаунт-влак историйыште уке.</p>
                    <table class="fc-table" style="margin-top:8px;">
                        <thead><tr><th>Тылзе</th><th>Аккаунт-влак</th><th>Покшел черле-влак</th><th>Пуртымаш-влак</th><th>Черле-влак/аккаунт</th></tr></thead>
                        <tbody>
                        <?php foreach (array_reverse($U['monthly']) as $m): ?>
                            <tr><td><?= htmlspecialchars($m['label']) ?></td><td><?= $m['accounts'] ?></td><td><?= fcNum($m['avgCensus']) ?></td><td><?= $m['adm'] ?></td><td><?= fcNum($m['ratio'], 2) ?></td></tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div>
                    <h4 style="margin-top:0;">Аккаунтлан паша <small class="text-muted">(пытартыш 90 кече)</small></h4>
                    <table class="fc-table">
                        <thead><tr><th>Кучылтшо</th><th>Роль</th><th>Пуртымаш-влак</th><th>Вашталтыш-влак</th><th>Лукмаш-влак</th><th>Ужаш</th></tr></thead>
                        <tbody>
                        <?php foreach (array_slice($U['work'], 0, 25) as $w): $share = $U['totalActions'] ? $w['total'] / $U['totalActions'] * 100 : 0; ?>
                            <tr>
                                <td title="<?= htmlspecialchars($w['user']) ?>"><?= htmlspecialchars($w['name']) ?></td>
                                <td><?= htmlspecialchars($w['role']) ?></td>
                                <td><?= $w['admit'] ?></td><td><?= $w['move'] ?></td><td><?= $w['discharge'] ?></td>
                                <td><span class="fc-bar"><span style="width:<?= min(100, round($share)) ?>%"></span></span><?= fcNum($share, 0) ?>%</td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (!$U['work']): ?><tr><td colspan="6" class="text-muted">Пытартыш кечылаште возымо ыштыме-влак уке 90 кече.</td></tr><?php endif; ?>
                        </tbody>
                    </table>
                    <p class="fc-note">Прогнозын кӱшылныже <?= fcNum($peak) ?> вакшыш годым <strong><?= fcNum($U['peakPerClinical']) ?></strong> черле лиеш кажне эмлызе/медсестра аккаунтлан (кызыт <?= fcNum($U['perClinical']) ?>).</p>
                </div>
            </div>
        </div>

        <!-- ===== TRENDS ===== -->
        <div class="card">
            <div class="fc-head" style="margin-bottom:8px;">
                <h3 style="margin:0;">Тенденций-влак</h3>
                <div class="fc-controls">
                    <?php foreach (['day' => 'Кече', 'week' => 'Арня', 'month' => 'Тылзе', 'year' => 'Ий'] as $tk => $tl): ?>
                        <a class="btn <?= $tk === $mode ? 'btn-primary' : '' ?>" href="<?= htmlspecialchars($q(['trend' => $tk])) ?>#trends"><?= $tl ?></a>
                    <?php endforeach; ?>
                </div>
            </div>
            <a id="trends"></a>
            <?= fcLegend([['Пуртымаш-влак', 'bar', 'var(--fc-ink)'], ['Лукмаш-влак', 'bar', 'var(--fc-mid)'], ['Палате вашталтыш-влак', 'bar', 'var(--fc-light)']]) ?>
            <?= $trendChart ?>
            <?= fcLegend([['Покшел тичмаш', 'line'], ['85% шонымаш', 'ref']]) ?>
            <?= $trendOccChart ?>
            <div class="table-container" style="margin-top:10px;">
                <table class="fc-table">
                    <thead><tr><th><?= ['day' => 'Кече', 'week' => 'Арня', 'month' => 'Тылзе', 'year' => 'Ий'][$mode] ?? $mode ?></th><th>Пуртымаш-влак</th><th>ончычсо дене таҥастарен</th><th>Лукмаш-влак</th><th>Палате вашталтыш-влак</th><th>Покшел налме вакшыш</th><th>Кӱшыл</th><th>Тичмаш</th><th>Покшел кодмаш</th></tr></thead>
                    <tbody>
                    <?php foreach (array_reverse($trend) as $r): ?>
                        <tr>
                            <td><?= htmlspecialchars($r['label']) ?><?= $r['partial'] ? ' <span class="text-muted">(кызытеш)</span>' : '' ?></td>
                            <td><?= $r['adm'] ?></td>
                            <td class="<?= $r['admDelta'] === null ? '' : ($r['admDelta'] >= 0 ? 'fc-up' : 'fc-down') ?>">
                                <?= $r['admDelta'] === null ? '–' : ($r['admDelta'] >= 0 ? '▲ +' : '▼ ') . fcNum($r['admDelta'], 0) . '%' ?>
                            </td>
                            <td><?= $r['dis'] ?></td>
                            <td><?= $r['moves'] ?></td>
                            <td><?= fcNum($r['avgCensus']) ?></td>
                            <td><?= $r['peak'] ?></td>
                            <td><?= fcNum($r['occPct'], 0) ?>%</td>
                            <td><?= $r['los'] === null ? '–' : fcNum($r['los']) . ' d' ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <p class="fc-note">Тичмаш кажне жаплан таче вакшыш чот дене шотлалтеш. Палемдыме жап "кызытеш" эше шуйна, садлан чумыр чот-влак эше тичмаш огыл.</p>
        </div>

        <div class="card">
            <h3>Прогноз кузе ыштеш</h3>
            <p class="fc-note" style="font-size:13px;">
                Историй кажне черлын возымыж гыч (ыштыше да архивысе) уэш ыштыме, лукмо деч вара угыч пуртымо черле-влакат. Пуртымаш, лукмаш, палате вашталтыш прогнозлалтыт Holt’s exponential smoothing дене, иземше тенденций да арня кече йӧн дене, пытартыш <?= FC_FIT_DAYS ?> кечылан келыштарыме. Шемемдыме пасу — 80% кокласе: 8 кокла гыч 10 кечын чын чот тушко логалшаш. Вакшыш тичмаш пуртымаш прогноз дене кодмашын покшел кужытше гыч лектеш. Нимат аралыме огыл; лаштык кажне пурымо годым уэш шотлалтеш.
            </p>
        </div>

        <a href="?action=admin" class="btn">&larr; Админ</a>
        <a href="?action=statistics" class="btn btn-primary">Статистике</a>
    </div>
<?php
    showFooter();
}