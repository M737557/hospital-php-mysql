<?php
session_start();
require_once 'config.php';
require_once __DIR__ . '/forecast.php';   // administrator-only forecasting (?action=forecast)

// ==================== CONFIGURATION ====================
$pF = PATIENTS_FILE;
$rF = ROOMS_FILE;
$uF = USERS_FILE;
$lF = ACTIVITY_LOG;   // fallback file only; the activity log is stored in MySQL (activity_log)
$tF = TELEPHONES_FILE;
$sF = STATISTICS_FILE;
$rateLimitFile = RATE_LIMIT_FILE;
$dischargedDir = DISCHARGED_DIR;
$photoDir = PHOTO_DIR;

$depts = $GLOBALS['depts'];
$roles = $GLOBALS['roles'];
$genders = $GLOBALS['genders'];

// Create directories if they don't exist
if (!file_exists($dischargedDir)) mkdir($dischargedDir, 0755, true);
if (!file_exists($photoDir)) mkdir($photoDir, 0755, true);

// ==================== DATABASE INITIALIZATION ====================
// All data lives in MySQL (see db.php / sql/schema.sql). Default rooms and users are
// inserted the first time the tables are empty.
dbSeedDefaults();

// Activity log lives in the `activity_log` table. Any lines still in activity.log (old file,
// rotated .bak files, or fallback lines written while MySQL was unreachable) are imported here.
importActivityLogFiles();
purgeActivityLog();

ensurePhotoScript();

if (AUTO_ARCHIVE_ENABLED) {
    autoDetachDischargedPatients();
    cleanupDetachedPatientPhotos();
}

// ==================== SESSION MANAGEMENT ====================
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > SESSION_TIMEOUT)) {
    session_unset();
    session_destroy();
    session_start();
    $_SESSION['error'] = 'Xk’is ri ramaj. Chatok chi jun mul.';
    header('Location: ./');
    exit;
}
$_SESSION['last_activity'] = time();

if (!isset($_SESSION['created'])) {
    $_SESSION['created'] = time();
} else if (time() - $_SESSION['created'] > SESSION_REGENERATE) {
    session_regenerate_id(true);
    $_SESSION['created'] = time();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(CSRF_TOKEN_LENGTH));
}

// ==================== REQUEST HANDLING ====================
if (isset($_GET['cancel_mfa'])) {
    unset($_SESSION['temp_user'], $_SESSION['mfa_required']);
    header('Location: ./');
    exit;
}
if (!isset($_SESSION['user']) && !isset($_POST['login']) && !isset($_POST['mfa_verify'])) {
    if (isset($_SESSION['mfa_required']) && isset($_SESSION['temp_user'])) showMFAPrompt();
    else showLogin();
}
if (isset($_POST['login'])) handleLogin();
if (isset($_GET['logout'])) {
    logMsg("Elem: {$_SESSION['user']['user']}");
    session_destroy();
    header('Location: ./');
    exit;
}
if (isset($_POST['mfa_verify'])) verifyMFA();
if (isset($_POST['mfa_action'])) handleMFAAction();
if (isset($_POST['verify_setup'])) verifyMFASetup();
if (isset($_POST['admin_mfa_action'])) handleAdminMFAAction();
if (isset($_POST['reset_user_password'])) resetUserPassword();
if (isset($_POST['add_new_user'])) addNewUser();
if (isset($_POST['delete_user'])) deleteUser();
if (isset($_POST['add_telephone'])) {
    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
        $_SESSION['error'] = 'CSRF ri chaq’ab’al man xel ta';
        header('Location: ?action=telephone');
        exit;
    }
    addTelephone();
}
if (isset($_POST['edit_telephone'])) {
    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
        $_SESSION['error'] = 'CSRF ri chaq’ab’al man xel ta';
        header('Location: ?action=telephone');
        exit;
    }
    editTelephone();
}
if (isset($_POST['delete_telephone'])) {
    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
        $_SESSION['error'] = 'CSRF ri chaq’ab’al man xel ta';
        header('Location: ?action=telephone');
        exit;
    }
    deleteTelephone();
}
if (isset($_POST['search_telephone'])) $_SESSION['tel_search'] = $_POST['search_query'];
if (isset($_GET['clear_tel_search'])) unset($_SESSION['tel_search']);
if (isset($_POST['add_patient_photo'])) {
    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
        $_SESSION['error'] = 'CSRF ri chaq’ab’al man xel ta';
        header('Location: ?action=patients');
        exit;
    }
    addPatientPhoto();
}
if (isset($_POST['toggle_encryption'])) {
    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
        $_SESSION['error'] = 'CSRF ri chaq’ab’al man xel ta';
        header('Location: ?action=admin');
        exit;
    }
    togglePatientEncryption();
}
if (isset($_POST['view_encrypted_raw'])) {
    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
        $_SESSION['error'] = 'CSRF ri chaq’ab’al man xel ta';
        header('Location: ?action=admin');
        exit;
    }
    viewEncryptedRaw();
}
if (isset($_POST['export_decrypted'])) {
    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
        $_SESSION['error'] = 'CSRF ri chaq’ab’al man xel ta';
        header('Location: ?action=admin');
        exit;
    }
    exportDecryptedPatients();
}
if (isset($_POST['manual_detach']) && can('admin')) {
    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
        $_SESSION['error'] = 'CSRF ri chaq’ab’al man xel ta';
        header('Location: ?action=admin');
        exit;
    }
    manualDetachDischargedPatients();
}

$user = $_SESSION['user'] ?? null;
$action = $_GET['action'] ?? 'dashboard';

if (isset($_SESSION['mfa_required']) && !isset($_POST['mfa_verify']) && $action != 'setup' && $action != 'security') {
    showMFAPrompt();
    exit;
}

if ($user) {
    switch ($action) {
        case 'dashboard':
            showDash();
            break;
        case 'rooms':
            if (can('view')) showRooms();
            else showError('Xq’ataj ri b’ixikil');
            break;
        case 'patients':
            if (can('view')) showPatients();
            else showError('Xq’ataj ri b’ixikil');
            break;
        case 'view':
            if (can('view')) showPatient();
            else showError('Xq’ataj ri b’ixikil');
            break;
        case 'admit':
            if (can('admit')) {
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
                        $_SESSION['error'] = 'CSRF ri chaq’ab’al man xel ta';
                        header('Location: ?action=admit');
                        exit;
                    }
                    admitPatient();
                } else showAdmitForm();
            } else showError('Xq’ataj ri b’ixikil');
            break;
        case 'discharge':
            if (can('discharge')) {
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
                        $_SESSION['error'] = 'CSRF ri chaq’ab’al man xel ta';
                        header('Location: ?action=discharge');
                        exit;
                    }
                    dischargePatient();
                } else showDischargeForm();
            } else showError('Xq’ataj ri b’ixikil');
            break;
        case 'readmit':
            if (canReadmit()) {
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
                        $_SESSION['error'] = 'CSRF ri chaq’ab’al man xel ta';
                        header('Location: ?action=discharged');
                        exit;
                    }
                    readmitPatient();
                } else showReadmitForm();
            } else showError('Xq’ataj ri b’ixikil');
            break;
        case 'print':
            if (can('view')) printSummary();
            else showError('Xq’ataj ri b’ixikil');
            break;
        case 'prescription':
            if (can('view')) printPrescription();
            else showError('Xq’ataj ri b’ixikil');
            break;
        case 'change':
            if (can('move')) {
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
                        $_SESSION['error'] = 'CSRF ri chaq’ab’al man xel ta';
                        header('Location: ?action=change');
                        exit;
                    }
                    changeRoom();
                } else showChangeForm();
            } else showError('Xq’ataj ri b’ixikil');
            break;
        case 'edit':
            if (can('edit')) {
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
                        $_SESSION['error'] = 'CSRF ri chaq’ab’al man xel ta';
                        header('Location: ?action=edit');
                        exit;
                    }
                    editPatient();
                } else showEditForm();
            } else showError('Xq’ataj ri b’ixikil');
            break;
        case 'add_photo':
            if (can('edit')) {
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
                        $_SESSION['error'] = 'CSRF ri chaq’ab’al man xel ta';
                        header('Location: ?action=patients');
                        exit;
                    }
                    addPatientPhoto();
                } else showAddPhotoForm();
            } else showError('Xq’ataj ri b’ixikil');
            break;
        case 'manage':
            if (can('manage')) {
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
                        $_SESSION['error'] = 'CSRF ri chaq’ab’al man xel ta';
                        header('Location: ?action=manage');
                        exit;
                    }
                    addRoom();
                } else showManage();
            } else showError('Xq’ataj ri b’ixikil');
            break;
        case 'medications':
            if (canMeds()) {
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
                        $_SESSION['error'] = 'CSRF ri chaq’ab’al man xel ta';
                        header('Location: ?action=medications');
                        exit;
                    }
                    handleMedicationPost();
                } else showMedications();
            } else showError('Xq’ataj ri b’ixikil');
            break;
        case 'logs':
            if (can('logs')) showLogs();
            else showError('Xq’ataj ri b’ixikil');
            break;
        case 'setup':
            showMFASetup();
            break;
        case 'security':
            showSecurity();
            break;
        case 'mfa_admin':
            if (can('mfa_admin')) showMFAAdmin();
            else showError('Xq’ataj ri b’ixikil');
            break;
        case 'user_manage':
            if (can('user_admin')) showUserManage();
            else showError('Xq’ataj ri b’ixikil');
            break;
        case 'telephone':
            if (can('telephone')) showTelephone();
            else showError('Xq’ataj ri b’ixikil');
            break;
        case 'add_tel':
            if (can('telephone')) {
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
                        $_SESSION['error'] = 'CSRF ri chaq’ab’al man xel ta';
                        header('Location: ?action=add_tel');
                        exit;
                    }
                    addTelephone();
                } else showAddTelForm();
            } else showError('Xq’ataj ri b’ixikil');
            break;
        case 'edit_tel':
            if (can('telephone')) {
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
                        $_SESSION['error'] = 'CSRF ri chaq’ab’al man xel ta';
                        header('Location: ?action=edit_tel');
                        exit;
                    }
                    editTelephone();
                } else showEditTelForm();
            } else showError('Xq’ataj ri b’ixikil');
            break;
        case 'discharged':
            if (canViewDischarged()) showDischargedPatients();
            else showError('Xq’ataj ri b’ixikil');
            break;
        case 'view_discharged':
            if (canViewDischarged()) viewDischargedPatient();
            else showError('Xq’ataj ri b’ixikil');
            break;
        case 'statistics':
            if (can('stats')) showStatistics();
            else showError('Xq’ataj ri b’ixikil');
            break;
        case 'export_discharged':
            if (can('admin')) exportDischargedPatients();
            else showError('Xq’ataj ri b’ixikil');
            break;
        case 'room_photos':
            if (can('view')) showRoomPhotos();
            else showError('Xq’ataj ri b’ixikil');
            break;
        case 'discharge_photos':
            if (canViewDischarged()) showDischargePhotos();
            else showError('Xq’ataj ri b’ixikil');
            break;
        case 'log_photos':
            if (can('logs')) showLogPhotos();
            else showError('Xq’ataj ri b’ixikil');
            break;
        case 'timelines':
            if (can('view')) showTimelines();
            else showError('Xq’ataj ri b’ixikil');
            break;
        case 'photo_grid':
            if (can('view')) showPhotoGrid();
            else showError('Xq’ataj ri b’ixikil');
            break;
        case 'debug_photos':
            if (can('admin')) debugPhotoSystem();
            else showError('Xq’ataj ri b’ixikil');
            break;
        case 'admin':
            if (can('admin')) showAdminPanel();
            else showError('Xq’ataj ri b’ixikil');
            break;
        case 'forecast':
            if (can('admin')) showForecast();
            else showError('Xq’ataj ri b’ixikil');
            break;
        case 'editor':
            if (can('admin')) {
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
                        $_SESSION['error'] = 'CSRF ri chaq’ab’al man xel ta';
                        header('Location: ?action=editor');
                        exit;
                    }
                    handleEditorPost();
                } else showEditor();
            } else showError('Xq’ataj ri b’ixikil');
            break;
        default:
            showDash();
    }
} else {
    showLogin();
}

// ==================== ENCRYPTION FUNCTIONS (MySQL) ====================
// Patient records are always stored ROT47-encoded in MySQL (patients.data_rot47 and
// detached_patients.data_rot47). db.php encodes on write and decodes on read.
function encryptPatientsFile() {
    // Re-writing every record re-encodes it with ROT47
    writeJSONFile($GLOBALS['pF'], readJSONFile($GLOBALS['pF']));
    logMsg("Ri tz’ib’ re yawab’ xk’ewax chi jun mul rik’in ROT47");
    return true;
}

function decryptPatientsFile() {
    return readJSONFile($GLOBALS['pF']);
}

function writePatientsFile($data) {
    writeJSONFile($GLOBALS['pF'], is_array($data) ? $data : []);
    return true;
}

function filterDetachedPatients($patients) {
    // De-attached patients live in their own table, so nothing needs filtering any more
    return is_array($patients) ? array_values(array_filter($patients, 'is_array')) : [];
}

function togglePatientEncryption() {
    // ROT47 storage is mandatory with MySQL; the button re-encodes all records instead
    encryptPatientsFile();
    $_SESSION['success'] = 'Ri retal yawab’ junelik kyakon rik’in ROT47 pa MySQL. Ronoj tz’ib’ xk’ewax chi jun mul.';
    header('Location: ?action=admin');
    exit;
}

function viewEncryptedRaw() {
    if (!can('admin')) {
        showError('Xq’ataj ri b’ixikil');
        exit;
    }
    header('Content-Type: text/plain; charset=utf-8');
    foreach (db()->query("SELECT id, data_rot47 FROM patients ORDER BY admit_date, id") as $r) {
        echo $r['id'], "\t", $r['data_rot47'], "\n";
    }
    exit;
}

function exportDecryptedPatients() {
    if (!can('admin')) {
        showError('Xq’ataj ri b’ixikil');
        exit;
    }

    $patients = readJSONFile($GLOBALS['pF']);

    header('Content-Type: application/json');
    header('Content-Disposition: attachment; filename="patients_decrypted_' . date('Y-m-d') . '.json"');
    echo json_encode($patients, JSON_PRETTY_PRINT);
    exit;
}

// ==================== WEEKLY DE-ATTACH (MySQL) ====================
// Every Sunday 00:00 the MySQL event `ev_weekly_detach` calls sp_detach_discharged(), which
// moves every discharged patient from `patients` to `detached_patients` in one transaction.
// PHP fallback: on every page load from Sunday 00:00 onwards, PHP checks whether `patients`
// still holds patients discharged before the most recent Sunday 00:00. If so, it runs the
// same procedure. This no longer depends on the 'last_detach_boundary' marker, so a missed
// event, a manual run earlier in the week or a failed run can never block the weekly archive.
// A MySQL named lock makes sure only one request runs it at a time.
function countPendingDetach($cutoffTs) {
    $stmt = db()->prepare("SELECT COUNT(*) FROM patients
                            WHERE status = 'discharged' AND discharge_date IS NOT NULL AND discharge_date < ?");
    $stmt->execute([date('Y-m-d H:i:s', $cutoffTs)]);
    return (int)$stmt->fetchColumn();
}

function autoDetachDischargedPatients() {
    $boundary = lastArchiveBoundary();          // most recent Sunday 00:00
    try {
        if (countPendingDetach($boundary) === 0) return;   // nothing waiting: cheap check, no lock
    } catch (Throwable $e) {
        logMsg("SACH: ri tzukunik yakb’al re wuqq q’ij man xel ta: " . $e->getMessage());
        return;
    }

    if (!dbLock('weekly_detach')) return;       // another request is running it right now
    try {
        $pending = countPendingDetach($boundary);   // re-check inside the lock
        if ($pending > 0) {
            $moved = dbDetach($boundary, 'php');
            if ($moved > 0) {
                logMsg("Yakb’al re wuqq q’ij (" . date(DATE_FORMAT, $boundary) . "): $moved re $pending yawab’ xjalwachixik pa detached_patients");
            }
            if ($moved < $pending && dbKvGet('detach_warned') !== (string)$boundary) {
                dbKvSet('detach_warned', (string)$boundary);   // warn once per week, not on every page load
                logMsg("PIXAB: ri yakb’al re wuqq q’ij xuya kan " . countPendingDetach($boundary) . " yawab’ xeel pa patients - chatzukuj sp_detach_discharged");
            }
        }
    } catch (Throwable $e) {
        logMsg("SACH: ri yakb’al re wuqq q’ij man xel ta: " . $e->getMessage());
    } finally {
        dbUnlock('weekly_detach');
    }
}

// Photos are files, so they are removed here (not in SQL) for every de-attached patient
// that still has photos. Runs after the event as well as after the PHP fallback.
function cleanupDetachedPatientPhotos() {
    if (!PHOTO_DELETE_ON_ARCHIVE) return 0;
    $ids = dbDetachedWithoutPhotoCleanup();
    if (!$ids || !dbLock('photo_cleanup')) return 0;
    $total = 0;
    try {
        foreach ($ids as $id) {
            $total += deletePatientPhotos($id);
            dbMarkPhotosDeleted($id);
        }
    } finally {
        dbUnlock('photo_cleanup');
    }
    return $total;
}

function manualDetachDischargedPatients() {
    if (!can('admin')) {
        $_SESSION['error'] = 'Xq’ataj ri b’ixikil';
        header('Location: ?action=admin');
        exit;
    }

    // De-attach everything discharged up to now (does not change the weekly schedule)
    $result = detachDischargedPatients(time(), 'manual');

    if ($result['patients'] > 0) {
        $_SESSION['success'] = "Xjalwachixik {$result['patients']} yawab’ xeel pa detached_patients" .
            ($result['photos'] > 0 ? " rachi’ xesaxik {$result['photos']} (wachib’al)" : '');
    } else {
        $_SESSION['success'] = "Maja k’o yawab’ xel che yakik";
    }

    header('Location: ?action=admin');
    exit;
}

// Moves every patient discharged before $cutoffTs to `detached_patients`.
// Returns ['patients' => n, 'photos' => n].
function detachDischargedPatients($cutoffTs, $source = 'php') {
    $result = ['patients' => 0, 'photos' => 0];
    if (!dbLock('weekly_detach', 10)) {
        logMsg("SACH: ri yakb’al ojer kachakun");
        return $result;
    }
    try {
        $result['patients'] = dbDetach($cutoffTs, $source);
        logMsg("Yakb’al ($source): {$result['patients']} yawab’ xjalwachixik pa detached_patients");
    } catch (Throwable $e) {
        logMsg("SACH: ri yakb’al man xel ta: " . $e->getMessage());
    } finally {
        dbUnlock('weekly_detach');
    }
    $result['photos'] = cleanupDetachedPatientPhotos();
    return $result;
}

// Deletes every photo (and thumbnail) of one patient from all room folders. Returns the count.
function deletePatientPhotos($patientId) {
    $patientId = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)$patientId);
    if ($patientId === '') return 0;
    $deleted = 0;
    foreach (glob(PHOTO_DIR . 'room_*/' . $patientId . '_*.png') ?: [] as $file) {
        if (is_file($file) && @unlink($file)) $deleted++;
    }
    if ($deleted > 0) logMsg("Xesaxik $deleted wachib’al re yawab’ yakom $patientId");
    return $deleted;
}

// ==================== ARCHIVE WEEKS ====================
// De-attached patients are grouped by the ISO week of their discharge date ('WW-YYYY'),
// stored in detached_patients.archive_week.
function archiveWeekKey($ts) {
    return date('W', $ts) . '-' . date('o', $ts);
}

// Validates an archive key; returns a label (no longer a file path) or null
function archiveFileForKey($key) {
    $key = (string)$key;
    if (preg_match('/^\d{2}-\d{4}$/', $key)) return 'detached_patients wuqq q’ij ' . $key;
    return null;
}

function archiveWeekFile($ts) {
    return archiveFileForKey(archiveWeekKey($ts));
}

// [start, end] timestamps covered by an archive key
function archiveKeyRange($key) {
    if (preg_match('/^(\d{2})-(\d{4})$/', (string)$key, $m)) {
        $d = new DateTime();
        $d->setISODate((int)$m[2], (int)$m[1], 1);
        $d->setTime(0, 0, 0);
        $start = $d->getTimestamp();
        $d->modify('+6 days');
        $d->setTime(23, 59, 59);
        return [$start, $d->getTimestamp()];
    }
    return [0, PHP_INT_MAX];
}

function archiveKeyLabel($key) {
    if (preg_match('/^(\d{2})-(\d{4})$/', (string)$key, $m)) {
        list($a, $b) = archiveKeyRange($key);
        return 'Wuqq q’ij ' . (int)$m[1] . ', ' . $m[2] . ' (' . date('M j', $a) . ' - ' . date('M j', $b) . ')';
    }
    return htmlspecialchars((string)$key);
}

// All archive weeks, newest first
function getArchiveKeys() {
    static $keys = null;
    if ($keys === null) $keys = dbArchiveWeeks();
    return $keys;
}

// Kept for older callers
function getDischargeDates() {
    return getArchiveKeys();
}

// $key = archive week ('WW-YYYY'); null = every de-attached patient. Newest discharge first.
// Each patient gets '_archive_date' (its week) and 'source_file' (a label).
function getDischargedPatients($key = null) {
    if ($key !== null && $key !== '' && !archiveFileForKey($key)) return [];
    return dbDetachedPatients($key ?: null);
}

// ==================== PDF GENERATION FUNCTIONS ====================
function generateDischargePDF($patient, $dischargeDate) {
    global $dischargedDir;
    
    $datetime = date('Y-m-d_H-i-s', strtotime($dischargeDate));
    $pdfFile = $dischargedDir . 'discharge_' . $patient['id'] . '_' . $datetime . '.pdf';
    
    $width = 800;
    $height = 1000;
    $image = imagecreate($width, $height);
    
    $white = imagecolorallocate($image, 255, 255, 255);
    $black = imagecolorallocate($image, 0, 0, 0);
    $gray = imagecolorallocate($image, 200, 200, 200);
    $darkGray = imagecolorallocate($image, 100, 100, 100);
    
    imagefill($image, 0, 0, $white);
    
    imagerectangle($image, 10, 10, $width-10, $height-10, $black);
    
    $headerY = 40;
    imagestring($image, 5, 50, $headerY, HOSPITAL_NAME . " - DISCHARGE SUMMARY", $black);
    imagestring($image, 3, 50, $headerY + 25, HOSPITAL_ADDRESS . " · " . HOSPITAL_PHONE, $darkGray);
    
    imageline($image, 50, 80, $width-50, 80, $black);
    
    $y = 100;
    imagestring($image, 4, 50, $y, "PATIENT INFORMATION", $black);
    $y += 25;
    
    imagestring($image, 3, 50, $y, "Patient ID: " . $patient['id'], $black);
    imagestring($image, 3, 300, $y, "Name: " . $patient['name'], $black);
    $y += 20;
    imagestring($image, 3, 50, $y, "Age: " . $patient['age'], $black);
    imagestring($image, 3, 300, $y, "Gender: " . getGenderName($patient['gender'] ?? 'prefer_not_to_say'), $black);
    $y += 20;
    imagestring($image, 3, 50, $y, "Department: " . getDeptName($patient['department']), $black);
    imagestring($image, 3, 300, $y, "Room: " . ($patient['room_num'] ?? 'Maja k’o'), $black);
    $y += 20;
    imagestring($image, 3, 50, $y, "Admit Date: " . date(DATE_DISPLAY, strtotime($patient['admit_date'])), $black);
    imagestring($image, 3, 300, $y, "Discharge Date: " . date(DATE_DISPLAY, strtotime($patient['discharge_date'])), $black);
    
    $y += 30;
    imageline($image, 50, $y, $width-50, $y, $gray);
    $y += 20;
    
    imagestring($image, 4, 50, $y, "CHIEF COMPLAINT", $black);
    $y += 20;
    
    $complaint = wordwrap($patient['complaint'] ?? 'Maja k’o tz’ib’am', 80, "\n", true);
    $complaintLines = explode("\n", $complaint);
    foreach ($complaintLines as $line) {
        imagestring($image, 3, 50, $y, $line, $darkGray);
        $y += 15;
    }
    
    $y += 10;
    imageline($image, 50, $y, $width-50, $y, $gray);
    $y += 20;
    
    if (!empty($patient['history']) || !empty($patient['allergies'])) {
        imagestring($image, 4, 50, $y, "MEDICAL HISTORY", $black);
        $y += 20;
        
        if (!empty($patient['history'])) {
            imagestring($image, 3, 50, $y, "History: " . $patient['history'], $darkGray);
            $y += 20;
        }
        
        if (!empty($patient['allergies'])) {
            imagestring($image, 3, 50, $y, "Allergies: " . $patient['allergies'], $darkGray);
            $y += 20;
        }
        
        $y += 10;
        imageline($image, 50, $y, $width-50, $y, $gray);
        $y += 20;
    }
    
    imagestring($image, 4, 50, $y, "DISCHARGE SUMMARY", $black);
    $y += 20;
    
    if (isset($patient['discharge'])) {
        $summary = wordwrap($patient['discharge']['summary'] ?? 'Maja k’o ch’utitzijob’al yo’om', 70, "\n", true);
        $summaryLines = explode("\n", $summary);
        foreach ($summaryLines as $line) {
            imagestring($image, 3, 50, $y, $line, $darkGray);
            $y += 15;
        }
        $y += 10;
        
        imagestring($image, 3, 50, $y, "Final Condition: " . ($patient['discharge']['cond'] ?? 'Maja k’o'), $black);
        $y += 20;
        
        if (!empty($patient['discharge']['follow'])) {
            imagestring($image, 3, 50, $y, "Follow-up: " . $patient['discharge']['follow'], $darkGray);
            $y += 20;
        }
        
        if (!empty($patient['discharge']['meds'])) {
            imagestring($image, 3, 50, $y, "Medications: " . $patient['discharge']['meds'], $darkGray);
            $y += 20;
        }
        
        if (!empty($patient['discharge']['doctor_final_notes'])) {
            imagestring($image, 3, 50, $y, "Doctor's Notes: " . $patient['discharge']['doctor_final_notes'], $darkGray);
            $y += 20;
        }
    }
    
    $y += 20;
    imageline($image, 50, $y, $width-50, $y, $black);
    $y += 20;
    
    imagestring($image, 3, 50, $y, "Attending Physician: _________________________", $black);
    imagestring($image, 3, 350, $y, "Date: " . date(DATE_SHORT), $black);
    
    $y += 30;
    imagestring($image, 2, 50, $height-50, "This is an official medical record - Generated: " . date(DATE_FORMAT), $darkGray);
    
    imagepng($image, $pdfFile . '.png');
    imagedestroy($image);
    
    rename($pdfFile . '.png', $pdfFile);
    
    return $pdfFile;
}

// ==================== HEADER FUNCTION ====================
function showHeader() {
    $user = $_SESSION['user'] ?? null;
    $roles = $GLOBALS['roles'];
    $depts = $GLOBALS['depts'];
    // Patient busyness for the top menu (same aggregated numbers as on the login screen)
    $hdrBusy = $user ? getLoginBusyness() : null;

?>
<!DOCTYPE html>
<html lang="quc">
<head>
    <title><?= HOSPITAL_NAME ?> - <?= APP_NAME ?></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="hospital.css">
    <link rel="stylesheet" href="style.css">
    <style>
        .hdr-busy { display: inline-flex; align-items: center; gap: 8px; padding: 3px 10px; margin-right: 10px;
            border: 1px solid #000; border-radius: 999px; font-size: 12px; font-weight: 600;
            text-decoration: none; white-space: nowrap; background: #000; color: #fff !important; }
        .hdr-busy:hover { background: #222; }
        .hdr-busy i { color: #fff; }
        .hdr-busy .hdr-busy-bar { width: 50px; height: 6px; background: #555; border-radius: 999px; overflow: hidden; }
        .hdr-busy .hdr-busy-fill { display: block; height: 100%; background: #fff; }
    </style>
</head>
<body>
<?php $act = $GLOBALS['action'] ?? ''; ?>
<div class="app-container">
    <div class="header">
        <div>
            <h1>
                <?php if (file_exists(HOSPITAL_LOGO)): ?><img src="<?= HOSPITAL_LOGO ?>" class="header-logo" alt=""><?php endif; ?>
                <?= HOSPITAL_NAME ?> <small><?= APP_NAME ?></small>
                <span class="version">v<?= APP_VERSION ?></span>
            </h1>
        </div>
        <?php if ($user): ?>
        <div class="tabs">
            <a href="?action=dashboard" class="tab <?= $act == 'dashboard' ? 'active' : '' ?>"><i class="fas fa-th-large"></i> Nab’e wuj</a>
            <a href="?action=patients" class="tab <?= in_array($act, ['patients','view','edit','change','discharge','print']) ? 'active' : '' ?>"><i class="fas fa-user-injured"></i> Yawab’</a>
            <a href="?action=rooms" class="tab <?= $act == 'rooms' ? 'active' : '' ?>"><i class="fas fa-bed"></i> Taq ja</a>
            <a href="?action=timelines" class="tab <?= $act == 'timelines' ? 'active' : '' ?>"><i class="fas fa-stream"></i> Ub’e q’ij</a>
            <?php if (can('admit')): ?>
                <a href="?action=admit" class="tab <?= $act == 'admit' ? 'active' : '' ?>"><i class="fas fa-user-plus"></i> Chok’ama Yawab’</a>
            <?php endif; ?>
            <?php if (can('telephone')): ?>
                <a href="?action=telephone" class="tab <?= in_array($act, ['telephone','add_tel','edit_tel']) ? 'active' : '' ?>"><i class="fas fa-phone"></i> Ch’awib’al</a>
            <?php endif; ?>
            <?php if (canMeds()): ?>
                <a href="?action=medications" class="tab <?= $act == 'medications' ? 'active' : '' ?>"><i class="fas fa-pills"></i> Kunab’al</a>
            <?php endif; ?>
            <?php if (can('logs')): ?>
                <a href="?action=logs" class="tab <?= $act == 'logs' ? 'active' : '' ?>"><i class="fas fa-clipboard-list"></i> Tz’ib’</a>
            <?php endif; ?>
            <?php if (can('stats')): ?>
                <a href="?action=statistics" class="tab <?= $act == 'statistics' ? 'active' : '' ?>"><i class="fas fa-chart-bar"></i> Ajilanik</a>
            <?php endif; ?>
            <a href="?action=room_photos" class="tab <?= $act == 'room_photos' ? 'active' : '' ?>"><i class="fas fa-camera"></i> Wachib’al Ja</a>
            <a href="?action=photo_grid" class="tab <?= $act == 'photo_grid' ? 'active' : '' ?>"><i class="fas fa-images"></i> Ronoj Wachib’al</a>
            <?php if (can('manage')): ?>
                <a href="?action=manage" class="tab <?= $act == 'manage' ? 'active' : '' ?>"><i class="fas fa-door-open"></i> Chajinik Ja</a>
            <?php endif; ?>
            <?php if (can('user_admin')): ?>
                <a href="?action=user_manage" class="tab <?= $act == 'user_manage' ? 'active' : '' ?>"><i class="fas fa-users"></i> Okisanelab’</a>
            <?php endif; ?>
            <?php if (can('mfa_admin')): ?>
                <a href="?action=mfa_admin" class="tab <?= $act == 'mfa_admin' ? 'active' : '' ?>"><i class="fas fa-key"></i> MFA Ajchak’</a>
            <?php endif; ?>
            <a href="?action=security" class="tab <?= $act == 'security' ? 'active' : '' ?>"><i class="fas fa-shield-alt"></i> Chajinik</a>
            <?php if (can('admin')): ?>
                <a href="?action=admin" class="tab <?= $act == 'admin' ? 'active' : '' ?>"><i class="fas fa-cog"></i> Ajchak’</a>
                <a href="?action=forecast" class="tab <?= $act == 'forecast' ? 'active' : '' ?>"><i class="fas fa-chart-line"></i> Nab’e ilik</a>
                <a href="?action=editor" class="tab <?= $act == 'editor' ? 'active' : '' ?>"><i class="fas fa-code"></i> Ajutzirisanel</a>
            <?php endif; ?>
            <?php if (canViewDischarged()): ?>
                <a href="?action=discharged" class="tab <?= in_array($act, ['discharged','view_discharged','discharge_photos']) ? 'active' : '' ?>"><i class="fas fa-user-check"></i> Yawab’ Xeel</a>
            <?php endif; ?>
        </div>
        <div class="header-user">
            <?php if ($hdrBusy): ?>
            <a href="?action=patients" class="hdr-busy busy-<?= $hdrBusy['level'] ?>"
               title="<?= $hdrBusy['occupied'] ?>/<?= $hdrBusy['beds'] ?> warab’al k’o winaq (<?= $hdrBusy['percent'] ?>%), <?= $hdrBusy['free'] ?> tolon">
                <i class="fas fa-procedures"></i>
                <?= $hdrBusy['patients'] ?> yawab’
                <span class="hdr-busy-bar"><span class="hdr-busy-fill" style="width:<?= $hdrBusy['percent'] ?>%;"></span></span>
                <?= $hdrBusy['label'] ?> &middot; <?= $hdrBusy['percent'] ?>%
            </a>
            <?php endif; ?>
            <span class="who"><i class="fas fa-user"></i> <?= htmlspecialchars($user['name'] ?? $user['user']) ?> (<?= getRoleName($user['role']) ?>)</span>
            <a href="?logout=1" class="logout"><i class="fas fa-sign-out-alt"></i> Elem</a>
        </div>
        <?php endif; ?>
    </div>

    <div class="message-container">
        <?php 
        if (isset($_SESSION['success'])) {
            echo '<div class="alert alert-success">' . htmlspecialchars($_SESSION['success']) . '</div>';
            unset($_SESSION['success']);
        }
        if (isset($_SESSION['error'])) {
            echo '<div class="alert alert-error">' . htmlspecialchars($_SESSION['error']) . '</div>';
            unset($_SESSION['error']);
        }
        if (isset($_SESSION['admin_message'])) {
            echo '<div class="alert alert-success">' . htmlspecialchars($_SESSION['admin_message']) . '</div>';
            unset($_SESSION['admin_message']);
        }
        if (isset($_SESSION['info'])) {
            echo '<div class="alert alert-info">' . htmlspecialchars($_SESSION['info']) . '</div>';
            unset($_SESSION['info']);
        }
        if (isset($_SESSION['warning'])) {
            echo '<div class="alert alert-warning">' . htmlspecialchars($_SESSION['warning']) . '</div>';
            unset($_SESSION['warning']);
        }
        ?>
    </div>
<?php
}

// ==================== FOOTER FUNCTION ====================
function showFooter() {
?>
    <div class="footer">
        <?= HOSPITAL_NAME ?> · <?= APP_NAME ?> v<?= APP_VERSION ?> · <?= date('d-m-Y H:i') ?>
        <?php if (AUTO_ARCHIVE_ENABLED): ?>
            <br><span style="font-size:11px;">Yawab’ xeel keyakik <?= archiveScheduleText() ?> (kepe: <?= date('d-m-Y H:i', nextArchiveRun()) ?>)</span>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
<?php
}

// ==================== HELPER FUNCTIONS ====================
function canViewDischarged() {
    return can('admin') || can('logs') || can('discharge');
}

function canMeds() {
    // 'meds' is not defined in the roles in config.php, so also allow anyone who can discharge or administer.
    return can('meds') || can('discharge') || can('admin');
}

function can($p) {
    $u = $_SESSION['user'] ?? null;
    if (!$u || !isset($u['perms']) || !is_array($u['perms'])) {
        return false;
    }
    return in_array($p, $u['perms']);
}

// ==================== PATIENT TIMELINE ====================
function addTimelineEvent(array &$patient, $type, $title, $detail = '') {
    if (!isset($patient['timeline']) || !is_array($patient['timeline'])) {
        $patient['timeline'] = [];
    }
    $patient['timeline'][] = [
        'time'   => now(),
        'type'   => $type,
        'title'  => $title,
        'detail' => $detail,
        'by'     => $_SESSION['user']['user'] ?? 'system',
        'by_name' => $_SESSION['user']['name'] ?? ($_SESSION['user']['user'] ?? 'system')
    ];
}

// Rebuild room moves for older patients (admitted before timelines existed) from the activity log.
function getLegacyMovesFromLog($patientId) {
    $patientId = (string)$patientId;
    if ($patientId === '') return [];
    $moves = [];
    $idq = preg_quote($patientId, '/');
    // English (old) and K’iche’ log lines; the branch reset (?|...) numbers both the same
    $re = '/^(?|Moved: .*\(' . $idq . '\).*? from Room (\S+) \((.*?)\) to Room (\S+) \((.*?)\)'
        . '|Xjalwachixik: .*\(' . $idq . '\).*? pa Ja (\S+) \((.*?)\) pa Ja (\S+) \((.*?)\))/u';
    $like = '%(' . addcslashes($patientId, '%_\\') . ')%';
    try {
        $stmt = db()->prepare("SELECT logged_at, username, message FROM activity_log
                                WHERE type = 'move' AND (patient_id = ? OR message LIKE ?)
                                ORDER BY logged_at, id");
        $stmt->execute([$patientId, $like]);
        foreach ($stmt as $row) {
            if (preg_match($re, $row['message'], $m)) {
                $moves[] = ['time' => $row['logged_at'], 'by' => $row['username'],
                            'from_room' => $m[1], 'from_dept' => $m[2], 'to_room' => $m[3], 'to_dept' => $m[4]];
            }
        }
    } catch (Throwable $e) {
        return [];
    }
    return $moves;
}

function getPatientTimeline($patient) {
    if (!empty($patient['timeline']) && is_array($patient['timeline'])) {
        $events = $patient['timeline'];
        $events[0]['legacy'] = false;
    } else {
        $events = [];
        $moves = getLegacyMovesFromLog($patient['id'] ?? '');
        $firstRoom = $moves ? $moves[0]['from_room'] : ($patient['room_num'] ?? '?');
        $firstDept = $moves ? $moves[0]['from_dept'] : getDeptName($patient['department'] ?? '');
        if (!empty($patient['admit_date'])) {
            $events[] = ['time' => $patient['admit_date'], 'type' => 'admit', 'title' => 'Xok',
                         'detail' => "Ja $firstRoom ($firstDept)", 'by' => '', 'legacy' => true];
        }
        foreach ($moves as $mv) {
            $events[] = ['time' => $mv['time'], 'type' => 'move', 'title' => 'Xjalwachixik pa Ja ' . $mv['to_room'],
                         'detail' => "Pa Ja {$mv['from_room']} ({$mv['from_dept']}) pa Ja {$mv['to_room']} ({$mv['to_dept']})",
                         'by' => $mv['by'], 'legacy' => true];
        }
        if (!empty($patient['discharge_date'])) {
            $events[] = ['time' => $patient['discharge_date'], 'type' => 'discharge', 'title' => 'Xel',
                         'detail' => '', 'by' => '', 'legacy' => true];
        }
    }
    usort($events, function($a, $b) { return strtotime($a['time']) <=> strtotime($b['time']); });
    return $events;
}

function formatDuration($seconds) {
    $seconds = max(0, (int)$seconds);
    $d = intdiv($seconds, 86400);
    $h = intdiv($seconds % 86400, 3600);
    $m = intdiv($seconds % 3600, 60);
    if ($d > 0) return $d . 'd ' . $h . 'h';
    if ($h > 0) return $h . 'h ' . $m . 'min';
    return $m . 'min';
}

function renderPatientTimeline($patient) {
    $events = getPatientTimeline($patient);
    if (!$events) return;
    $isDischarged = ($patient['status'] ?? '') === 'discharged';
    $start = strtotime($patient['admit_date'] ?? $events[0]['time']);
    $end = $isDischarged && !empty($patient['discharge_date']) ? strtotime($patient['discharge_date']) : time();
    $colors = ['admit' => '#444444', 'move' => '#4c4c4c', 'discharge' => '#3a3a3a'];
    $legacy = !empty($events[0]['legacy']);
    ?>
    <div class="patient-timeline" style="margin-top:30px;">
        <div class="label" style="margin-bottom:8px;">Ub’e q’ij Ja re kunanik</div>
        <div style="display:flex;gap:30px;flex-wrap:wrap;margin-bottom:14px;">
            <div><div class="label">Okib’al</div><div class="info-value"><?= formatDate($patient['admit_date'] ?? $events[0]['time']) ?></div></div>
            <div><div class="label"><?= $isDischarged ? 'Ronoj Ramaj' : 'Ramaj pa Ja re kunanik' ?></div><div class="info-value"><?= formatDuration($end - $start) ?></div></div>
            <div><div class="label">Jalwachinik Ja</div><div class="info-value"><?= count(array_filter($events, function($e) { return $e['type'] === 'move'; })) ?></div></div>
        </div>
        <div style="border-left:3px solid #c8c8c8;margin-left:8px;padding-left:22px;">
            <?php foreach ($events as $i => $e):
                $color = $colors[$e['type']] ?? '#555';
                $next = $events[$i + 1]['time'] ?? null;
                $isLast = ($next === null);
                $stayEnd = $next ? strtotime($next) : ($isDischarged ? null : time());
            ?>
                <div style="position:relative;padding-bottom:18px;">
                    <span style="position:absolute;left:-31px;top:4px;width:15px;height:15px;border-radius:50%;background:<?= $color ?>;border:3px solid #fff;box-shadow:0 0 0 1px <?= $color ?>;"></span>
                    <div style="font-weight:600;"><?= htmlspecialchars($e['title']) ?></div>
                    <div style="font-size:0.9em;opacity:0.75;"><?= formatDate($e['time']) ?><?= !empty($e['by']) ? ' · ' . htmlspecialchars((!empty($e['by_name']) && $e['by_name'] !== $e['by']) ? $e['by_name'] . ' (' . $e['by'] . ')' : $e['by']) : '' ?></div>
                    <?php if (!empty($e['detail'])): ?><div style="font-size:0.95em;margin-top:2px;"><?= htmlspecialchars($e['detail']) ?></div><?php endif; ?>
                    <?php if ($e['type'] !== 'discharge' && $stayEnd): ?>
                        <div style="font-size:0.85em;opacity:0.65;margin-top:2px;">
                            <?= $isLast ? 'Ramaj kamik k’a kamik: ' : 'Xk’oji: ' ?><?= formatDuration($stayEnd - strtotime($e['time'])) ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
        <?php if ($legacy): ?>
            <div style="font-size:0.8em;opacity:0.6;">Xb’an chi jun mul pa ri tz’ib’ re chak (ri yawab’ xok nab’e chuwach ri ub’e q’ij).</div>
        <?php endif; ?>
    </div>
    <?php
}

// ==================== TIMELINE OVERVIEW (SEARCHABLE) ====================
function showTimelines() {
    if (!can('view')) {
        showError('Xq’ataj ri b’ixikil');
        exit;
    }

    $q = trim($_GET['search'] ?? '');
    $type = $_GET['search_type'] ?? 'all';
    $status = $_GET['status'] ?? 'all';
    $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
    $perPage = MAX_PATIENTS_PER_PAGE;
    $canArchive = can('admin') || can('logs');

    // current patients (+ patients discharged today), then archived ones for admin/logs
    $patients = [];
    $seen = [];
    foreach (readJSONFile($GLOBALS['pF']) as $pt) {
        if (!is_array($pt) || empty($pt['id']) || isset($seen[$pt['id']])) continue;
        $pt['_archived'] = false;
        $patients[] = $pt;
        $seen[$pt['id']] = true;
    }
    if ($canArchive) {
        foreach (getDischargedPatients() as $pt) {
            if (!is_array($pt) || empty($pt['id']) || isset($seen[$pt['id']])) continue;
            $pt['_archived'] = true;
            $patients[] = $pt;
            $seen[$pt['id']] = true;
        }
    }

    $rows = [];
    foreach ($patients as $pt) {
        $st = $pt['status'] ?? 'unknown';
        if ($status === 'admitted' && $st !== 'admitted') continue;
        if ($status === 'discharged' && $st !== 'discharged') continue;

        $events = getPatientTimeline($pt);
        $deptName = getDeptName($pt['department'] ?? '');

        if ($q !== '') {
            $hay = [
                'name'       => [$pt['name'] ?? ''],
                'id'         => [$pt['id'] ?? ''],
                'room'       => [$pt['room_num'] ?? ''],
                'department' => [$deptName],
                'user'       => [],
                'event'      => [],
            ];
            foreach ($events as $e) {
                $hay['user'][]  = $e['by'] ?? '';
                $hay['user'][]  = $e['by_name'] ?? '';
                $hay['room'][]  = ($e['title'] ?? '') . ' ' . ($e['detail'] ?? '');
                $hay['department'][] = $e['detail'] ?? '';
                $hay['event'][] = ($e['type'] ?? '') . ' ' . ($e['title'] ?? '') . ' ' . ($e['detail'] ?? '');
            }
            $fields = $type === 'all' ? array_merge(...array_values($hay)) : ($hay[$type] ?? []);
            $match = false;
            foreach ($fields as $f) {
                if ($f !== '' && stripos((string)$f, $q) !== false) { $match = true; break; }
            }
            if (!$match) continue;
        }

        $moves = 0;
        foreach ($events as $e) if (($e['type'] ?? '') === 'move') $moves++;
        $last = $events ? end($events)['time'] : ($pt['admit_date'] ?? '');
        $rows[] = ['patient' => $pt, 'moves' => $moves, 'last' => $last, 'dept' => $deptName];
    }

    usort($rows, function ($a, $b) { return strtotime($b['last']) <=> strtotime($a['last']); });

    $total = count($rows);
    $totalPages = max(1, (int)ceil($total / $perPage));
    $page = min($page, $totalPages);
    $pageRows = array_slice($rows, ($page - 1) * $perPage, $perPage);
    $qs = http_build_query(['action' => 'timelines', 'search' => $q, 'search_type' => $type, 'status' => $status]);

    showHeader();
?>
    <div class="container">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:var(--spacing-lg); flex-wrap:wrap; gap:var(--spacing-md);">
            <div>
                <h2 style="margin-bottom:var(--spacing-xs);">Ub’e q’ij Yawab’</h2>
                <p class="text-muted">Chatzukuj jalwachinik ja chawilampe jachin xjalwachin ri yawab’ rachi’ jampa’.</p>
            </div>
            <div class="btn-group">
                <a href="?action=patients" class="btn btn-primary">Yawab’ Kamik</a>
            </div>
        </div>

        <div class="card" style="margin-bottom:var(--spacing-xl);">
            <h3>Chatzukuj Ub’e q’ij</h3>
            <form method="GET" action="">
                <input type="hidden" name="action" value="timelines">
                <div class="filter-bar" style="margin:0;">
                    <div class="filter-group" style="flex:2;">
                        <label for="search">Chatzukuj:</label>
                        <input type="text" id="search" name="search" value="<?= htmlspecialchars($q) ?>" placeholder="Yawab’, ID, ja, k’olb’al, okisanel, k’ulmatajem...">
                    </div>
                    <div class="filter-group">
                        <label for="search_type">Pa:</label>
                        <select id="search_type" name="search_type">
                            <option value="all" <?= $type == 'all' ? 'selected' : '' ?>>Ronoj Ucholaj</option>
                            <option value="name" <?= $type == 'name' ? 'selected' : '' ?>>Ub’i’ Yawab’</option>
                            <option value="id" <?= $type == 'id' ? 'selected' : '' ?>>ID Yawab’</option>
                            <option value="room" <?= $type == 'room' ? 'selected' : '' ?>>Ajilab’al re Ja</option>
                            <option value="department" <?= $type == 'department' ? 'selected' : '' ?>>Ja</option>
                            <option value="user" <?= $type == 'user' ? 'selected' : '' ?>>Xjalwachixik / Xok rumal</option>
                            <option value="event" <?= $type == 'event' ? 'selected' : '' ?>>K’ulmatajem (Xok / Xjalwachixik / Xel)</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label for="status">Wachinem:</label>
                        <select id="status" name="status">
                            <option value="all" <?= $status == 'all' ? 'selected' : '' ?>>Ronoj</option>
                            <option value="admitted" <?= $status == 'admitted' ? 'selected' : '' ?>>Xok</option>
                            <option value="discharged" <?= $status == 'discharged' ? 'selected' : '' ?>>Xel</option>
                        </select>
                    </div>
                    <div class="btn-group">
                        <button type="submit" class="btn btn-primary">Chatzukuj</button>
                        <?php if ($q !== '' || $status !== 'all'): ?>
                            <a href="?action=timelines" class="btn">Chesaj</a>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
            <div style="margin-top:var(--spacing-md);">
                <strong><?= $total ?></strong> ub’e q’ij yawab’<?= $q !== '' ? ' junam rik’in &quot;' . htmlspecialchars($q) . '&quot;' : '' ?>
            </div>
        </div>

        <?php if (empty($pageRows)): ?>
            <div class="empty-state">
                <p>Maja ub’e q’ij xriqitaj.</p>
                <?php if ($q !== '' || $status !== 'all'): ?><p><a href="?action=timelines" class="btn btn-primary">Chesaj Tzukunik</a></p><?php endif; ?>
            </div>
        <?php else: ?>
            <?php foreach ($pageRows as $row):
                $pt = $row['patient'];
                $isArchived = !empty($pt['_archived']);
                $st = $pt['status'] ?? 'unknown';
                $viewUrl = $isArchived ? '?action=view_discharged&id=' . urlencode($pt['id']) : '?action=view&id=' . urlencode($pt['id']);
                $open = ($q !== '' || $total <= 5);
            ?>
                <details class="card" style="margin-bottom:var(--spacing-lg);" <?= $open ? 'open' : '' ?>>
                    <summary style="cursor:pointer; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:var(--spacing-md);">
                        <span>
                            <strong><?= htmlspecialchars($pt['name'] ?? 'Man etaman ta') ?></strong>
                            <span class="text-muted"> &middot; ID <?= htmlspecialchars($pt['id']) ?></span>
                            <span class="text-muted"> &middot; <?= htmlspecialchars($row['dept']) ?></span>
                            <?php if (!empty($pt['room_num'])): ?><span class="text-muted"> &middot; Ja <?= htmlspecialchars($pt['room_num']) ?></span><?php endif; ?>
                        </span>
                        <span>
                            <span class="text-muted"><?= $row['moves'] ?> jalwachinik ja</span>
                            <span class="status-badge <?= $st === 'discharged' ? 'status-discharged' : 'status-admitted' ?>"><?= $isArchived ? 'Yakom' : htmlspecialchars(ucfirst($st)) ?></span>
                        </span>
                    </summary>
                    <?php renderPatientTimeline($pt); ?>
                    <div style="margin-top:var(--spacing-md);">
                        <a href="<?= $viewUrl ?>" class="btn btn-sm">Chawila Yawab’</a>
                    </div>
                </details>
            <?php endforeach; ?>

            <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?><a href="?<?= $qs ?>&page=<?= $page - 1 ?>" class="page-link">Nab’e</a><?php endif; ?>
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <a href="?<?= $qs ?>&page=<?= $i ?>" class="page-link <?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
                    <?php endfor; ?>
                    <?php if ($page < $totalPages): ?><a href="?<?= $qs ?>&page=<?= $page + 1 ?>" class="page-link">Kepe</a><?php endif; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
<?php
    showFooter();
}

// ==================== ACTIVITY LOG (MySQL) ====================
// Every entry is one row in `activity_log`. If MySQL cannot be reached the line is appended to
// ACTIVITY_LOG (the old file) instead, and importActivityLogFiles() moves it into the table on
// the next page load, so no entry is lost.

// Patient IDs look like P00289F0 (same pattern the photo log has always used)
function logPatientId($msg) {
    return preg_match('/\b(P[0-9A-F]{7})\b/', (string)$msg, $m) ? $m[1] : null;
}

// Category used for filtering on the System Logs page
function logType($msg) {
    $first = strtolower((string)strtok((string)$msg, ' :'));
    $map = [
        'admitted' => 'admit', 'discharged' => 'discharge', 'prescription' => 'rx',
        'login' => 'login', 'logout' => 'login', 'moved' => 'move', 'updated' => 'edit',
        'photo' => 'photo', 'auto-detachment' => 'system', 'weekly' => 'system', 'de-attach' => 'system', 'activity' => 'system',
        'mfa' => 'login', 'soft' => 'login', 'admin' => 'admin', 'medication' => 'edit',
        'added' => 'edit', 'edited' => 'edit', 'deleted' => 'edit',
        // K’iche’ log messages (first word, lowercase)
        'elem' => 'login', 'tz’ib’' => 'system', 'xjalwachixik' => 'move', 'xel' => 'discharge',
        'wachib’al' => 'photo', 'wujkunab’al' => 'rx', 'xk’ak’arisaxik' => 'edit', 'xtz’aqatisaxik' => 'edit',
        'kunab’al' => 'edit', 'ri' => 'system', 'xch’ajch’ojirisaxik' => 'system', 'sach' => 'system',
        'yakb’al' => 'system', 'pixab' => 'system', 'xesaxik' => 'edit', 'xutzirisaxik' => 'edit',
        'xok' => 'admit',
    ];
    $type = $map[$first] ?? 'other';
    if (stripos($msg, 'fail') !== false || stripos($msg, 'denied') !== false || stripos($msg, 'blocked') !== false
        || stripos($msg, 'invalid') !== false || stripos($msg, 'rate limit') !== false || strpos($msg, 'ERROR') === 0
        || strpos($msg, 'WARNING') === 0
        || strpos($msg, 'SACH') === 0
        || strpos($msg, 'PIXAB') === 0
        || stripos($msg, 'man xel ta') !== false
        || stripos($msg, 'man utz ta') !== false
        || stripos($msg, 'xq’ataj') !== false
        || stripos($msg, 'k’i taqanik') !== false
        || stripos($msg, 'uk’isik taqanik') !== false) {
        $type = 'alert';
    }
    return $type;
}

function logMsg($m) {
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $user = $_SESSION['user']['user'] ?? 'guest';
    $m = (string)$m;
    try {
        static $stmt = null;
        if ($stmt === null) {
            $stmt = db()->prepare("INSERT INTO activity_log (logged_at, username, ip, type, patient_id, message)
                                   VALUES (?, ?, ?, ?, ?, ?)");
        }
        $stmt->execute([date('Y-m-d H:i:s'), substr($user, 0, 60), substr($ip, 0, 45),
                        logType($m), logPatientId($m), $m]);
    } catch (Throwable $e) {
        // MySQL unavailable: keep the entry in the fallback file, it is imported later
        @file_put_contents(ACTIVITY_LOG, date('[Y-m-d H:i:s] ') . "[$user@$ip] $m" . PHP_EOL, FILE_APPEND | LOCK_EX);
    }
}

// Imports activity.log, its rotated .bak files and any fallback lines into `activity_log`.
// Each file is first renamed (atomic), so two requests can never import the same file twice.
function importActivityLogFiles() {
    $base = ACTIVITY_LOG;
    $files = array_merge(glob($base . '.*.bak') ?: [], file_exists($base) ? [$base] : []);
    if (!$files) return 0;

    $total = 0;
    try {
        $pdo = db();
        $stmt = $pdo->prepare("INSERT INTO activity_log (logged_at, username, ip, type, patient_id, message)
                               VALUES (?, ?, ?, ?, ?, ?)");
        foreach ($files as $file) {
            if (!is_file($file) || filesize($file) === 0) continue;
            $work = $file . '.importing-' . bin2hex(random_bytes(4));
            if (!@rename($file, $work)) continue;          // another request took it
            $fh = fopen($work, 'r');
            if (!$fh) { @rename($work, $file); continue; }
            $pdo->beginTransaction();
            try {
                $n = 0;
                while (($line = fgets($fh)) !== false) {
                    if (trim($line) === '') continue;
                    $e = parseLogLine($line);
                    $ts = $e['time'] !== '' ? strtotime($e['time']) : false;
                    $stmt->execute([
                        date('Y-m-d H:i:s', $ts ?: filemtime($work)),
                        substr($e['user'] !== '' ? $e['user'] : 'unknown', 0, 60),
                        substr($e['ip'], 0, 45),
                        logType($e['msg']),
                        logPatientId($e['msg']),
                        $e['msg'],
                    ]);
                    $n++;
                }
                $pdo->commit();
                fclose($fh);
                @rename($work, $file . '.imported-' . date('Ymd-His'));   // keep a copy, nothing is deleted
                $total += $n;
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                fclose($fh);
                @rename($work, $file);                                 // retry on a later page load
                throw $e;
            }
        }
    } catch (Throwable $e) {
        return $total;   // MySQL down: files stay in place
    }
    if ($total > 0) logMsg("Tz’ib’ re chak: xok $total cholaj pa wuj pa activity_log");
    return $total;
}

// Removes entries older than LOG_RETENTION_DAYS, at most once a day. 0 or less = keep everything.
function purgeActivityLog() {
    if (!defined('LOG_RETENTION_DAYS') || (int)LOG_RETENTION_DAYS <= 0) return;
    $today = date('Y-m-d');
    try {
        if (dbKvGet('activity_log_purged') === $today) return;
        dbKvSet('activity_log_purged', $today);
        $stmt = db()->prepare("DELETE FROM activity_log WHERE logged_at < ?");
        $stmt->execute([date('Y-m-d H:i:s', time() - (int)LOG_RETENTION_DAYS * 86400)]);
        if ($stmt->rowCount() > 0) logMsg("Tz’ib’ re chak: xesaxik {$stmt->rowCount()} ojer tz’ib’ chi " . (int)LOG_RETENTION_DAYS . " q’ij");
    } catch (Throwable $e) {
        // ignore: retried tomorrow
    }
}

// Newest first. $filter: '' = everything, 'photo' = photo-related entries only.
function getActivityLog($limit = 5000, $filter = '') {
    $limit = max(1, (int)$limit);
    $sql = "SELECT id, logged_at, username, ip, type, patient_id, message FROM activity_log";
    if ($filter === 'photo') $sql .= " WHERE type = 'photo' OR message LIKE '%photo%'";
    $sql .= " ORDER BY logged_at DESC, id DESC LIMIT $limit";
    $out = [];
    try {
        foreach (db()->query($sql) as $r) {
            $out[] = [
                'time' => $r['logged_at'], 'user' => $r['username'], 'ip' => (string)$r['ip'],
                'msg' => $r['message'], 'type' => $r['type'] ?: 'other', 'patient_id' => $r['patient_id'],
                'line' => '[' . $r['logged_at'] . '] [' . $r['username'] . '@' . $r['ip'] . '] ' . $r['message'],
            ];
        }
    } catch (Throwable $e) {
        // table missing or MySQL down: show nothing rather than a fatal error
    }
    return $out;
}

function countActivityLog() {
    try {
        return (int)db()->query("SELECT COUNT(*) FROM activity_log")->fetchColumn();
    } catch (Throwable $e) {
        return 0;
    }
}

function verifyCSRF($token) {
    return hash_equals($_SESSION['csrf_token'] ?? '', $token);
}

function validatePassword($password) {
    if (strlen($password) < PASSWORD_MIN_LENGTH) return false;
    if (PASSWORD_REQUIRE_UPPER && !preg_match('/[A-Z]/', $password)) return false;
    if (PASSWORD_REQUIRE_LOWER && !preg_match('/[a-z]/', $password)) return false;
    if (PASSWORD_REQUIRE_NUMBER && !preg_match('/[0-9]/', $password)) return false;
    if (PASSWORD_REQUIRE_SPECIAL && !preg_match('/[^A-Za-z0-9]/', $password)) return false;
    return true;
}

function checkRateLimit($username) {
    global $rateLimitFile;
    $attempts = [];
    if (file_exists($rateLimitFile)) {
        $attempts = json_decode(file_get_contents($rateLimitFile), true) ?: [];
    }

    $key = md5($username . $_SERVER['REMOTE_ADDR']);
    $now = time();

    foreach ($attempts as $k => $data) {
        if ($data['time'] < $now - RATE_LIMIT_WINDOW) {
            unset($attempts[$k]);
        }
    }

    $userAttempts = 0;
    foreach ($attempts as $data) {
        if ($data['key'] === $key) {
            $userAttempts++;
        }
    }

    if ($userAttempts >= RATE_LIMIT_ATTEMPTS) {
        return false;
    }

    $attempts[] = [
        'key' => $key,
        'time' => $now
    ];

    file_put_contents($rateLimitFile, json_encode($attempts));
    return true;
}

function readJSONFile($filename) {
    // Application data is stored in MySQL (db.php); other files are still read from disk
    if (dbIsManaged($filename)) {
        return dbRead($filename);
    }
    if (!file_exists($filename)) {
        return [];
    }
    
    $fp = fopen($filename, 'r');
    if (!$fp) {
        logMsg("SACH: Man xjaqataj ta ri wuj: $filename");
        return [];
    }
    
    $data = '';
    if (flock($fp, LOCK_SH)) {
        $data = fread($fp, filesize($filename) ?: 1);
        flock($fp, LOCK_UN);
    }
    fclose($fp);
    
    if (empty($data)) {
        return [];
    }
    
    if ($filename === $GLOBALS['pF']) {
        $decoded = json_decode($data, true);
        if ($decoded !== null && is_array($decoded)) {
            return filterDetachedPatients($decoded);
        }
        
        $decrypted = rot47_decrypt($data);
        $decoded = json_decode($decrypted, true);
        
        if ($decoded !== null && is_array($decoded)) {
            return filterDetachedPatients($decoded);
        }
        
        logMsg("SACH: Man xetamax ta ri retal yawab’, katzalij jun cholaj maja k’o");
        return [];
    }
    
    $decoded = json_decode($data, true);
    return is_array($decoded) ? $decoded : [];
}

function writeJSONFile($filename, $data) {
    if (!is_array($data)) {
        $data = [];
    }
    if (dbIsManaged($filename)) {
        dbWrite($filename, $data);
        return;
    }
    if ($filename === $GLOBALS['pF']) {
        $data = array_values($data);
    }
    
    $fp = fopen($filename, 'w');
    if (flock($fp, LOCK_EX)) {
        if ($filename === $GLOBALS['pF'] && ENCRYPT_PATIENTS) {
            $encrypted = rot47_encrypt(json_encode($data, JSON_PRETTY_PRINT));
            fwrite($fp, $encrypted);
        } else {
            fwrite($fp, json_encode($data, JSON_PRETTY_PRINT));
        }
        flock($fp, LOCK_UN);
    }
    fclose($fp);
}

// ==================== PHOTO FUNCTIONS ====================
function ensurePhotoScript() {
    // (Re)create get_photo.php when missing or when it is an old version (v1 had a hardcoded path)
    $target = __DIR__ . '/get_photo.php';
    if (file_exists($target) && strpos((string)@file_get_contents($target), 'get_photo.php v3') !== false) {
        return;
    }
    $script = <<<'PHPSCRIPT'
<?php
// get_photo.php v2 - serves patient/room photos (PNG). Do not hardcode paths here:
// PHOTO_DIR comes from config.php and follows wherever the application is installed.
ob_start();
@ini_set('display_errors', '0');
session_start();
require_once __DIR__ . '/config.php';
session_write_close();   // do not block parallel image requests on the session lock
ob_clean();

function photo_fail($code, $msg) {
    while (ob_get_level()) ob_end_clean();
    http_response_code($code);
    header('Content-Type: text/plain; charset=utf-8');
    echo $msg;
    exit;
}

if (!isset($_SESSION['user'])) photo_fail(403, 'Xq’ataj ri okib’al');

$patientId = isset($_GET['patient']) ? preg_replace('/[^a-zA-Z0-9_-]/', '', $_GET['patient']) : '';
$roomNum   = isset($_GET['room'])    ? preg_replace('/[^a-zA-Z0-9_-]/', '', $_GET['room'])    : '';
$filename  = isset($_GET['file'])    ? basename($_GET['file']) : '';

if ($filename === '' || ($patientId === '' && $roomNum === '')) photo_fail(400, 'Parametro man utz ta');
if (!preg_match('/^[A-Za-z0-9-]+_\d+(_thumb)?\.png$/', $filename)) photo_fail(400, 'Ub’i’ wuj man utz ta');
if ($patientId !== '' && strpos($filename, $patientId . '_') !== 0) photo_fail(400, 'Ri wachib’al man rech ta we yawab’ ri’');

$base = rtrim(PHOTO_DIR, '/\\') . DIRECTORY_SEPARATOR;
$filepath = null;

// 1) the room given in the link
if ($roomNum !== '') {
    $try = $base . 'room_' . $roomNum . DIRECTORY_SEPARATOR . $filename;
    if (is_file($try)) $filepath = $try;
}
// 2) otherwise (or when the patient was moved to another room) search every room folder
if ($filepath === null) {
    foreach (glob($base . 'room_*', GLOB_ONLYDIR) ?: [] as $dir) {
        $try = $dir . DIRECTORY_SEPARATOR . $filename;
        if (is_file($try)) { $filepath = $try; break; }
    }
}

if ($filepath === null) photo_fail(404, 'Man xriqitaj ta ri wachib’al');

// the resolved file must really be inside the photo folder
$real = realpath($filepath);
$root = realpath($base);
if ($real === false || $root === false || strpos($real, $root) !== 0) photo_fail(403, 'Xq’ataj ri okib’al');

$info = @getimagesize($real);
if (!$info || $info[2] !== IMAGETYPE_PNG) photo_fail(415, 'Ruk’ojlem wachib’al man utz ta');

while (ob_get_level()) ob_end_clean();
header('Content-Type: image/png');
header('Content-Length: ' . filesize($real));
header('Cache-Control: private, max-age=86400');
readfile($real);
exit;
PHPSCRIPT;
    @file_put_contents($target, $script);
    @chmod($target, 0644);
}

function photoUploadErrorMessage($code) {
    switch ($code) {
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE:
            return 'Ri wachib’al nim chuwach ri kuya ri servidor (' . ini_get('upload_max_filesize') . '). Chacha’ jun wachib’al ch’uti.';
        case UPLOAD_ERR_PARTIAL:    return 'Ri wachib’al xa jun peraj xjoten. Chatojtob’ej chi jun mul.';
        case UPLOAD_ERR_NO_FILE:    return 'Maja k’o wachib’al cha’om';
        case UPLOAD_ERR_NO_TMP_DIR: return 'Ri servidor maja k’o ucarpeta che ujotesaxik (upload_tmp_dir)';
        case UPLOAD_ERR_CANT_WRITE: return 'Ri servidor man xutz’ib’aj ta ri wachib’al';
        default: return 'Sach re jotesaxik (kod ' . (int)$code . ')';
    }
}

/**
 * Decode any uploaded image (JPG/PNG/WebP), fix phone rotation, centre-crop to a square,
 * resize to $size x $size and write a small PNG (256-colour palette) to $destination.
 */
function savePhotoResized($source, $destination, $size = 200) {
    $dim = @getimagesize($source);
    if (!$dim || ($dim[0] * $dim[1]) > 40000000) return false;   // too large to decode safely
    @ini_set('memory_limit', '256M');

    $src = @imagecreatefromstring(file_get_contents($source));
    if (!$src) return false;

    // Phone cameras store rotation in EXIF (JPEG only)
    if (($dim[2] ?? 0) === IMAGETYPE_JPEG && function_exists('exif_read_data')) {
        $exif = @exif_read_data($source);
        $orient = $exif['Orientation'] ?? 1;
        $angle = [3 => 180, 6 => -90, 8 => 90][$orient] ?? 0;
        if ($angle) {
            $rot = imagerotate($src, $angle, 0);
            if ($rot) { imagedestroy($src); $src = $rot; }
        }
    }

    $w = imagesx($src);
    $h = imagesy($src);
    $side = min($w, $h);
    $srcX = (int)(($w - $side) / 2);
    $srcY = (int)(($h - $side) / 2);

    $dst = imagecreatetruecolor($size, $size);
    imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255));   // flatten transparency on white
    imagecopyresampled($dst, $src, 0, 0, $srcX, $srcY, $size, $size, $side, $side);
    imagedestroy($src);

    // 256-colour palette keeps a 200x200 photo around 30-50 KB instead of ~100 KB
    imagetruecolortopalette($dst, true, 256);
    $ok = imagepng($dst, $destination, 9);
    imagedestroy($dst);
    return (bool)$ok;
}

function handlePhotoUpload($patientId, $roomNum) {
    if (!isset($_FILES['patient_photo'])) {
        return ['success' => false, 'message' => 'Maja k’o wachib’al xjotesax'];
    }
    if ($_FILES['patient_photo']['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'message' => photoUploadErrorMessage($_FILES['patient_photo']['error'])];
    }

    $file = $_FILES['patient_photo'];

    if ($file['size'] > MAX_PHOTO_SIZE) {
        return ['success' => false, 'message' => 'Ri wachib’al nim. Nim nimal: ' . getMaxUploadSize()];
    }

    $mime = '';
    if (function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
    } else {
        $info = @getimagesize($file['tmp_name']);
        $mime = $info['mime'] ?? '';
    }

    $allowed = is_array(ALLOWED_PHOTO_TYPES) ? ALLOWED_PHOTO_TYPES : (array)unserialize(ALLOWED_PHOTO_TYPES);
    if (!in_array($mime, $allowed, true) || !@getimagesize($file['tmp_name'])) {
        return ['success' => false, 'message' => 'Ruk’ojlem wachib’al man kak’ul ta (' . ($mime ?: 'man etaman ta') . '). Chakuj PNG o JPG.'];
    }

    $roomDir = PHOTO_DIR . 'room_' . preg_replace('/[^a-zA-Z0-9_-]/', '', $roomNum) . '/';
    if (!file_exists($roomDir) && !@mkdir($roomDir, 0755, true)) {
        return ['success' => false, 'message' => 'Ri servidor man kub’an ta ri carpeta (chatzukuj ri b’ixikil pa data/patient_photos)'];
    }
    if (!is_writable($roomDir)) {
        return ['success' => false, 'message' => 'Ri carpeta man katz’ib’ax ta (chatzukuj ri b’ixikil pa data/patient_photos)'];
    }

    $ts = time();
    $filename = $patientId . '_' . $ts . '.png';
    $filepath = $roomDir . $filename;

    // Every photo is centre-cropped and resized to 200x200 before it touches the disk
    if (!extension_loaded('gd')) {
        return ['success' => false, 'message' => 'PHP GD man yakom ta, man kajalwachix ta ri nimal wachib’al'];
    }
    $saved = savePhotoResized($file['tmp_name'], $filepath);

    if ($saved) {
        @chmod($filepath, 0644);
        // No separate thumbnail needed: the stored photo is already small
        return [
            'success' => true,
            'path' => $filepath,
            'filename' => $filename,
            'room_dir' => $roomDir
        ];
    }

    return ['success' => false, 'message' => 'Ri yakik wachib’al man xel ta'];
}

function createThumbnail($source, $destination, $size = PHOTO_THUMB_SIZE) {
    if (!extension_loaded('gd')) return false;
    
    $dim = @getimagesize($source);
    if (!$dim || ($dim[0] * $dim[1]) > 40000000) return false;   // too large to decode safely
    list($width, $height) = $dim;
    @ini_set('memory_limit', '256M');
    $sourceImg = @imagecreatefrompng($source);
    if (!$sourceImg) return false;
    $thumb = imagecreatetruecolor($size, $size);
    
    imagealphablending($thumb, false);
    imagesavealpha($thumb, true);
    
    $transparent = imagecolorallocatealpha($thumb, 255, 255, 255, 127);
    imagefilledrectangle($thumb, 0, 0, $size, $size, $transparent);
    
    $srcX = 0;
    $srcY = 0;
    $srcW = $width;
    $srcH = $height;
    
    if ($width > $height) {
        $srcX = ($width - $height) / 2;
        $srcW = $height;
    } else {
        $srcY = ($height - $width) / 2;
        $srcH = $width;
    }
    
    imagecopyresampled($thumb, $sourceImg, 0, 0, $srcX, $srcY, $size, $size, $srcW, $srcH);
    imagepng($thumb, $destination, 9);
    
    imagedestroy($thumb);
    imagedestroy($sourceImg);
    
    return true;
}

function getPatientPhotos($patientId = null, $roomNum = null) {
    $photos = [];
    $photoDir = PHOTO_DIR;

    if (!file_exists($photoDir)) {
        return $photos;
    }

    if ($patientId) {
        $roomDirs = glob($photoDir . 'room_*', GLOB_ONLYDIR);
        if (is_array($roomDirs)) {
            foreach ($roomDirs as $roomDir) {
                $files = glob($roomDir . '/' . $patientId . '_*.png');
                if (is_array($files)) {
                    foreach ($files as $file) {
                        if (is_file($file) && !preg_match('/_thumb\.png$/', $file)) {
                            $filename = basename($file);
                            $room = str_replace('room_', '', basename($roomDir));
                            $photos[] = [
                                'path' => $file,
                                'filename' => $filename,
                                'patient_id' => $patientId,
                                'room_num' => $room,
                                'uploaded' => filemtime($file),
                                'size' => filesize($file),
                                'url' => 'get_photo.php?patient=' . urlencode($patientId) . '&file=' . urlencode($filename)
                            ];
                        }
                    }
                }
            }
        }
    } elseif ($roomNum) {
        $roomDir = $photoDir . 'room_' . preg_replace('/[^a-zA-Z0-9_-]/', '', $roomNum) . '/';
        if (file_exists($roomDir)) {
            $files = glob($roomDir . '*.png');
            if (is_array($files)) {
                foreach ($files as $file) {
                    if (is_file($file) && !preg_match('/_thumb\.png$/', $file)) {
                        $filename = basename($file);
                        $pid = explode('_', $filename)[0];
                        $photos[] = [
                            'path' => $file,
                            'filename' => $filename,
                            'patient_id' => $pid,
                            'room_num' => $roomNum,
                            'uploaded' => filemtime($file),
                            'size' => filesize($file),
                            'url' => 'get_photo.php?room=' . urlencode($roomNum) . '&file=' . urlencode($filename)
                        ];
                    }
                }
            }
        }
    }

    if (is_array($photos)) {
        usort($photos, function ($a, $b) {
            return ($b['uploaded'] ?? 0) - ($a['uploaded'] ?? 0);
        });
    }

    return $photos;
}

function getPatientPhotoCount($patientId) {
    $photos = getPatientPhotos($patientId);
    return is_array($photos) ? count($photos) : 0;
}

function getAllPhotos() {
    $allPhotos = [];
    $photoDir = PHOTO_DIR;
    if (!file_exists($photoDir)) return $allPhotos;

    $roomDirs = glob($photoDir . 'room_*', GLOB_ONLYDIR);
    if (is_array($roomDirs)) {
        foreach ($roomDirs as $roomDir) {
            $files = glob($roomDir . '/*.png');
            if (is_array($files)) {
                foreach ($files as $file) {
                    if (is_file($file) && !preg_match('/_thumb\.png$/', $file)) {
                        $filename = basename($file);
                        $pid = explode('_', $filename)[0];
                        $roomNum = str_replace('room_', '', basename($roomDir));
                        $allPhotos[] = [
                            'path' => $file,
                            'filename' => $filename,
                            'patient_id' => $pid,
                            'room_num' => $roomNum,
                            'uploaded' => filemtime($file),
                            'size' => filesize($file),
                            'url' => 'get_photo.php?patient=' . urlencode($pid) . '&file=' . urlencode($filename)
                        ];
                    }
                }
            }
        }
    }
    return $allPhotos;
}

function movePatientPhotos($patientId, $oldRoomNum, $newRoomNum) {
    if (!$patientId || !$oldRoomNum || !$newRoomNum) {
        return ['success' => false, 'message' => 'Maja k’o parametro'];
    }

    $photoDir = PHOTO_DIR;
    $oldRoomDir = $photoDir . 'room_' . preg_replace('/[^a-zA-Z0-9_-]/', '', $oldRoomNum) . '/';
    $newRoomDir = $photoDir . 'room_' . preg_replace('/[^a-zA-Z0-9_-]/', '', $newRoomNum) . '/';

    if (!file_exists($oldRoomDir)) {
        return ['success' => true, 'message' => 'Maja k’o wachib’al che jalwachinik', 'moved' => 0];
    }

    if (!file_exists($newRoomDir)) {
        mkdir($newRoomDir, 0755, true);
    }

    $files = glob($oldRoomDir . $patientId . '_*.png');
    $moved = 0;

    if (is_array($files)) {
        foreach ($files as $file) {
            if (is_file($file)) {
                $filename = basename($file);
                $newPath = $newRoomDir . $filename;
                if (rename($file, $newPath)) {
                    chmod($newPath, 0644);
                    $moved++;
                }
            }
        }
    }

    if ($moved > 0) {
        logMsg("Xjalwachixik $moved wachib’al yawab’ $patientId pa ja $oldRoomNum pa ja $newRoomNum");
        return ['success' => true, 'message' => "Xjalwachixik $moved wachib’al", 'moved' => $moved];
    }

    return ['success' => true, 'message' => 'Maja k’o wachib’al xriqitaj che jalwachinik', 'moved' => 0];
}

function cleanupOldPhotos() {
    $photoDir = PHOTO_DIR;
    $cutoff = time() - (PHOTO_RETENTION_DAYS * 24 * 60 * 60);
    $cleaned = 0;

    if (file_exists($photoDir)) {
        $files = glob($photoDir . '*/*');
        if (is_array($files)) {
            foreach ($files as $file) {
                if (is_file($file) && filemtime($file) < $cutoff) {
                    if (unlink($file)) {
                        $cleaned++;
                    }
                }
            }
        }
    }

    if ($cleaned > 0) {
        logMsg("Xch’ajch’ojirisaxik $cleaned wachib’al yawab’ xk’is uq’ijol");
    }
}

function debugPhotoSystem() {
    if (!can('admin')) {
        showError('Xq’ataj ri b’ixikil');
        exit;
    }
    
    showHeader();
    $photoDir = PHOTO_DIR;
    $allPhotos = getAllPhotos();
    
    echo '<div class="container">';
    echo '<h2>Debug Ucholajil Wachib’al</h2>';
    
    echo '<div class="card">';
    echo '<h3>Ub’antajik Carpeta</h3>';
    echo '<pre style="background:var(--bg-tertiary); padding:var(--spacing-md); overflow:auto; border:1px solid var(--border-color); border-radius:var(--border-radius);">';
    if (file_exists($photoDir)) {
        echo "Carpeta wachib’al k’o: JE’\n";
        echo "Ub’e carpeta wachib’al: " . realpath($photoDir) . "\n";
        echo "B’ixikil: " . substr(sprintf('%o', fileperms($photoDir)), -4) . "\n";
        
        $roomDirs = glob($photoDir . 'room_*', GLOB_ONLYDIR);
        echo "Carpeta re ja xriqitaj: " . (is_array($roomDirs) ? count($roomDirs) : 0) . "\n";
        if (is_array($roomDirs)) {
            foreach ($roomDirs as $roomDir) {
                echo "  - " . basename($roomDir) . "\n";
                $files = glob($roomDir . '/*.png');
                if (is_array($files)) {
                    foreach ($files as $file) {
                        echo "      " . basename($file) . " (" . round(filesize($file)/1024, 1) . "KB)\n";
                    }
                }
            }
        }
    } else {
        echo "Maja k’o carpeta wachib’al\n";
    }
    echo '</pre>';
    echo '</div>';
    
    echo '<div class="card">';
    echo '<h3>Wachib’al chi jujun yawab’</h3>';
    $p = readJSONFile($GLOBALS['pF']);
    echo '<div class="table-container">';
    echo '<table>';
    echo '<tr><th>ID Yawab’</th><th>B’i’aj</th><th>Achi/Ixoq</th><th>Jarupa Wachib’al</th><th>Chak</th></tr>';
    if (is_array($p)) {
        foreach ($p as $patient) {
            if (is_array($patient) && isset($patient['id'])) {
                $count = getPatientPhotoCount($patient['id']);
                echo '<tr>';
                echo '<td>' . htmlspecialchars($patient['id']) . '</td>';
                echo '<td>' . htmlspecialchars($patient['name'] ?? 'Man etaman ta') . '</td>';
                echo '<td>' . getGenderName($patient['gender'] ?? 'prefer_not_to_say') . '</td>';
                echo '<td>' . $count . '</td>';
                echo '<td><a href="?action=view&id=' . $patient['id'] . '" class="btn btn-sm">Chawila</a></td>';
                echo '</tr>';
            }
        }
    }
    echo '</table>';
    echo '</div>';
    echo '</div>';
    
    echo '<div class="card">';
    echo '<h3>Ronoj Wachib’al</h3>';
    if (empty($allPhotos)) {
        echo '<p>Maja k’o wachib’al xriqitaj</p>';
    } else {
        echo '<div class="table-container">';
        echo '<table>';
        echo '<tr><th>Ub’i’ Wuj</th><th>ID Yawab’</th><th>Ja</th><th>Nimal</th><th>Xjalwachixik</th><th>URL</th></tr>';
        foreach ($allPhotos as $photo) {
            if (is_array($photo)) {
                echo '<tr>';
                echo '<td>' . htmlspecialchars($photo['filename'] ?? '') . '</td>';
                echo '<td>' . htmlspecialchars($photo['patient_id'] ?? '') . '</td>';
                echo '<td>' . htmlspecialchars($photo['room_num'] ?? '') . '</td>';
                echo '<td>' . round(($photo['size'] ?? 0)/1024, 1) . ' KB</td>';
                echo '<td>' . (isset($photo['uploaded']) ? date(DATE_DISPLAY, $photo['uploaded']) : '') . '</td>';
                echo '<td><a href="' . htmlspecialchars($photo['url'] ?? '#') . '" target="_blank" class="btn btn-sm">Chawila</a></td>';
                echo '</tr>';
            }
        }
        echo '</table>';
        echo '</div>';
    }
    echo '</div>';
    
    echo '<div style="margin-top:var(--spacing-lg);">';
    echo '<a href="?action=dashboard" class="btn">Chatzalij pa Nab’e wuj</a>';
    echo '</div>';
    echo '</div>';
    showFooter();
}

// ==================== STATISTICS FUNCTIONS ====================
function updateStats($t, $d = '') {
    global $sF;
    $s = readJSONFile($sF);
    $td = date(DATE_SHORT);
    $w = date('Y-W');
    $m = date('Y-m');
    $y = date('Y');

    if (!is_array($s)) $s = ['daily' => [], 'weekly' => [], 'monthly' => [], 'yearly' => []];
    if (!isset($s['daily'][$td])) $s['daily'][$td] = ['admitted' => 0, 'discharged' => 0];
    if (!isset($s['weekly'][$w])) $s['weekly'][$w] = ['admitted' => 0, 'discharged' => 0];
    if (!isset($s['monthly'][$m])) $s['monthly'][$m] = ['admitted' => 0, 'discharged' => 0];
    if (!isset($s['yearly'][$y])) $s['yearly'][$y] = ['admitted' => 0, 'discharged' => 0];

    $s['daily'][$td][$t]++;
    $s['weekly'][$w][$t]++;
    $s['monthly'][$m][$t]++;
    $s['yearly'][$y][$t]++;

    if ($d) {
        if (!isset($s['daily'][$td]['depts'])) $s['daily'][$td]['depts'] = [];
        if (!isset($s['daily'][$td]['depts'][$d])) $s['daily'][$td]['depts'][$d] = ['admitted' => 0, 'discharged' => 0];
        $s['daily'][$td]['depts'][$d][$t]++;

        if (!isset($s['weekly'][$w]['depts'])) $s['weekly'][$w]['depts'] = [];
        if (!isset($s['weekly'][$w]['depts'][$d])) $s['weekly'][$w]['depts'][$d] = ['admitted' => 0, 'discharged' => 0];
        $s['weekly'][$w]['depts'][$d][$t]++;
    }

    writeJSONFile($sF, $s);
}

// ==================== AUTHENTICATION FUNCTIONS ====================
function handleCodeLogin() {
    global $uF, $roles;
    $code = preg_replace('/\D/', '', $_POST['code'] ?? '');

    // Rate limit per IP: with only a 6-digit code, brute-force protection matters
    if (!checkRateLimit('softtoken')) {
        $_SESSION['error'] = 'Login: k’i taqanik. Chatojtob’ej chi jun mul chi rij.';
        logMsg("Login: uk’isik taqanik xq’axtaj (soft token) pa IP: {$_SERVER['REMOTE_ADDR']}");
        header('Location: ./');
        exit;
    }
    if (strlen($code) != 6) {
        $_SESSION['error'] = 'Chaya 6-ajilab’al kod';
        header('Location: ./');
        exit;
    }

    $users = readJSONFile($uF);
    if (!is_array($users)) $users = [];

    $matches = [];
    foreach ($users as $i => $usr) {
        if (!is_array($usr) || empty($usr['secret'])) continue;
        if (isset($usr['active']) && !$usr['active']) continue;
        if (verifyTOTP($code, $usr['secret'])) $matches[] = $i;
    }

    if (count($matches) > 1) {
        // Two users share the same code in this time window: refuse, never guess
        logMsg("Login soft token xq’ataj: ri kod junam rik’in k’i okisanel");
        $_SESSION['error'] = 'Chawoyob’ej ri kod kepe chatojtob’ej chi jun mul';
        header('Location: ./');
        exit;
    }
    if (count($matches) == 0) {
        logMsg("Login soft token man utz ta pa IP: {$_SERVER['REMOTE_ADDR']}");
        $_SESSION['error'] = 'Kod man utz ta';
        header('Location: ./');
        exit;
    }

    $idx = $matches[0];
    $usr = $users[$idx];
    $users[$idx]['last_login'] = now();
    writeJSONFile($uF, $users);

    $usr['name'] = $usr['name'] ?? ($roles[$usr['role']]['name'] ?? $usr['role']);
    $usr['perms'] = $roles[$usr['role']]['perms'] ?? [];
    $_SESSION['user'] = $usr;
    unset($_SESSION['temp_user'], $_SESSION['mfa_required']);
    session_regenerate_id(true);
    logMsg("Login soft token: {$usr['user']}");
    header('Location: ./');
    exit;
}

function handleLogin() {
    global $uF, $roles;
    if (SOFTTOKEN_ONLY) handleCodeLogin();
    $u = $_POST['username'] ?? '';
    $p = $_POST['password'] ?? '';

    if (!checkRateLimit($u)) {
        $_SESSION['error'] = 'Login: k’i taqanik. Chatojtob’ej chi jun mul chi rij.';
        logMsg("Login: uk’isik taqanik xq’axtaj che: $u pa IP: {$_SERVER['REMOTE_ADDR']}");
        header('Location: ./');
        exit;
    }

    $users = readJSONFile($uF);
    if (!is_array($users)) $users = [];
    
    foreach ($users as $usr) {
        if (is_array($usr) && $usr['user'] === $u && password_verify($p, $usr['pass'])) {
            foreach ($users as &$userRecord) {
                if ($userRecord['user'] == $u) {
                    $userRecord['last_login'] = now();
                    break;
                }
            }
            writeJSONFile($uF, $users);
            
            $_SESSION['temp_user'] = $usr;
            $_SESSION['temp_user']['name'] = $usr['name'] ?? ($roles[$usr['role']]['name'] ?? $usr['role']);
            $_SESSION['temp_user']['perms'] = $roles[$usr['role']]['perms'] ?? [];
            
            if (SOFTTOKEN_ONLY && empty($usr['secret'])) {
                // Soft token is mandatory: no token on the account means no login
                unset($_SESSION['temp_user']);
                logMsg("Login xq’ataj (maja k’o soft token pa okisab’al): $u");
                $_SESSION['error'] = 'Maja k’o soft token che we okisab’al ri’. Chach’awij ri ajchak’.';
                header('Location: ./');
                exit;
            } elseif (($usr['mfa'] && !empty($usr['secret'])) || SOFTTOKEN_ONLY || MFA_ENFORCE) {
                $_SESSION['mfa_required'] = 1;
                logMsg("MFA rajawaxik che: $u");
                header('Location: ./');
                exit;
            } else {
                $_SESSION['user'] = $_SESSION['temp_user'];
                unset($_SESSION['temp_user']);
                logMsg("Login: $u");
                header('Location: ./');
                exit;
            }
        }
    }

    $_SESSION['error'] = 'Ub’i’ okisanel o ri ewal tzij man utz ta';
    header('Location: ./');
    exit;
}

function verifyMFA() {
    global $uF;
    $code = $_POST['code'] ?? '';
    if (!isset($_SESSION['temp_user'])) {
        $_SESSION['error'] = 'Xk’is ri ramaj. Chatok chi jun mul.';
        header('Location: ./');
        exit;
    }
    $user = $_SESSION['temp_user'];
    if (!$code || strlen($code) != 6 || !is_numeric($code)) {
        $_SESSION['error'] = 'Chaya 6-ajilab’al kod';
        header('Location: ./');
        exit;
    }
    if (verifyTOTP($code, $user['secret'])) {
        $_SESSION['user'] = $user;
        unset($_SESSION['temp_user'], $_SESSION['mfa_required']);
        logMsg("MFA xqatzij: {$user['user']}");
        header('Location: ./');
        exit;
    }
    $_SESSION['error'] = 'Kod MFA man utz ta';
    header('Location: ./');
    exit;
}

function handleMFAAction() {
    global $uF;
    $user = $_SESSION['user']['user'] ?? '';
    $act = $_POST['action'] ?? '';
    if (!$user) {
        $_SESSION['error'] = 'Maja katok';
        header('Location: ?action=security');
        exit;
    }
    $users = readJSONFile($uF);
    if (!is_array($users)) $users = [];
    
    if ($act == 'enable') {
        $secret = genSecret();
        $_SESSION['setup_secret'] = $secret;
        header('Location: ?action=setup');
        exit;
    } elseif ($act == 'disable') {
        if (SOFTTOKEN_ONLY) {
            $_SESSION['error'] = 'Login soft token rajawaxik man kachuplix ta';
            header('Location: ?action=security');
            exit;
        }
        foreach ($users as &$u) {
            if ($u['user'] == $user) {
                $u['secret'] = '';
                $u['mfa'] = 0;
                break;
            }
        }
        writeJSONFile($uF, $users);
        $_SESSION['user']['mfa'] = 0;
        $_SESSION['user']['secret'] = '';
        $_SESSION['success'] = 'MFA xchuplix';
        header('Location: ?action=security');
        exit;
    }
}

function handleAdminMFAAction() {
    global $uF;
    if (!can('mfa_admin')) {
        showError('Xq’ataj ri b’ixikil');
        exit;
    }
    $target = $_POST['target_user'] ?? '';
    $action = $_POST['admin_action'] ?? '';
    $users = readJSONFile($uF);
    if (!is_array($users)) $users = [];

    if ($action == 'enable') {
        $secret = genSecret();
        foreach ($users as &$u) {
            if ($u['user'] == $target) {
                $u['secret'] = $secret;
                $u['mfa'] = 1;
                logMsg("Admin xuchaplej MFA che: $target");
                $_SESSION['admin_message'] = "MFA xchaplex che $target. Ewal: $secret";
                break;
            }
        }
    } elseif ($action == 'disable') {
        foreach ($users as &$u) {
            if ($u['user'] == $target) {
                $u['secret'] = '';
                $u['mfa'] = 0;
                logMsg("Admin xuchuplij MFA che: $target");
                $_SESSION['admin_message'] = "MFA xchuplix che $target";
                break;
            }
        }
    } elseif ($action == 'reset_secret') {
        $secret = genSecret();
        foreach ($users as &$u) {
            if ($u['user'] == $target) {
                $u['secret'] = $secret;
                logMsg("Admin xujalwachij ri ewal MFA che: $target");
                $_SESSION['admin_message'] = "MFA ri ewal xjalwachix che $target. K’ak’ ewal: $secret";
                break;
            }
        }
    } elseif ($action == 'view_secret') {
        foreach ($users as $u) {
            if ($u['user'] == $target) {
                $_SESSION['admin_message'] = "MFA ri ewal che $target: " . ($u['secret'] ? $u['secret'] : 'Maja yakom');
                break;
            }
        }
    }
    writeJSONFile($uF, $users);
    header('Location: ?action=mfa_admin');
    exit;
}

function resetUserPassword() {
    global $uF;
    if (!can('user_admin')) {
        showError('Xq’ataj ri b’ixikil');
        exit;
    }
    $target = $_POST['target_user'] ?? '';
    $newpass = $_POST['new_password'] ?? '';
    if (!$target || !$newpass) {
        $_SESSION['error'] = 'Maja k’o retal';
        header('Location: ?action=user_manage');
        exit;
    }
    if (!validatePassword($newpass)) {
        $_SESSION['error'] = 'Ri ewal tzij rajawaxik k’o 8 tz’ib’ rachi’ nim tz’ib’, ch’uti tz’ib’, ajilab’al rachi’ jun wi’ retal';
        header('Location: ?action=user_manage');
        exit;
    }
    $users = readJSONFile($uF);
    if (!is_array($users)) $users = [];
    
    foreach ($users as &$u) {
        if ($u['user'] == $target) {
            $u['pass'] = password_hash($newpass, PASSWORD_DEFAULT, ['cost' => BCRYPT_COST]);
            logMsg("Admin xujalwachij ri ewal tzij che: $target");
            $_SESSION['admin_message'] = "Ri ewal tzij xjalwachix che $target";
            break;
        }
    }
    writeJSONFile($uF, $users);
    header('Location: ?action=user_manage');
    exit;
}

function addNewUser() {
    global $uF, $roles;
    if (!can('user_admin')) {
        showError('Xq’ataj ri b’ixikil');
        exit;
    }
    $u = $_POST['new_username'] ?? '';
    $p = $_POST['new_password'] ?? '';
    $r = $_POST['new_role'] ?? '';
    $m = isset($_POST['new_mfa']) ? 1 : 0;
    $name = $_POST['new_name'] ?? '';
    $email = $_POST['new_email'] ?? '';

    if (!$u || !$p || !$r) {
        $_SESSION['error'] = 'Maja k’o ucholaj';
        header('Location: ?action=user_manage');
        exit;
    }

    if (!validatePassword($p)) {
        $_SESSION['error'] = 'Ri ewal tzij rajawaxik k’o 8 tz’ib’ rachi’ nim tz’ib’, ch’uti tz’ib’, ajilab’al rachi’ jun wi’ retal';
        header('Location: ?action=user_manage');
        exit;
    }

    if (!isset($roles[$r])) {
        $_SESSION['error'] = 'Chak man utz ta';
        header('Location: ?action=user_manage');
        exit;
    }

    $users = readJSONFile($uF);
    if (!is_array($users)) $users = [];
    
    foreach ($users as $usr) {
        if ($usr['user'] == $u) {
            $_SESSION['error'] = 'Ub’i’ okisanel k’o chi';
            header('Location: ?action=user_manage');
            exit;
        }
    }

    $s = '';
    if ($m) {
        $s = genSecret();
        $_SESSION['admin_message'] = "Okisanel $u xb’an rik’in MFA. Ewal: $s";
    } else {
        $_SESSION['admin_message'] = "Okisanel $u xb’an maja k’o MFA";
    }

    $users[] = [
        'user' => $u, 
        'pass' => password_hash($p, PASSWORD_DEFAULT, ['cost' => BCRYPT_COST]), 
        'role' => $r, 
        'mfa' => $m, 
        'secret' => $s,
        'name' => $name ?: $u,
        'email' => $email,
        'created' => now(),
        'last_login' => null,
        'active' => 1
    ];
    
    writeJSONFile($uF, $users);
    logMsg("Admin xub’an okisanel: $u ($r)");
    header('Location: ?action=user_manage');
    exit;
}

function deleteUser() {
    global $uF;
    if (!can('user_admin')) {
        showError('Xq’ataj ri b’ixikil');
        exit;
    }
    $t = $_POST['target_user'] ?? '';

    if (!$t) {
        $_SESSION['error'] = 'Maja k’o okisanel b’im';
        header('Location: ?action=user_manage');
        exit;
    }

    if ($t == 'admin') {
        $_SESSION['error'] = 'Man kesax ta admin';
        header('Location: ?action=user_manage');
        exit;
    }

    $users = readJSONFile($uF);
    if (!is_array($users)) $users = [];
    
    $nu = [];
    $uf = false;

    foreach ($users as $u) {
        if ($u['user'] == $t) {
            $uf = true;
            continue;
        }
        $nu[] = $u;
    }

    if (!$uf) {
        $_SESSION['error'] = "Okisanel '$t' man xriqitaj ta";
        header('Location: ?action=user_manage');
        exit;
    }

    writeJSONFile($uF, $nu);
    logMsg("Admin xresaj okisanel: $t");
    $_SESSION['admin_message'] = "Okisanel $t xesaxik";
    header('Location: ?action=user_manage');
    exit;
}

function verifyMFASetup() {
    global $uF;
    $code = $_POST['code'] ?? '';
    $secret = $_SESSION['setup_secret'] ?? '';
    $user = $_SESSION['user']['user'] ?? '';
    if (!$code || !$secret || !$user) {
        $_SESSION['error'] = 'Maja k’o retal';
        header('Location: ?action=security');
        exit;
    }
    if (!verifyTOTP($code, $secret)) {
        $_SESSION['error'] = 'Kod MFA man utz ta';
        header('Location: ?action=setup');
        exit;
    }
    $users = readJSONFile($uF);
    if (!is_array($users)) $users = [];
    
    foreach ($users as &$u) {
        if ($u['user'] == $user) {
            $u['secret'] = $secret;
            $u['mfa'] = 1;
            $_SESSION['user']['mfa'] = 1;
            $_SESSION['user']['secret'] = $secret;
            break;
        }
    }
    writeJSONFile($uF, $users);
    unset($_SESSION['setup_secret']);
    $_SESSION['success'] = 'MFA xchaplex!';
    logMsg("MFA xchaplex che: $user");
    header('Location: ?action=security');
    exit;
}

function genSecret() {
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $s = '';
    for ($i = 0; $i < 16; $i++) $s .= $chars[rand(0, 31)];
    return $s;
}

function verifyTOTP($code, $secret) {
    if (strlen($code) != 6 || !is_numeric($code)) return false;
    if (empty($secret)) return false;
    $t = floor(time() / 30);
    for ($i = -1; $i <= 1; $i++) {
        $calc = calcTOTP($secret, $t + $i);
        if (hash_equals($calc, $code)) return true;
    }
    return false;
}

function calcTOTP($s, $t) {
    $k = base32_decode($s);
    if (!$k) return '000000';
    $time = pack('N*', 0) . pack('N*', $t);
    $h = hash_hmac('sha1', $time, $k, 1);
    $o = ord($h[19]) & 0xF;
    $r = (ord($h[$o]) & 0x7F) << 24 | (ord($h[$o + 1]) & 0xFF) << 16 | (ord($h[$o + 2]) & 0xFF) << 8 | (ord($h[$o + 3]) & 0xFF);
    return str_pad($r % 1000000, 6, '0', STR_PAD_LEFT);
}

function base32_decode($s) {
    $c = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $b = 0;
    $bl = 0;
    $o = '';
    for ($i = 0; $i < strlen($s); $i++) {
        $v = strpos($c, $s[$i]);
        if ($v === false) continue;
        $b <<= 5;
        $b |= $v;
        $bl += 5;
        if ($bl >= 8) {
            $o .= chr(($b >> ($bl - 8)) & 0xFF);
            $bl -= 8;
        }
    }
    return $o;
}

// ==================== TELEPHONE FUNCTIONS ====================
function addTelephone() {
    if (!can('telephone')) {
        showError('Xq’ataj ri b’ixikil');
        exit;
    }

    $rid = intval($_POST['room_id'] ?? 0);
    $n = trim($_POST['number'] ?? '');
    $e = trim($_POST['ext'] ?? '');
    $p = trim($_POST['purpose'] ?? '');
    $nt = trim($_POST['notes'] ?? '');

    if (!$rid || !$n) {
        $_SESSION['error'] = 'Rajawaxik ri ID ja rachi’ ajilab’al';
        header('Location: ?action=add_tel');
        exit;
    }

    $ph = readJSONFile($GLOBALS['tF']);
    if (!is_array($ph)) $ph = [];
    
    $r = readJSONFile($GLOBALS['rF']);
    if (!is_array($r)) $r = [];
    
    $re = false;
    $rn = '';

    foreach ($r as $rm) {
        if (is_array($rm) && ($rm['id'] ?? 0) == $rid) {
            $re = true;
            $rn = $rm['num'] ?? '';
            break;
        }
    }

    if (!$re) {
        $_SESSION['error'] = 'Ja man utz ta';
        header('Location: ?action=add_tel');
        exit;
    }

    $id = count($ph) > 0 ? max(array_column($ph, 'id')) + 1 : 1;
    $ph[] = [
        'id' => $id,
        'room_id' => $rid,
        'room_num' => $rn,
        'number' => $n,
        'ext' => $e,
        'purpose' => $p,
        'notes' => $nt,
        'created' => now(),
        'updated' => now()
    ];

    writeJSONFile($GLOBALS['tF'], $ph);
    logMsg("Xtz’aqatisaxik ch’awib’al: $n che Ja $rn");
    $_SESSION['success'] = 'Ri ajilab’al ch’awib’al utz xtz’aqatisax';
    header('Location: ?action=telephone');
    exit;
}

function editTelephone() {
    if (!can('telephone')) {
        showError('Xq’ataj ri b’ixikil');
        exit;
    }

    $id = intval($_POST['id'] ?? 0);
    $n = trim($_POST['number'] ?? '');
    $e = trim($_POST['ext'] ?? '');
    $p = trim($_POST['purpose'] ?? '');
    $nt = trim($_POST['notes'] ?? '');

    if (!$id || !$n) {
        $_SESSION['error'] = 'Rajawaxik ID rachi’ ajilab’al';
        header('Location: ?action=telephone');
        exit;
    }

    $ph = readJSONFile($GLOBALS['tF']);
    if (!is_array($ph)) $ph = [];
    
    $f = false;

    foreach ($ph as &$phn) {
        if (is_array($phn) && ($phn['id'] ?? 0) == $id) {
            $phn['number'] = $n;
            $phn['ext'] = $e;
            $phn['purpose'] = $p;
            $phn['notes'] = $nt;
            $phn['updated'] = now();
            $f = true;
            break;
        }
    }

    if (!$f) {
        $_SESSION['error'] = 'Man xriqitaj ta ri ch’awib’al';
        header('Location: ?action=telephone');
        exit;
    }

    writeJSONFile($GLOBALS['tF'], $ph);
    logMsg("Xutzirisaxik ch’awib’al: $n (ID: $id)");
    $_SESSION['success'] = 'Ri ajilab’al ch’awib’al utz xk’ak’arisax';
    header('Location: ?action=telephone');
    exit;
}

function deleteTelephone() {
    if (!can('telephone')) {
        showError('Xq’ataj ri b’ixikil');
        exit;
    }

    $id = intval($_POST['id'] ?? 0);
    if (!$id) {
        header('Location: ?action=telephone');
        exit;
    }

    $ph = readJSONFile($GLOBALS['tF']);
    if (!is_array($ph)) $ph = [];
    
    $np = [];
    $dn = '';

    foreach ($ph as $p) {
        if (is_array($p) && ($p['id'] ?? 0) != $id) {
            $np[] = $p;
        } else {
            $dn = $p['number'] ?? '';
        }
    }

    writeJSONFile($GLOBALS['tF'], $np);
    logMsg("Xesaxik ch’awib’al: $dn (ID: $id)");
    $_SESSION['success'] = 'Ri ajilab’al ch’awib’al utz xesax';
    header('Location: ?action=telephone');
    exit;
}

// ==================== DISCHARGED PATIENTS FUNCTIONS ====================
// ==================== DISCHARGED PATIENTS: PERIOD FILTER ====================
// Resolves ?period=today|yesterday|week|month|year|all|custom (&from=&to=). Default: today.
// A legacy ?date=YYYY-MM-DD link is treated as a one-day custom period.
function resolveDischargePeriod() {
    $period = $_GET['period'] ?? '';
    $from = $_GET['from'] ?? '';
    $to = $_GET['to'] ?? '';
    $date = $_GET['date'] ?? '';
    $re = '/^\d{4}-\d{2}-\d{2}$/';

    if ($date !== '' && preg_match($re, $date)) {
        $period = 'custom';
        $from = $to = $date;
    } elseif ($date !== '' && preg_match('/^\d{2}-\d{4}$/', $date)) {
        // link to a weekly archive: show that week
        list($ws, $we) = archiveKeyRange($date);
        $period = 'custom';
        $from = date(DATE_SHORT, $ws);
        $to = date(DATE_SHORT, $we);
    }
    if ($period === '') $period = 'today';

    $today = date(DATE_SHORT);
    switch ($period) {
        case 'yesterday':
            $f = $t = date(DATE_SHORT, strtotime('-1 day'));
            $label = 'Iwir';
            break;
        case 'week':
            $f = date(DATE_SHORT, strtotime('monday this week'));
            $t = $today;
            $label = 'We wuqq q’ij ri’';
            break;
        case 'month':
            $f = date('Y-m-01');
            $t = $today;
            $label = 'We ik’ ri’';
            break;
        case 'year':
            $f = date('Y-01-01');
            $t = $today;
            $label = 'We junab’ ri’';
            break;
        case 'all':
            $f = $t = null;
            $label = 'Ronoj';
            break;
        case 'custom':
            if (preg_match($re, $from) && preg_match($re, $to)) {
                if ($from > $to) { $tmp = $from; $from = $to; $to = $tmp; }
                $f = $from;
                $t = $to;
                $label = ($f === $t) ? $f : "$f k’a $t";
                break;
            }
            // invalid custom range: fall back to today
            $period = 'today';
            // no break
        case 'today':
        default:
            $period = 'today';
            $f = $t = $today;
            $label = 'Kamik';
            break;
    }
    return ['key' => $period, 'from' => $f, 'to' => $t, 'label' => $label];
}

function dischargePeriodQuery($pr) {
    $q = '&period=' . urlencode($pr['key']);
    if ($pr['key'] === 'custom') {
        $q .= '&from=' . urlencode($pr['from']) . '&to=' . urlencode($pr['to']);
    }
    return $q;
}

// Everything discharged inside the range: discharged patients still in the `patients` table
// (until the weekly de-attach) plus the rows in `detached_patients`.
function getDischargedPatientsInRange($from, $to) {
    $fromTs = $from ? strtotime($from . ' 00:00:00') : null;
    $toTs = $to ? strtotime($to . ' 23:59:59') : null;
    $out = [];
    $seen = [];

    $live = readJSONFile($GLOBALS['pF']);
    if (is_array($live)) {
        foreach ($live as $pt) {
            if (!is_array($pt) || ($pt['status'] ?? '') !== 'discharged') continue;
            $ts = strtotime($pt['discharge_date'] ?? '');
            if ($ts === false) continue;
            if (($fromTs !== null && $ts < $fromTs) || ($toTs !== null && $ts > $toTs)) continue;
            $pt['_live'] = true;
            $out[] = $pt;
            $seen[($pt['id'] ?? '') . '|' . ($pt['discharge_date'] ?? '')] = true;
        }
    }

    // De-attached patients: filtered on discharge_date in MySQL
    foreach (dbDetachedPatientsInRange($fromTs !== null ? date('Y-m-d H:i:s', $fromTs) : null,
                                       $toTs !== null ? date('Y-m-d H:i:s', $toTs) : null) as $pt) {
        $key = ($pt['id'] ?? '') . '|' . ($pt['discharge_date'] ?? '');
        if (isset($seen[$key])) continue;
        $seen[$key] = true;
        $out[] = $pt;
    }

    usort($out, function($a, $b) {
        return strtotime($b['discharge_date'] ?? '') - strtotime($a['discharge_date'] ?? '');
    });
    return $out;
}

// Links for one row: patients discharged today are opened from the live record,
// de-attached ones from detached_patients (week of their discharge).
function dischargedRowLinks($pt) {
    $id = urlencode($pt['id'] ?? '');
    if (!empty($pt['_live'])) {
        return [
            'view'  => "?action=view&id=$id",
            'print' => "?action=print&id=$id",
            'rx'    => "?action=prescription&id=$id",
            'readmit' => "?action=readmit&id=$id",
        ];
    }
    $d = $pt['_archive_date'] ?? archiveWeekKey(strtotime($pt['discharge_date'] ?? 'now'));
    return [
        'view'  => "?action=view_discharged&id=$id&date=$d",
        'print' => "?action=print&id=$id&discharged=1&date=$d",
        'rx'    => "?action=prescription&id=$id&discharged=1&date=$d",
        'readmit' => "?action=readmit&id=$id&date=$d",
    ];
}

// ==================== TAKE A DISCHARGED PATIENT BACK TO PATIENTS ====================
function canReadmit() {
    return can('discharge') || can('admin');
}


// Finds a discharged patient. Returns [patient, source, archiveDate] where source is
// 'live' (still in the `patients` table) or 'archive' (in `detached_patients`).
function locateDischargedPatient($id, $date = '') {
    $live = readJSONFile($GLOBALS['pF']);
    if (is_array($live)) {
        foreach ($live as $pt) {
            if (is_array($pt) && ($pt['id'] ?? '') === $id && ($pt['status'] ?? '') === 'discharged') {
                return [$pt, 'live', ''];
            }
        }
    }
    $dates = ($date !== '' && archiveFileForKey($date)) ? [$date] : getArchiveKeys();
    foreach ($dates as $d) {
        foreach (getDischargedPatients($d) as $pt) {
            if (is_array($pt) && ($pt['id'] ?? '') === $id) return [$pt, 'archive', $d];
        }
    }
    return [null, '', ''];
}

function showReadmitForm() {
    if (!canReadmit()) { showError('Xq’ataj ri b’ixikil'); exit; }
    $id = $_GET['id'] ?? '';
    $date = $_GET['date'] ?? '';
    list($pt, $source, $archiveDate) = locateDischargedPatient($id, $date);
    if (!$pt) {
        $_SESSION['error'] = 'Man xriqitaj ta ri yawab’ xel';
        header('Location: ?action=discharged');
        exit;
    }

    $rooms = readJSONFile($GLOBALS['rF']);
    if (!is_array($rooms)) $rooms = [];
    $free = [];
    foreach ($rooms as $r) {
        if (($r['occ'] ?? 0) < ($r['beds'] ?? 0)) $free[] = $r;
    }
    // Original room first if it still has a free bed, then rooms of the same department
    usort($free, function($a, $b) use ($pt) {
        $sa = (($a['id'] ?? 0) == ($pt['room_id'] ?? -1) ? 0 : (($a['dept'] ?? '') === ($pt['department'] ?? '') ? 1 : 2));
        $sb = (($b['id'] ?? 0) == ($pt['room_id'] ?? -1) ? 0 : (($b['dept'] ?? '') === ($pt['department'] ?? '') ? 1 : 2));
        return $sa - $sb;
    });

    showHeader();
?>
    <div class="container">
        <div class="form-container" style="max-width:700px;">
            <h2>Chatzalij ri Yawab’ pa Yawab’</h2>

            <div class="patient-info">
                <p><strong>Yawab’:</strong> <?= htmlspecialchars($pt['name'] ?? '') ?> (ID: <?= htmlspecialchars($pt['id'] ?? '') ?>)</p>
                <p><strong>Xel:</strong> <?= isset($pt['discharge_date']) ? htmlspecialchars(formatDate($pt['discharge_date'])) : '-' ?>
                    &middot; <?= htmlspecialchars($pt['discharge']['cond'] ?? '') ?></p>
                <p><strong>Ja:</strong> <?= htmlspecialchars(getDeptName($pt['department'] ?? '')) ?></p>
                <p class="text-muted">Ri yawab’ kok <em>xok</em> chi jun mul kak’ut pa Yawab’. Ri tz’ib’ re elib’al, rachi’ ri wuj kunab’al, kyakon pa ri ojer re yawab’.</p>
            </div>

            <?php if (empty($free)): ?>
                <div class="alert alert-error">Maja k’o ja rachi’ warab’al tolon, rumal ri’ man katzalix ta ri yawab’ kamik.</div>
                <a href="?action=discharged" class="btn">← Chatzalij</a>
            <?php else: ?>
                <form method="POST" action="?action=readmit">
                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                    <input type="hidden" name="id" value="<?= htmlspecialchars($pt['id']) ?>">
                    <input type="hidden" name="date" value="<?= htmlspecialchars($archiveDate) ?>">
                    <div class="form-group">
                        <label class="required">Ja</label>
                        <select name="room_id" required>
                            <?php foreach ($free as $r): ?>
                                <option value="<?= (int)$r['id'] ?>" <?= ($r['id'] == ($pt['room_id'] ?? -1)) ? 'selected' : '' ?>>
                                    Ja <?= htmlspecialchars($r['num']) ?> &middot; <?= htmlspecialchars(getDeptName($r['dept'] ?? '')) ?>
                                    (<?= (int)($r['beds'] - $r['occ']) ?> tolon)<?= ($r['id'] == ($pt['room_id'] ?? -1)) ? ' - ja nab’e' : '' ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Rumal jas (we kawaj)</label>
                        <input type="text" name="reason" maxlength="200" placeholder="jas xesax rumal sach, ri wachinem xk’axk’ar">
                    </div>
                    <div style="display:flex;gap:15px;">
                        <button type="submit" class="btn btn-primary">Chatzalij pa yawab’</button>
                        <a href="?action=discharged" class="btn">Chatanab’a</a>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
<?php
    showFooter();
}

function readmitPatient() {
    if (!canReadmit()) { showError('Xq’ataj ri b’ixikil'); exit; }
    $id = $_POST['id'] ?? '';
    $date = $_POST['date'] ?? '';
    $rid = intval($_POST['room_id'] ?? 0);
    $reason = trim($_POST['reason'] ?? '');

    list($pt, $source, $archiveDate) = locateDischargedPatient($id, $date);
    if (!$pt) {
        $_SESSION['error'] = 'Man xriqitaj ta ri yawab’ xel';
        header('Location: ?action=discharged');
        exit;
    }

    $rooms = readJSONFile($GLOBALS['rF']);
    if (!is_array($rooms)) $rooms = [];
    $ri = array_search($rid, array_column($rooms, 'id'));
    if ($ri === false || $rooms[$ri]['occ'] >= $rooms[$ri]['beds']) {
        $_SESSION['error'] = 'Ri ja man tolon ta';
        header('Location: ?action=readmit&id=' . urlencode($id) . ($archiveDate ? '&date=' . $archiveDate : ''));
        exit;
    }

    // Keep the discharge record in the patient's history, then clear the discharged state
    $origDischargeDate = $pt['discharge_date'] ?? '';
    $history = $pt['previous_discharges'] ?? [];
    $history[] = [
        'discharge_date' => $pt['discharge_date'] ?? '',
        'discharge'      => $pt['discharge'] ?? [],
        'returned_at'    => now(),
        'returned_by'    => $_SESSION['user']['user'] ?? 'system',
        'reason'         => $reason,
    ];
    $pt['previous_discharges'] = $history;
    foreach (['discharge', 'discharge_date', 'archived', 'detached_at', 'detached_from', 'encrypted',
              'pdf_archive', 'source_file', '_live', '_archive_date', 'archive_week'] as $k) {
        unset($pt[$k]);
    }
    $pt['status'] = 'admitted';
    $pt['room_id'] = $rooms[$ri]['id'];
    $pt['room_num'] = $rooms[$ri]['num'];
    addTimelineEvent($pt, 'admit', 'Xtzalix pa yawab’',
        'Ja ' . $rooms[$ri]['num'] . ' (' . getDeptName($rooms[$ri]['dept'] ?? '') . ')' . ($reason !== '' ? ' - ' . $reason : ''));

    $patients = readJSONFile($GLOBALS['pF']);
    if (!is_array($patients)) $patients = [];

    if ($source === 'live') {
        $pi = array_search($id, array_column($patients, 'id'));
        if ($pi === false) { header('Location: ?action=discharged'); exit; }
        $patients[$pi] = $pt;
    } else {
        // Back into `patients`; the row in `detached_patients` is removed once that is saved
        $patients[] = $pt;
    }

    $rooms[$ri]['occ']++;
    writeJSONFile($GLOBALS['pF'], $patients);
    writeJSONFile($GLOBALS['rF'], $rooms);
    if ($source !== 'live') {
        dbDeleteDetached($id, $origDischargeDate);
    }

    logMsg("Xel yawab’ xtzalix pa yawab’: {$pt['name']} ($id) - Ja {$rooms[$ri]['num']}" . ($reason !== '' ? " - Rumal jas: $reason" : ''));
    $_SESSION['success'] = 'Ri yawab’ xtzalij pa Yawab’ (Ja ' . $rooms[$ri]['num'] . ').';
    header('Location: ?action=view&id=' . urlencode($id));
    exit;
}

function showDischargedPatients() {
    if (!canViewDischarged()) {
        showError('Xq’ataj ri b’ixikil');
        exit;
    }

    $searchQuery = $_GET['search'] ?? '';
    $searchType = $_GET['search_type'] ?? 'all';
    $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
    $perPage = MAX_PATIENTS_PER_PAGE;

    $pr = resolveDischargePeriod();
    $periodQS = dischargePeriodQuery($pr);
    $searchQS = $searchQuery !== '' ? '&search=' . urlencode($searchQuery) . '&search_type=' . urlencode($searchType) : '';
    $dischargedPatients = getDischargedPatientsInRange($pr['from'], $pr['to']);

    if (!empty($searchQuery)) {
        $filteredPatients = [];
        foreach ($dischargedPatients as $patient) {
            $deptName = isset($patient['department']) ? getDeptName($patient['department']) : '';
            $genderName = isset($patient['gender']) ? getGenderName($patient['gender']) : '';
            $condition = $patient['discharge']['cond'] ?? '';
            $complaint = $patient['complaint'] ?? '';
            switch ($searchType) {
                case 'id':
                    $match = isset($patient['id']) && stripos($patient['id'], $searchQuery) !== false;
                    break;
                case 'name':
                    $match = isset($patient['name']) && stripos($patient['name'], $searchQuery) !== false;
                    break;
                case 'gender':
                    $match = stripos($genderName, $searchQuery) !== false;
                    break;
                case 'department':
                    $match = stripos($deptName, $searchQuery) !== false;
                    break;
                case 'condition':
                    $match = stripos($condition, $searchQuery) !== false;
                    break;
                case 'all':
                default:
                    $match = (isset($patient['id']) && stripos($patient['id'], $searchQuery) !== false) ||
                             (isset($patient['name']) && stripos($patient['name'], $searchQuery) !== false) ||
                             stripos($genderName, $searchQuery) !== false ||
                             stripos($deptName, $searchQuery) !== false ||
                             stripos($condition, $searchQuery) !== false ||
                             stripos($complaint, $searchQuery) !== false;
                    break;
            }
            if ($match) $filteredPatients[] = $patient;
        }
        $dischargedPatients = $filteredPatients;
    }

    $totalPatients = count($dischargedPatients);
    $totalPages = (int)ceil($totalPatients / $perPage);
    $offset = ($page - 1) * $perPage;
    $paginatedPatients = array_slice($dischargedPatients, $offset, $perPage);

    $withRx = 0;
    $todayCount = 0;
    $today = date(DATE_SHORT);
    foreach ($dischargedPatients as $pt) {
        if (getPrescriptionItems($pt)) $withRx++;
        if (date(DATE_SHORT, strtotime($pt['discharge_date'] ?? '')) === $today) $todayCount++;
    }

    $periodButtons = ['today' => 'Kamik', 'yesterday' => 'Iwir', 'week' => 'We wuqq q’ij ri’',
                      'month' => 'We ik’ ri’', 'year' => 'We junab’ ri’', 'all' => 'Ronoj'];
    $photoDate = $pr['from'] ? '&date=' . archiveWeekKey(strtotime($pr['from'])) : '';

    showHeader();
?>
    <div class="container">
        <h2>Yawab’ Xeel</h2>
        <p class="text-muted" style="margin-bottom:var(--spacing-lg);">Ri yawab’ xeel kek’ut aninaq waral. Kyakon kumal <?= archiveScheduleText() ?> (xjalwachixik pa ri tabla yawab’ yakom) rachi’ kech’akataj na.<?= PHOTO_DELETE_ON_ARCHIVE ? ' Ri kiwachib’al kesax pa ri ramaj ri’.' : '' ?></p>

        <div class="grid grid-4" style="margin-bottom:var(--spacing-lg);">
            <div class="card">
                <div class="card-label">Ramaj</div>
                <div class="card-stats" style="font-size:1.1rem;"><?= htmlspecialchars($pr['label']) ?></div>
            </div>
            <div class="card">
                <div class="card-label">Xeel pa ramaj</div>
                <div class="card-stats"><?= $totalPatients ?></div>
            </div>
            <div class="card">
                <div class="card-label">Rachi’ wujkunab’al</div>
                <div class="card-stats"><?= $withRx ?></div>
            </div>
            <div class="card">
                <div class="card-label">Xeel kamik</div>
                <div class="card-stats"><?= $todayCount ?></div>
            </div>
        </div>

        <div class="card" style="margin-bottom:var(--spacing-lg);">
            <h3>Chak’utu’ elib’al</h3>
            <div class="filter-bar" style="margin:0;">
                <div class="btn-group">
                    <?php foreach ($periodButtons as $key => $label): ?>
                        <a href="?action=discharged&period=<?= $key ?><?= $searchQS ?>" class="btn <?= $pr['key'] === $key ? 'btn-primary' : '' ?>"><?= $label ?></a>
                    <?php endforeach; ?>
                </div>
            </div>
            <form method="GET" action="" style="margin-top:var(--spacing-md);">
                <input type="hidden" name="action" value="discharged">
                <input type="hidden" name="period" value="custom">
                <?php if ($searchQuery !== ''): ?>
                    <input type="hidden" name="search" value="<?= htmlspecialchars($searchQuery) ?>">
                    <input type="hidden" name="search_type" value="<?= htmlspecialchars($searchType) ?>">
                <?php endif; ?>
                <div class="filter-bar" style="margin:0;">
                    <div class="filter-group">
                        <label for="from">Pa:</label>
                        <input type="date" id="from" name="from" value="<?= htmlspecialchars($pr['from'] ?? date(DATE_SHORT)) ?>" max="<?= date(DATE_SHORT) ?>" required>
                    </div>
                    <div class="filter-group">
                        <label for="to">K’a:</label>
                        <input type="date" id="to" name="to" value="<?= htmlspecialchars($pr['to'] ?? date(DATE_SHORT)) ?>" max="<?= date(DATE_SHORT) ?>" required>
                    </div>
                    <div class="btn-group">
                        <button type="submit" class="btn <?= $pr['key'] === 'custom' ? 'btn-primary' : '' ?>">Nimal kawaj</button>
                    </div>
                </div>
            </form>
        </div>

        <div class="card" style="margin-bottom:var(--spacing-xl);">
            <h3>Chatzukuj yawab’ xeel</h3>
            <form method="GET" action="">
                <input type="hidden" name="action" value="discharged">
                <input type="hidden" name="period" value="<?= htmlspecialchars($pr['key']) ?>">
                <?php if ($pr['key'] === 'custom'): ?>
                    <input type="hidden" name="from" value="<?= htmlspecialchars($pr['from']) ?>">
                    <input type="hidden" name="to" value="<?= htmlspecialchars($pr['to']) ?>">
                <?php endif; ?>
                <div class="filter-bar" style="margin:0;">
                    <div class="filter-group" style="flex:2;">
                        <label for="search">Chatzukuj:</label>
                        <input type="text" id="search" name="search" value="<?= htmlspecialchars($searchQuery) ?>" placeholder="Chaya tzij che tzukunik...">
                    </div>
                    <div class="filter-group">
                        <label for="search_type">Pa:</label>
                        <select id="search_type" name="search_type">
                            <option value="all" <?= $searchType == 'all' ? 'selected' : '' ?>>Ronoj Ucholaj</option>
                            <option value="id" <?= $searchType == 'id' ? 'selected' : '' ?>>ID Yawab’</option>
                            <option value="name" <?= $searchType == 'name' ? 'selected' : '' ?>>Ub’i’ Yawab’</option>
                            <option value="gender" <?= $searchType == 'gender' ? 'selected' : '' ?>>Achi/Ixoq</option>
                            <option value="department" <?= $searchType == 'department' ? 'selected' : '' ?>>Ja</option>
                            <option value="condition" <?= $searchType == 'condition' ? 'selected' : '' ?>>Wachinem</option>
                        </select>
                    </div>
                    <div class="btn-group">
                        <button type="submit" class="btn btn-primary">Chatzukuj</button>
                        <?php if (!empty($searchQuery)): ?>
                            <a href="?action=discharged<?= $periodQS ?>" class="btn">Chesaj</a>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
            <?php if (!empty($searchQuery)): ?>
                <div style="margin-top:var(--spacing-md);">
                    Xriqitaj <strong><?= $totalPatients; ?></strong> yawab’ (xeel)
                </div>
            <?php endif; ?>
        </div>

        <?php if (empty($paginatedPatients)): ?>
            <div class="empty-state">
                <p>Maja k’o yawab’ xel xriqitaj che: <?= htmlspecialchars($pr['label']) ?>.</p>
                <?php if ($pr['key'] !== 'all'): ?>
                    <p><a href="?action=discharged&period=all" class="btn btn-primary">Chawila ronojel</a></p>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Wachib’al</th>
                            <th>ID Yawab’</th>
                            <th>Ub’i’ Yawab’</th>
                            <th>Junab’</th>
                            <th>Achi/Ixoq</th>
                            <th>Ja</th>
                            <th>Q’ij re Elik</th>
                            <th>Wachinem</th>
                            <th>PDF</th>
                            <th>Chak</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($paginatedPatients as $patient):
                            if (!is_array($patient)) continue;

                            $links = dischargedRowLinks($patient);
                            $photoCount = isset($patient['id']) ? getPatientPhotoCount($patient['id']) : 0;
                            $hasPhoto = $photoCount > 0;
                            $hasPDF = isset($patient['pdf_archive']);
                            $hasRx = (bool)getPrescriptionItems($patient);
                            $genderClass = isset($patient['gender']) ? str_replace('_', '-', $patient['gender']) : 'prefer-not';

                            $firstPhoto = null;
                            if ($hasPhoto && isset($patient['id'])) {
                                $photos = getPatientPhotos($patient['id']);
                                $firstPhoto = !empty($photos) ? $photos[0] : null;
                            }

                            $isEncrypted = isset($patient['encrypted']) && $patient['encrypted'] === 'rot47';
                        ?>
                            <tr>
                                <td style="text-align:center;">
                                    <?php if ($hasPhoto && $firstPhoto): ?>
                                        <img src="<?= htmlspecialchars($firstPhoto['url']) ?>"
                                             alt="Wachib’al Yawab’"
                                             class="patient-photo-thumb"
                                             onclick="window.location.href='<?= htmlspecialchars($links['view'], ENT_QUOTES) ?>'"
                                             style="width:40px; height:40px; cursor:pointer;">
                                        <?php if ($photoCount > 1): ?>
                                            <span class="photo-count-badge" title="<?= $photoCount ?> ronoj wachib’al">+<?= $photoCount-1 ?></span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <div style="width:40px; height:40px; background:var(--bg-tertiary); border-radius:var(--border-radius); display:flex; align-items:center; justify-content:center; color:var(--text-muted);">📷</div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <strong><?= htmlspecialchars($patient['id'] ?? '') ?></strong>
                                    <?php if ($isEncrypted): ?>
                                        <span class="badge" title="ROT47 Yakb’al ewam" style="background:var(--warning); color:white; font-size:10px; margin-left:5px;">🔒</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars($patient['name'] ?? 'Man etaman ta') ?></td>
                                <td><?= $patient['age'] ?? '?' ?></td>
                                <td>
                                    <span class="gender-badge <?= $genderClass ?>">
                                        <?= getGenderName($patient['gender'] ?? 'prefer_not_to_say') ?>
                                    </span>
                                </td>
                                <td><?= getDeptName($patient['department'] ?? '') ?></td>
                                <td><?= isset($patient['discharge_date']) ? formatDate($patient['discharge_date']) : '' ?></td>
                                <td>
                                    <span class="status-badge status-discharged">
                                        <?= htmlspecialchars($patient['discharge']['cond'] ?? 'Maja k’o') ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($hasPDF): ?>
                                        <a href="<?= DISCHARGED_DIR . htmlspecialchars($patient['pdf_archive']) ?>" target="_blank" class="btn btn-sm">📄 Chawila</a>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <a href="<?= htmlspecialchars($links['view']) ?>" class="btn btn-sm">Chawila</a>
                                        <?php if (canReadmit()): ?>
                                            <a href="<?= htmlspecialchars($links['readmit']) ?>" class="btn btn-sm" title="Chatzalij pa yawab’"><i class="fas fa-undo"></i> Chatzalij</a>
                                        <?php endif; ?>
                                        <?php if ($hasRx): ?>
                                            <a href="<?= htmlspecialchars($links['rx']) ?>" target="_blank" class="btn btn-sm btn-primary" title="Chatz’ib’aj wujkunab’al"><i class="fas fa-prescription"></i> Chatz’ib’aj</a>
                                        <?php else: ?>
                                            <a href="<?= htmlspecialchars($links['print']) ?>" target="_blank" class="btn btn-sm" title="Maja k’o wujkunab’al - katz’ib’ax ri ch’utitzijob’al elib’al">Chatz’ib’aj ch’utitzijob’al</a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?action=discharged<?= $periodQS ?>&page=<?= $page-1 ?><?= $searchQS ?>" class="page-link">Nab’e</a>
                    <?php endif; ?>

                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <a href="?action=discharged<?= $periodQS ?>&page=<?= $i ?><?= $searchQS ?>" class="page-link <?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
                    <?php endfor; ?>

                    <?php if ($page < $totalPages): ?>
                        <a href="?action=discharged<?= $periodQS ?>&page=<?= $page+1 ?><?= $searchQS ?>" class="page-link">Kepe</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div style="margin-top:var(--spacing-xl); display:flex; gap:10px; flex-wrap:wrap;">
                <?php if (can('admin')): ?>
                    <a href="?action=export_discharged<?= $periodQS ?>" class="btn btn-primary">📥 Chesaj CSV</a>
                    <a href="?action=export_discharged&format=json<?= $periodQS ?>" class="btn btn-primary">📥 Chesaj JSON</a>
                <?php endif; ?>
                <a href="?action=discharge_photos<?= $photoDate ?>" class="btn btn-primary">Chawila Wachib’al</a>
            </div>
        <?php endif; ?>

        <div style="margin-top:30px;">
            <a href="?action=dashboard" class="btn">← Chatzalij</a>
            <a href="?action=patients" class="btn btn-primary">Yawab’ Kamik</a>
        </div>
    </div>
<?php
    showFooter();
}

function viewDischargedPatient() {
    if (!canViewDischarged()) {
        showError('Xq’ataj ri b’ixikil');
        exit;
    }
    
    $id = $_GET['id'] ?? '';
    $date = $_GET['date'] ?? '';

    if (!$id) {
        showError('Maja k’o ID yawab’ yo’om');
        return;
    }

    $patient = null;
    $sourceFile = '';

    if ($date !== '' && !archiveFileForKey($date)) $date = '';
    $found = dbDetachedPatients($date !== '' ? $date : null, $id);
    if (!$found && $date !== '') $found = dbDetachedPatients(null, $id);
    if ($found) {
        $patient = $found[0];
        $sourceFile = $patient['source_file'] ?? '';
        $date = $patient['_archive_date'] ?? '';
    }

    if (!$patient) {
        showError('Man xriqitaj ta ri yawab’ xel pa yakb’al');
        return;
    }

    $photoCount = getPatientPhotoCount($id);
    $photos = getPatientPhotos($id);
    $pdfFile = $patient['pdf_archive'] ?? null;
    $pdfPath = $pdfFile ? DISCHARGED_DIR . $pdfFile : null;
    $genderClass = isset($patient['gender']) ? str_replace('_', '-', $patient['gender']) : 'prefer-not';

    showHeader();
?>
    <div class="container">
        <div class="card">
            <div style="background:var(--primary-dark); color:var(--text-inverse); padding:var(--spacing-md); margin:-30px -30px 20px -30px; border-radius:var(--border-radius) var(--border-radius) 0 0; display:flex; justify-content:space-between; align-items:center;">
                <span>TZ’IB’ YAWAB’ YAKOM</span>
                <?php if ($pdfPath && file_exists($pdfPath)): ?>
                    <a href="<?= $pdfPath ?>" target="_blank" class="btn btn-sm" style="background:var(--text-inverse); color:var(--primary);">📄 Chawila PDF</a>
                <?php endif; ?>
            </div>

            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:var(--spacing-xl);">
                <h2 style="margin-bottom:0;">Ub’i’ Yawab’: <?= htmlspecialchars($patient['name'] ?? '') ?></h2>
                <?php if ($photoCount > 0): ?>
                    <span class="status-badge status-admitted"><?= $photoCount ?> (wachib’al)</span>
                <?php endif; ?>
            </div>

            <?php if (!empty($photos) && is_array($photos)): ?>
                <div class="photo-grid" style="margin-bottom:var(--spacing-xl);">
                    <?php foreach ($photos as $photo): ?>
                        <?php if (is_array($photo)): ?>
                        <div class="photo-card">
                            <img src="<?= htmlspecialchars($photo['url'] ?? '#') ?>" alt="Wachib’al Yawab’" onclick="window.open(this.src, '_blank')" onerror="this.onerror=null; this.src='data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'200\' height=\'150\' viewBox=\'0 0 200 150\'%3E%3Crect width=\'200\' height=\'150\' fill=\'%23f0f0f0\'/%3E%3Ctext x=\'10\' y=\'75\' font-family=\'Courier New\' font-size=\'14\' fill=\'%23999\'%3EMan%20xriqitaj%20ta%20ri%20wachib%E2%80%99al%3C/text%3E%3C/svg%3E';" title="Chapitz’a’ che unimarisaxik">
                            <div class="photo-info">
                                Xjotesax: <?= isset($photo['uploaded']) ? date(DATE_DISPLAY, $photo['uploaded']) : '' ?><br>
                                Ja: <?= htmlspecialchars($photo['room_num'] ?? '') ?><br>
                            </div>
                        </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <div class="grid grid-2">
                <div class="info-item">
                    <div class="label">ID Yawab’</div>
                    <div class="info-value"><?= htmlspecialchars($patient['id'] ?? '') ?></div>
                </div>
                <div class="info-item">
                    <div class="label">Junab’</div>
                    <div class="info-value"><?= $patient['age'] ?? '?' ?></div>
                </div>
                <div class="info-item">
                    <div class="label">Achi/Ixoq</div>
                    <div class="info-value">
                        <span class="gender-badge <?= $genderClass ?>">
                            <?= getGenderName($patient['gender'] ?? 'prefer_not_to_say') ?>
                        </span>
                    </div>
                </div>
                <div class="info-item">
                    <div class="label">Ja</div>
                    <div class="info-value"><?= getDeptName($patient['department'] ?? '') ?></div>
                </div>
                <div class="info-item">
                    <div class="label">Ajilab’al re Ja</div>
                    <div class="info-value"><?= htmlspecialchars($patient['room_num'] ?? 'Maja k’o') ?></div>
                </div>
                <div class="info-item">
                    <div class="label">Q’ij re Okib’al</div>
                    <div class="info-value"><?= isset($patient['admit_date']) ? formatDate($patient['admit_date']) : 'Maja k’o' ?></div>
                </div>
                <div class="info-item">
                    <div class="label">Q’ij re Elik</div>
                    <div class="info-value"><?= isset($patient['discharge_date']) ? formatDate($patient['discharge_date']) : 'Maja k’o' ?></div>
                </div>
                <?php if (isset($patient['detached_at'])): ?>
                <div class="info-item">
                    <div class="label">Yakom pa</div>
                    <div class="info-value"><?= formatDate($patient['detached_at']) ?></div>
                </div>
                <?php endif; ?>
            </div>

            <?php if (isset($patient['complaint']) && $patient['complaint']): ?>
                <div class="info-item">
                    <div class="label">Nima Oq’ej</div>
                    <div class="info-value"><?= nl2br(htmlspecialchars($patient['complaint'])) ?></div>
                </div>
            <?php endif; ?>

            <?php if (isset($patient['history']) && $patient['history']): ?>
                <div class="info-item">
                    <div class="label">Ojer Kunanik</div>
                    <div class="info-value"><?= nl2br(htmlspecialchars($patient['history'])) ?></div>
                </div>
            <?php endif; ?>

            <?php if (isset($patient['allergies']) && $patient['allergies']): ?>
                <div class="info-item">
                    <div class="label">Alergia</div>
                    <div class="info-value"><?= nl2br(htmlspecialchars($patient['allergies'])) ?></div>
                </div>
            <?php endif; ?>

            <?php if (isset($patient['vital_signs']) && $patient['vital_signs']): ?>
                <div class="info-item">
                    <div class="label">Retal re K’aslemal</div>
                    <div class="info-value"><?= nl2br(htmlspecialchars($patient['vital_signs'])) ?></div>
                </div>
            <?php endif; ?>

            <?php if (isset($patient['discharge'])): ?>
                <div class="info-item">
                    <div class="label">Ch’utitzijob’al Elib’al</div>
                    <div class="info-value"><?= nl2br(htmlspecialchars($patient['discharge']['summary'] ?? '')) ?></div>
                </div>
                <div class="info-item">
                    <div class="label">Wachinem are xel</div>
                    <div class="info-value"><?= htmlspecialchars($patient['discharge']['cond'] ?? '') ?></div>
                </div>
                <?php if ($patient['discharge']['follow'] ?? ''): ?>
                    <div class="info-item">
                        <div class="label">Pixab’ re Terenik</div>
                        <div class="info-value"><?= nl2br(htmlspecialchars($patient['discharge']['follow'])) ?></div>
                    </div>
                <?php endif; ?>
                <?php if (!renderPrescriptionBlock($patient) && ($patient['discharge']['meds'] ?? '')): ?>
                    <div class="info-item">
                        <div class="label">Kunab’al re Elib’al</div>
                        <div class="info-value"><?= nl2br(htmlspecialchars($patient['discharge']['meds'])) ?></div>
                    </div>
                <?php endif; ?>
                <?php if ($patient['discharge']['doctor_final_notes'] ?? ''): ?>
                    <div class="info-item">
                        <div class="label">Ruk’isb’al Tz’ib’ Ajkun</div>
                        <div class="info-value"><?= nl2br(htmlspecialchars($patient['discharge']['doctor_final_notes'])) ?></div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            <div style="margin-top:30px;display:flex;gap:10px;flex-wrap:wrap;">
                <a href="?action=discharged<?= $date ? '&date=' . $date : '' ?>" class="btn">← Chatzalij</a>
                <a href="?action=discharge_photos&date=<?= $date ?>" class="btn btn-primary">Chawila Wachib’al</a>
                <?php if ($pdfPath && file_exists($pdfPath)): ?>
                    <a href="<?= $pdfPath ?>" download class="btn btn-primary">📥 Chaqasaj PDF</a>
                <?php endif; ?>
                <?php if (canReadmit()): ?>
                    <a href="?action=readmit&id=<?= urlencode($patient['id']) ?>&date=<?= htmlspecialchars($date) ?>" class="btn"><i class="fas fa-undo"></i> Chatzalij pa yawab’</a>
                <?php endif; ?>
                <?php if (getPrescriptionItems($patient)): ?>
                    <a href="?action=prescription&id=<?= htmlspecialchars($patient['id']) ?>&discharged=1&date=<?= htmlspecialchars($date) ?>" target="_blank" class="btn btn-primary"><i class="fas fa-prescription"></i> Chatz’ib’aj Wujkunab’al</a>
                <?php endif; ?>
            </div>

            <div style="margin-top:20px; padding:10px; background:var(--bg-tertiary); border-radius:var(--border-radius); font-size:0.8rem; color:var(--text-muted);">
                <strong>Yakb’al:</strong> <?= htmlspecialchars($sourceFile) ?>
            </div>
        </div>
    </div>
<?php
    showFooter();
}

function exportDischargedPatients() {
    if (!can('admin')) {
        showError('Xq’ataj ri b’ixikil');
        exit;
    }

    $format = $_GET['format'] ?? 'csv';
    $date = $_GET['date'] ?? '';

    if ($date !== '' || isset($_GET['period'])) {
        $pr = resolveDischargePeriod();
    } else {
        $pr = ['key' => 'all', 'from' => null, 'to' => null];
    }
    $patients = getDischargedPatientsInRange($pr['from'], $pr['to']);
    foreach ($patients as &$ptRef) { unset($ptRef['_live'], $ptRef['_archive_date'], $ptRef['source_file']); }
    unset($ptRef);
    $filename = 'discharged_patients_' . $pr['key'] . ($pr['from'] ? '_' . $pr['from'] . '_' . $pr['to'] : '') . '_' . date(DATE_SHORT);

    if ($format == 'json') {
        header('Content-Type: application/json');
        header('Content-Disposition: attachment; filename="' . $filename . '.json"');
        echo json_encode($patients, JSON_PRETTY_PRINT);
        exit;
    } else {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '.csv"');
        
        $output = fopen('php://output', 'w');
        fputcsv($output, [
            'ID Yawab’', 
            'Ub’i’ Yawab’', 
            'Junab’', 
            'Achi/Ixoq',
            'Ja', 
            'Q’ij re Okib’al', 
            'Q’ij re Elik', 
            'Wachinem', 
            'K’o Uwachib’al', 
            'K’o PDF'
        ]);
        
        foreach ($patients as $pt) {
            if (!is_array($pt)) continue;
            $hasPhoto = isset($pt['id']) && getPatientPhotoCount($pt['id']) > 0 ? 'Je’' : 'Man';
            $hasPDF = isset($pt['pdf_archive']) ? 'Je’' : 'Man';
            
            fputcsv($output, [
                $pt['id'] ?? '',
                $pt['name'] ?? '',
                $pt['age'] ?? '',
                getGenderName($pt['gender'] ?? 'prefer_not_to_say'),
                getDeptName($pt['department'] ?? ''),
                $pt['admit_date'] ?? '',
                $pt['discharge_date'] ?? '',
                $pt['discharge']['cond'] ?? '',
                $hasPhoto,
                $hasPDF
            ]);
        }
        
        fclose($output);
        exit;
    }
}

// ==================== PHOTO GRID FUNCTION ====================
function showPhotoGrid() {
    if (!can('view')) {
        showError('Xq’ataj ri b’ixikil');
        exit;
    }
    showHeader();

    $p = readJSONFile($GLOBALS['pF']);
    if (!is_array($p)) $p = [];
    
    $allPhotos = [];
    $patientsWithPhotos = [];

    foreach ($p as $patient) {
        if (!is_array($patient) || !isset($patient['id'])) continue;
        
        $photos = getPatientPhotos($patient['id']);
        if (!empty($photos)) {
            $patientsWithPhotos[$patient['id']] = [
                'name' => $patient['name'] ?? 'Man etaman ta',
                'id' => $patient['id'],
                'gender' => $patient['gender'] ?? 'prefer_not_to_say',
                'room' => $patient['room_num'] ?? 'Maja k’o',
                'dept' => getDeptName($patient['department'] ?? ''),
                'status' => $patient['status'] ?? 'unknown',
                'admit_date' => $patient['admit_date'] ?? '',
                'photos' => $photos
            ];
            foreach ($photos as $photo) {
                if (is_array($photo)) {
                    $photo['patient_name'] = $patient['name'] ?? 'Man etaman ta';
                    $photo['patient_id'] = $patient['id'];
                    $photo['patient_gender'] = $patient['gender'] ?? 'prefer_not_to_say';
                    $photo['patient_status'] = $patient['status'] ?? 'unknown';
                    $allPhotos[] = $photo;
                }
            }
        }
    }

    if (can('admin') || can('logs')) {
        $dischargedDir = DISCHARGED_DIR;
        if (file_exists($dischargedDir)) {
            $dischargedFiles = getArchiveKeys();
            if (is_array($dischargedFiles)) {
                foreach ($dischargedFiles as $file) {
                    if (archiveFileForKey($file)) {
                        $patients = getDischargedPatients($file);
                        if (!is_array($patients)) continue;
                        
                        foreach ($patients as $patient) {
                            if (!is_array($patient) || !isset($patient['id'])) continue;
                            
                            $photos = getPatientPhotos($patient['id']);
                            if (!empty($photos)) {
                                $patientsWithPhotos[$patient['id']] = [
                                    'name' => $patient['name'] ?? 'Man etaman ta',
                                    'id' => $patient['id'],
                                    'gender' => $patient['gender'] ?? 'prefer_not_to_say',
                                    'room' => $patient['room_num'] ?? 'Maja k’o',
                                    'dept' => getDeptName($patient['department'] ?? ''),
                                    'status' => 'discharged',
                                    'discharge_date' => $patient['discharge_date'] ?? 'Man etaman ta',
                                    'photos' => $photos
                                ];
                                foreach ($photos as $photo) {
                                    if (is_array($photo)) {
                                        $photo['patient_name'] = $patient['name'] ?? 'Man etaman ta';
                                        $photo['patient_id'] = $patient['id'];
                                        $photo['patient_gender'] = $patient['gender'] ?? 'prefer_not_to_say';
                                        $photo['patient_status'] = 'discharged';
                                        $allPhotos[] = $photo;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (is_array($allPhotos)) {
        usort($allPhotos, function ($a, $b) {
            return ($b['uploaded'] ?? 0) - ($a['uploaded'] ?? 0);
        });
    }

    $totalPhotos = count($allPhotos);
    $totalPatients = count($patientsWithPhotos);

    $filter = $_GET['filter'] ?? 'all';
    $viewMode = $_GET['view'] ?? 'grid';
    $sort = $_GET['sort'] ?? 'newest';
    $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
    $perPage = MAX_PATIENTS_PER_PAGE;

    $filteredPhotos = $allPhotos;
    if ($filter == 'current') {
        $filteredPhotos = array_filter($allPhotos, function ($photo) {
            return ($photo['patient_status'] ?? '') != 'discharged';
        });
    } elseif ($filter == 'discharged') {
        $filteredPhotos = array_filter($allPhotos, function ($photo) {
            return ($photo['patient_status'] ?? '') == 'discharged';
        });
    }

    if (is_array($filteredPhotos)) {
        if ($sort == 'oldest') {
            usort($filteredPhotos, function ($a, $b) {
                return ($a['uploaded'] ?? 0) - ($b['uploaded'] ?? 0);
            });
        } elseif ($sort == 'patient') {
            usort($filteredPhotos, function ($a, $b) {
                return strcmp($a['patient_name'] ?? '', $b['patient_name'] ?? '');
            });
        } else {
            usort($filteredPhotos, function ($a, $b) {
                return ($b['uploaded'] ?? 0) - ($a['uploaded'] ?? 0);
            });
        }
    }

    $filteredCount = is_array($filteredPhotos) ? count($filteredPhotos) : 0;
    $totalPages = ceil($filteredCount / $perPage);
    $offset = ($page - 1) * $perPage;
    $paginatedPhotos = is_array($filteredPhotos) ? array_slice($filteredPhotos, $offset, $perPage) : [];

?>
    <style>
        /* ===== Photo Gallery: grid + list view ===== */
        #photoGrid.photo-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: var(--spacing-lg, 20px); }
        #photoGrid.photo-grid .photo-card { display: block; }
        #photoGrid.photo-grid .photo-card > img { width: 100%; height: 200px; object-fit: cover; cursor: pointer; display: block; }

        /* List view: one row per photo, thumbnail left, details right */
        #photoGrid.photo-grid.list-view { display: flex; flex-direction: column; gap: var(--spacing-md, 12px); grid-template-columns: none; }
        #photoGrid.photo-grid.list-view .photo-card { display: flex; flex-direction: row; align-items: center; gap: var(--spacing-lg, 20px); width: 100%; padding: var(--spacing-md, 12px); }
        #photoGrid.photo-grid.list-view .photo-card > img { width: 120px; height: 120px; flex: 0 0 120px; object-fit: cover; border-radius: var(--border-radius, 4px); }
        #photoGrid.photo-grid.list-view .photo-info { flex: 1; min-width: 0; display: flex; flex-wrap: wrap; align-items: center; gap: 8px 20px; text-align: left; }
        #photoGrid.photo-grid.list-view .photo-info .patient-name { flex: 1 1 180px; font-weight: 600; }
        #photoGrid.photo-grid.list-view .photo-meta { display: flex; gap: 20px; flex-wrap: wrap; margin-left: auto; }
        @media (max-width: 600px) {
            #photoGrid.photo-grid.list-view .photo-card { flex-direction: column; align-items: flex-start; }
            #photoGrid.photo-grid.list-view .photo-card > img { width: 100%; height: 180px; flex: none; }
            #photoGrid.photo-grid.list-view .photo-meta { margin-left: 0; }
        }
    </style>

    <div class="container">
        <div class="photo-grid-container">
            <div class="photo-grid-header card">
                <h2>Ronoj Wachib’al</h2>
                <div class="photo-stats">
                    <span><?= $filteredCount ?></span> wachib’al re <span><?= $totalPatients ?></span> yawab’
                    <?php if ($filteredCount != $totalPhotos): ?>
                        (xch’ay pa <?= $totalPhotos ?> ronojel)
                    <?php endif; ?>
                </div>
            </div>

            <div class="filter-bar">
                <div class="filter-group">
                    <label>Chach’ay:</label>
                    <select onchange="window.location.href='?action=photo_grid&filter='+this.value+'&view=<?= $viewMode ?>&sort=<?= $sort ?>&page=1'">
                        <option value="all" <?= $filter == 'all' ? 'selected' : '' ?>>Ronoj Wachib’al</option>
                        <option value="current" <?= $filter == 'current' ? 'selected' : '' ?>>Yawab’ Kamik</option>
                        <?php if (can('admin') || can('logs')): ?>
                            <option value="discharged" <?= $filter == 'discharged' ? 'selected' : '' ?>>Yawab’ Yakom</option>
                        <?php endif; ?>
                    </select>
                </div>

                <div class="filter-group">
                    <label>Chacholo:</label>
                    <select onchange="window.location.href='?action=photo_grid&filter=<?= $filter ?>&view=<?= $viewMode ?>&sort='+this.value+'&page=1'">
                        <option value="newest" <?= $sort == 'newest' ? 'selected' : '' ?>>K’ak’ nab’e</option>
                        <option value="oldest" <?= $sort == 'oldest' ? 'selected' : '' ?>>Ojer nab’e</option>
                        <option value="patient" <?= $sort == 'patient' ? 'selected' : '' ?>>Rumal Ub’i’ Yawab’</option>
                    </select>
                </div>

                <div class="filter-group">
                    <label>Chawila:</label>
                    <a href="?action=photo_grid&filter=<?= $filter ?>&view=grid&sort=<?= $sort ?>&page=1" class="btn <?= $viewMode == 'grid' ? 'btn-primary' : '' ?>">K’olb’al</a>
                    <a href="?action=photo_grid&filter=<?= $filter ?>&view=list&sort=<?= $sort ?>&page=1" class="btn <?= $viewMode == 'list' ? 'btn-primary' : '' ?>">Cholb’al</a>
                </div>

                <div class="search-box">
                    <input type="text" id="photoSearch" placeholder="Chatzukuj rumal ub’i’ yawab’, ID, achi/ixoq o ja..." onkeyup="searchPhotos()">
                </div>
            </div>

            <?php if (empty($paginatedPhotos)): ?>
                <div class="card" style="text-align:center; padding:var(--spacing-xxl);">
                    <p>Maja k’o wachib’al junam rik’in ri katzukuj.</p>
                    <?php if ($filter != 'all'): ?>
                        <p><a href="?action=photo_grid" class="btn btn-primary">Chesaj Ch’ayb’al</a></p>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <div id="photoGrid" class="photo-grid <?= $viewMode == 'list' ? 'list-view' : '' ?>">
                    <?php foreach ($paginatedPhotos as $photo):
                        if (!is_array($photo)) continue;
                        
                        $patientId = $photo['patient_id'] ?? '';
                        $isDischarged = ($photo['patient_status'] ?? '') == 'discharged';
                        $viewAction = $isDischarged && (can('admin') || can('logs')) ? 'view_discharged' : 'view';
                        $genderClass = isset($photo['patient_gender']) ? str_replace('_', '-', $photo['patient_gender']) : 'prefer-not';
                        
                        $displayPatientId = $patientId;
                        if (strlen($patientId) > 8) {
                            $displayPatientId = substr($patientId, 0, 8) . '…';
                        }
                    ?>
                        <div class="photo-card" data-patient="<?= strtolower(htmlspecialchars($photo['patient_name'] ?? '')) ?>" 
                             data-patient-id="<?= strtolower(htmlspecialchars($patientId)) ?>"
                             data-gender="<?= strtolower(getGenderName($photo['patient_gender'] ?? 'prefer_not_to_say')) ?>"
                             data-room="<?= strtolower(htmlspecialchars($photo['room_num'] ?? '')) ?>">
                            
                            <img src="<?= htmlspecialchars($photo['url'] ?? '#') ?>" alt="Wachib’al Yawab’" 
                                 onclick="window.location.href='?action=<?= $viewAction ?>&id=<?= $patientId ?>'" 
                                 onerror="this.onerror=null; this.src='data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'200\' height=\'150\' viewBox=\'0 0 200 150\'%3E%3Crect width=\'200\' height=\'150\' fill=\'%23f0f0f0\'/%3E%3Ctext x=\'10\' y=\'75\' font-family=\'Courier New\' font-size=\'14\' fill=\'%23999\'%3EMan%20xriqitaj%20ta%20ri%20wachib%E2%80%99al%3C/text%3E%3C/svg%3E';" 
                                 title="Chapitz’a’ che rilik ri yawab’">
                            
                            <div class="photo-info">
                                <div class="patient-name">
                                    <a href="?action=<?= $viewAction ?>&id=<?= $patientId ?>">
                                        <?= htmlspecialchars($photo['patient_name'] ?? 'Man etaman ta') ?>
                                    </a>
                                </div>
                                
                                <div style="font-size:0.8rem; color:var(--text-primary); margin:4px 0; font-family:monospace; background:var(--bg-tertiary); padding:2px 4px; border-radius:3px; display:inline-block;">
                                    ID: <?= htmlspecialchars($displayPatientId) ?>
                                </div>
                                
                                <div>
                                    <span class="gender-badge <?= $genderClass ?>" style="margin-right:5px;">
                                        <?= getGenderName($photo['patient_gender'] ?? 'prefer_not_to_say') ?>
                                    </span>
                                    <span class="status-badge <?= $isDischarged ? 'status-discharged' : 'status-admitted' ?>">
                                        <?= $isDischarged ? 'Yakom' : 'Xok' ?>
                                    </span>
                                </div>
                                
                                <div class="photo-meta">
                                    <div>Ja: <?= htmlspecialchars($photo['room_num'] ?? '') ?></div>
                                    <div class="photo-date">Xjotesax: <?= isset($photo['uploaded']) ? date(DATE_DISPLAY, $photo['uploaded']) : '' ?></div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?action=photo_grid&filter=<?= $filter ?>&view=<?= $viewMode ?>&sort=<?= $sort ?>&page=<?= $page-1 ?>" class="page-link">Nab’e</a>
                    <?php endif; ?>
                    
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <a href="?action=photo_grid&filter=<?= $filter ?>&view=<?= $viewMode ?>&sort=<?= $sort ?>&page=<?= $i ?>" class="page-link <?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
                    <?php endfor; ?>
                    
                    <?php if ($page < $totalPages): ?>
                        <a href="?action=photo_grid&filter=<?= $filter ?>&view=<?= $viewMode ?>&sort=<?= $sort ?>&page=<?= $page+1 ?>" class="page-link">Kepe</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div style="margin-top:30px;display:flex;gap:10px;justify-content:center;">
                <a href="?action=dashboard" class="btn">← Chatzalij</a>
                <a href="?action=room_photos" class="btn btn-primary">Wachib’al Ja</a>
                <?php if (can('admin') || can('logs')): ?>
                    <a href="?action=discharged" class="btn btn-primary">Yawab’ Yakom</a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        function searchPhotos() {
            const searchTerm = document.getElementById('photoSearch').value.toLowerCase();
            const photos = document.querySelectorAll('.photo-card');

            photos.forEach(photo => {
                const patientName = photo.getAttribute('data-patient') || '';
                const patientId = photo.getAttribute('data-patient-id') || '';
                const gender = photo.getAttribute('data-gender') || '';
                const roomNum = photo.getAttribute('data-room') || '';

                if (patientName.includes(searchTerm) || 
                    patientId.includes(searchTerm) || 
                    gender.includes(searchTerm) ||
                    roomNum.includes(searchTerm)) {
                    photo.style.display = '';
                } else {
                    photo.style.display = 'none';
                }
            });
        }

        document.getElementById('photoSearch').addEventListener('keyup', function(e) {
            if (e.key === 'Escape') {
                this.value = '';
                searchPhotos();
            }
        });
    </script>
<?php
    showFooter();
}

// ==================== ADD PHOTO AFTERWARDS FUNCTION ====================
function showAddPhotoForm() {
    $id = $_GET['id'] ?? '';
    if (!$id) {
        header('Location: ?action=patients');
        exit;
    }

    $p = readJSONFile($GLOBALS['pF']);
    if (!is_array($p)) $p = [];
    
    $pi = false;
    foreach ($p as $index => $pt) {
        if (is_array($pt) && ($pt['id'] ?? '') == $id) {
            $pi = $index;
            break;
        }
    }

    if ($pi === false || ($p[$pi]['status'] ?? '') !== 'admitted') {
        $_SESSION['error'] = 'Man xriqitaj ta ri yawab’';
        header('Location: ?action=patients');
        exit;
    }

    $pt = $p[$pi];
    $r = readJSONFile($GLOBALS['rF']);
    if (!is_array($r)) $r = [];
    
    $ri = false;
    foreach ($r as $index => $rm) {
        if (is_array($rm) && ($rm['id'] ?? 0) == ($pt['room_id'] ?? 0)) {
            $ri = $index;
            break;
        }
    }
    
    $roomNum = $ri !== false ? ($r[$ri]['num'] ?? '') : ($pt['room_num'] ?? '');

    $existingPhotos = getPatientPhotos($id);
    $photoCount = is_array($existingPhotos) ? count($existingPhotos) : 0;
    
    showHeader();
?>
    <div class="container">
        <div class="form-container">
            <h2>Chatz’aqatisaj Wachib’al Yawab’</h2>

            <div class="patient-info">
                <p><strong>Ub’i’ Yawab’:</strong> <?= htmlspecialchars($pt['name'] ?? '') ?></p>
                <p><strong>ID Yawab’:</strong> <?= htmlspecialchars($pt['id'] ?? '') ?></p>
                <p><strong>Achi/Ixoq:</strong> <?= getGenderName($pt['gender'] ?? 'prefer_not_to_say') ?></p>
                <p><strong>Ajilab’al re Ja:</strong> <?= htmlspecialchars($roomNum) ?></p>
                <p><strong>Wachib’al Kamik:</strong> <?= $photoCount ?></p>
            </div>

            <?php if (!empty($existingPhotos) && is_array($existingPhotos)): ?>
                <div class="card" style="margin-bottom:var(--spacing-xl);">
                    <h3>Wachib’al K’o</h3>
                    <div class="photo-grid" style="grid-template-columns:repeat(auto-fill, minmax(100px, 1fr));">
                        <?php foreach ($existingPhotos as $photo): ?>
                            <?php if (is_array($photo)): ?>
                            <div class="photo-card" style="padding:var(--spacing-sm);">
                                <img src="<?= htmlspecialchars($photo['url'] ?? '#') ?>" alt="Wachib’al Yawab’" onclick="window.open(this.src, '_blank')" style="height:80px;" title="Xjotesax: <?= isset($photo['uploaded']) ? date(DATE_DISPLAY, $photo['uploaded']) : '' ?>">
                            </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

            <form method="POST" action="?action=add_photo" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <input type="hidden" name="patient_id" value="<?= $id ?>">
                <input type="hidden" name="room_num" value="<?= htmlspecialchars($roomNum) ?>">

                <div class="form-group">
                    <div class="photo-upload-area" id="photoDropArea">
                        <p>Chakelesaj chaya ri wachib’al waral o chapitz’a’ che rucha’ik</p>
                        <p class="photo-info">Nim nimal: <?= getMaxUploadSize() ?> | PNG o JPG (kajalwachix pa PNG rumal)</p>
                        <button type="button" class="btn" id="cameraButton" style="margin-top:var(--spacing-sm);">Chakuj Cámara</button>
                    </div>

                    <input type="file" name="patient_photo" id="photoInput" accept="image/png,image/jpeg,image/webp" style="display:none;">

                    <div id="photoPreviewContainer" style="text-align:center; margin-top:var(--spacing-lg);">
                        <img id="photoPreview" class="photo-preview" src="#" alt="Nab’e ilik" style="max-width:300px; max-height:300px; border:2px solid var(--border-color); display:none; margin:0 auto; border-radius:var(--border-radius);">
                        <button type="button" id="removePhoto" class="btn btn-danger" style="display:none; margin-top:var(--spacing-md);">Chesaj</button>
                    </div>
                </div>

                <div style="display:flex;gap:15px;margin-top:30px;justify-content:center;">
                    <button type="submit" name="add_patient_photo" class="btn btn-primary">Chajotesaj Wachib’al</button>
                    <a href="?action=view&id=<?= $id ?>" class="btn" style="background:var(--text-muted); color:var(--text-inverse);">Chatanab’a</a>
                </div>
            </form>
        </div>
    </div>

    <script>
(function () {
    var LIMIT = <?= (int)getEffectiveUploadLimit() ?>;
    var input = document.getElementById('photoInput');
    var area = document.getElementById('photoDropArea');
    var preview = document.getElementById('photoPreview');
    var removeBtn = document.getElementById('removePhoto');
    var camBtn = document.getElementById('cameraButton');

    // No fixed "capture": otherwise phones only open the camera and never the gallery/files.
    input.removeAttribute('capture');
    input.setAttribute('accept', 'image/png,image/jpeg,image/webp');

    // Always deliver a PNG that fits the server limit (phone photos are converted + scaled down)
    function toPng(file) {
        return new Promise(function (resolve, reject) {
            var url = URL.createObjectURL(file);
            var img = new Image();
            img.onload = function () {
                URL.revokeObjectURL(url);
                var w = img.naturalWidth, h = img.naturalHeight;
                if (file.type === 'image/png' && file.size <= LIMIT && Math.max(w, h) <= 2000) { resolve(file); return; }
                var sizes = [1600, 1280, 1024, 800, 640, 480], i = 0;
                (function attempt() {
                    var max = sizes[i], sc = Math.min(1, max / Math.max(w, h));
                    var c = document.createElement('canvas');
                    c.width = Math.max(1, Math.round(w * sc)); c.height = Math.max(1, Math.round(h * sc));
                    c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
                    c.toBlob(function (blob) {
                        if (!blob) { reject(new Error('Man xjalwachix ta ri wachib’al')); return; }
                        if (blob.size <= LIMIT) {
                            var name = (file.name || 'photo').replace(/\.[^.]+$/, '') + '.png';
                            resolve(new File([blob], name, { type: 'image/png' }));
                        } else if (i >= sizes.length - 1) {
                            reject(new Error('Ri wachib’al nim na stape’ xch’utinarisax'));
                        } else { i++; attempt(); }
                    }, 'image/png');
                })();
            };
            img.onerror = function () { URL.revokeObjectURL(url); reject(new Error('We wuj ri’ man wachib’al ta kasik’ix (ri browser man kuk’ul ta HEIC - chacha’ JPG o PNG)')); };
            img.src = url;
        });
    }

    function setFile(file) {
        if (!file) return;
        if (!/^image\//.test(file.type) && !/\.(png|jpe?g|webp)$/i.test(file.name)) { alert('Chacha’ jun wachib’al PNG o JPG.'); return; }
        toPng(file).then(function (png) {
            var dt = new DataTransfer(); dt.items.add(png); input.files = dt.files;
            var reader = new FileReader();
            reader.onload = function (e) {
                preview.src = e.target.result; preview.style.display = 'block';
                area.style.display = 'none'; removeBtn.style.display = 'inline-block';
            };
            reader.readAsDataURL(png);
        }).catch(function (err) { alert(err.message); input.value = ''; });
    }

    function reset() {
        input.value = ''; preview.src = '#'; preview.style.display = 'none';
        area.style.display = 'block'; removeBtn.style.display = 'none';
    }

    area.addEventListener('click', function () { input.removeAttribute('capture'); input.click(); });
    camBtn.addEventListener('click', function (e) { e.stopPropagation(); input.setAttribute('capture', 'environment'); input.click(); });
    input.addEventListener('change', function () { setFile(input.files[0]); });
    removeBtn.addEventListener('click', reset);
    area.addEventListener('dragover', function (e) { e.preventDefault(); area.style.background = 'var(--bg-tertiary)'; });
    area.addEventListener('dragleave', function (e) { e.preventDefault(); area.style.background = 'var(--bg-secondary)'; });
    area.addEventListener('drop', function (e) {
        e.preventDefault(); area.style.background = 'var(--bg-secondary)';
        setFile(e.dataTransfer.files[0]);
    });
})();
    </script>
<?php
    showFooter();
}

function addPatientPhoto() {
    if (!can('edit')) {
        $_SESSION['error'] = 'Xq’ataj ri b’ixikil';
        header('Location: ?action=patients');
        exit;
    }

    $patientId = $_POST['patient_id'] ?? '';
    $roomNum = $_POST['room_num'] ?? '';

    if (!$patientId || !$roomNum) {
        $_SESSION['error'] = 'Maja k’o retal yawab’';
        header('Location: ?action=patients');
        exit;
    }

    $p = readJSONFile($GLOBALS['pF']);
    if (!is_array($p)) $p = [];
    
    $pi = false;
    foreach ($p as $index => $pt) {
        if (is_array($pt) && ($pt['id'] ?? '') == $patientId) {
            $pi = $index;
            break;
        }
    }

    if ($pi === false || ($p[$pi]['status'] ?? '') !== 'admitted') {
        $_SESSION['error'] = 'Man xriqitaj ta ri yawab’';
        header('Location: ?action=patients');
        exit;
    }

    $photoInfo = handlePhotoUpload($patientId, $roomNum);

    if (!$photoInfo['success']) {
        $_SESSION['error'] = 'Wachib’al: jotesaxik man xel ta: ' . $photoInfo['message'];
        header('Location: ?action=add_photo&id=' . urlencode($patientId));
        exit;
    }

    $p[$pi]['has_photo'] = true;
    if (!isset($p[$pi]['photo_count'])) {
        $p[$pi]['photo_count'] = 1;
    } else {
        $p[$pi]['photo_count']++;
    }

    writeJSONFile($GLOBALS['pF'], $p);

    logMsg("Wachib’al xtz’aqatisax che yawab’ {$p[$pi]['name']} ($patientId): " . $photoInfo['filename']);

    $_SESSION['success'] = 'Wachib’al utz xjotesax';
    header('Location: ?action=view&id=' . urlencode($patientId));
    exit;
}

// ==================== DISCHARGE PHOTOS FUNCTION ====================
function showDischargePhotos() {
    if (!canViewDischarged()) {
        showError('Xq’ataj ri b’ixikil');
        exit;
    }
    showHeader();

    $dischargeDate = $_GET['date'] ?? '';
    $dischargedFile = archiveFileForKey($dischargeDate);

    if (!$dischargedFile || !in_array($dischargeDate, getArchiveKeys(), true)) {
        $dischargeDates = getArchiveKeys();
        $datesWithPhotos = [];

        foreach ($dischargeDates as $date) {
            $patients = getDischargedPatients($date);
            $hasPhotos = false;
            foreach ($patients as $patient) {
                if (is_array($patient) && isset($patient['id']) && getPatientPhotoCount($patient['id']) > 0) {
                    $hasPhotos = true;
                    break;
                }
            }
            if ($hasPhotos) {
                $datesWithPhotos[] = $date;
            }
        }

        showDischargeDateSelector($datesWithPhotos);
        return;
    }

    $dischargedPatients = getDischargedPatients($dischargeDate);
    if (!is_array($dischargedPatients)) $dischargedPatients = [];
    
    $patientsWithPhotos = [];

    foreach ($dischargedPatients as $patient) {
        if (!is_array($patient) || !isset($patient['id'])) continue;
        
        $photos = getPatientPhotos($patient['id']);
        if (!empty($photos)) {
            $patientsWithPhotos[] = [
                'patient' => $patient,
                'photos' => $photos
            ];
        }
    }

    $dischargeDates = getArchiveKeys();

?>
    <div class="container">
        <div class="card">
            <h2>Wachib’al re Elib’al Yakom - <?= archiveKeyLabel($dischargeDate) ?></h2>

            <div class="filter-bar" style="margin-bottom:var(--spacing-xl);">
                <form method="GET" action="" class="filter-group">
                    <input type="hidden" name="action" value="discharge_photos">
                    <label for="date">Chacha’ Q’ij:</label>
                    <select name="date" id="date" onchange="this.form.submit()">
                        <?php foreach ($dischargeDates as $date): ?>
                            <option value="<?= $date ?>" <?= $date == $dischargeDate ? 'selected' : '' ?>>
                                <?= archiveKeyLabel($date) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </form>
            </div>

            <div class="stats">
                <p><strong>Ronoj Yakom:</strong> <?= count($dischargedPatients) ?></p>
                <p><strong>Yawab’ rachi’ Wachib’al:</strong> <?= count($patientsWithPhotos) ?></p>
            </div>

            <?php if (empty($patientsWithPhotos)): ?>
                <p style="text-align:center;padding:40px;">Maja k’o wachib’al xriqitaj che yawab’ yakom pa we q’ij ri’.</p>
            <?php else: ?>
                <?php foreach ($patientsWithPhotos as $item):
                    $patient = $item['patient'] ?? [];
                    $photos = $item['photos'] ?? [];
                    if (!is_array($patient) || empty($photos)) continue;
                    $genderClass = isset($patient['gender']) ? str_replace('_', '-', $patient['gender']) : 'prefer-not';
                ?>
                    <div class="card" style="margin-bottom:var(--spacing-xl);">
                        <div style="background:var(--primary-dark); color:var(--text-inverse); padding:var(--spacing-md); margin:-20px -20px 20px -20px; border-radius:var(--border-radius) var(--border-radius) 0 0;">
                            <strong><?= htmlspecialchars($patient['name'] ?? 'Man etaman ta') ?></strong> (ID: <?= $patient['id'] ?? '' ?>)<br>
                            <span class="gender-badge <?= $genderClass ?>">
                                <?= getGenderName($patient['gender'] ?? 'prefer_not_to_say') ?>
                            </span>
                            Ja <?= $patient['room_num'] ?? 'Man etaman ta' ?> | Wachinem: <?= $patient['discharge']['cond'] ?? 'Maja k’o' ?>
                        </div>
                        <div class="photo-grid">
                            <?php foreach ($photos as $photo): ?>
                                <?php if (is_array($photo)): ?>
                                <div class="photo-card">
                                    <img src="<?= htmlspecialchars($photo['url'] ?? '#') ?>" alt="Wachib’al Yawab’" onclick="window.open(this.src, '_blank')" onerror="this.onerror=null; this.src='data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'200\' height=\'150\' viewBox=\'0 0 200 150\'%3E%3Crect width=\'200\' height=\'150\' fill=\'%23f0f0f0\'/%3E%3Ctext x=\'10\' y=\'75\' font-family=\'Courier New\' font-size=\'14\' fill=\'%23999\'%3EMan%20xriqitaj%20ta%20ri%20wachib%E2%80%99al%3C/text%3E%3C/svg%3E';" title="Chapitz’a’ che unimarisaxik">
                                    <div class="photo-info">
                                        Xjotesax: <?= isset($photo['uploaded']) ? date(DATE_DISPLAY, $photo['uploaded']) : '' ?><br>
                                    </div>
                                    <a href="?action=view_discharged&id=<?= $patient['id'] ?? '' ?>&date=<?= $dischargeDate ?>" class="btn btn-sm" style="margin-top:5px;">Chawila Tz’ib’</a>
                                </div>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

            <div style="margin-top:20px;display:flex;gap:10px;">
                <a href="?action=discharged&date=<?= $dischargeDate ?>" class="btn">← Chawila Yakb’al</a>
                <a href="?action=photo_grid&filter=discharged" class="btn btn-primary">Chawila Ronoj Wachib’al Yakom</a>
                <a href="?action=dashboard" class="btn">Nab’e wuj</a>
            </div>
        </div>
    </div>
<?php
    showFooter();
}

function showDischargeDateSelector($datesWithPhotos) {
?>
    <div class="container">
        <div class="card">
            <h2>Wachib’al re Elib’al Yakom</h2>

            <?php if (empty($datesWithPhotos)): ?>
                <p style="text-align:center;padding:40px;">Maja k’o q’ij re elib’al yakom rachi’ wachib’al xriqitaj.</p>
            <?php else: ?>
                <p>Chacha’ jun q’ij:</p>
                <div class="grid grid-4">
                    <?php foreach ($datesWithPhotos as $date):
                        $patients = getDischargedPatients($date);
                        $photoCount = 0;
                        foreach ($patients as $patient) {
                            if (is_array($patient) && isset($patient['id'])) {
                                $photoCount += getPatientPhotoCount($patient['id']);
                            }
                        }
                    ?>
                        <div class="card" style="text-align:center;">
                            <a href="?action=discharge_photos&date=<?= $date ?>" style="text-decoration:none; color:var(--text-primary);">
                                <strong><?= archiveKeyLabel($date) ?></strong>
                                <div class="status-badge status-admitted" style="margin-top:var(--spacing-sm);"><?= $photoCount ?> wachib’al</div>
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <div style="margin-top:var(--spacing-xl);">
                <a href="?action=photo_grid&filter=discharged" class="btn btn-primary">Chawila Ronoj Wachib’al Yakom</a>
            </div>
        </div>
    </div>
<?php
    showFooter();
}

// ==================== LOG PHOTOS FUNCTION ====================
function showLogPhotos() {
    if (!can('logs')) {
        showError('Xq’ataj ri b’ixikil');
        exit;
    }
    showHeader();

    $photoEvents = [];

    foreach (getActivityLog(5000, 'photo') as $e) {
        preg_match('/Room (\d+)/', $e['msg'], $roomMatches);
        $photoEvents[] = [
            'line' => $e['line'],
            'timestamp' => $e['time'],
            'patient_id' => $e['patient_id'] ?: logPatientId($e['msg']),
            'room_num' => $roomMatches[1] ?? null
        ];
    }

    $patientIds = array_unique(array_filter(array_column($photoEvents, 'patient_id')));
    $patientsWithPhotos = [];

    foreach ($patientIds as $pid) {
        $photos = getPatientPhotos($pid);
        if (!empty($photos)) {
            $patientsWithPhotos[$pid] = $photos;
        }
    }

    $p = readJSONFile($GLOBALS['pF']);
    if (!is_array($p)) $p = [];
    
    $patientNames = [];
    foreach ($p as $pt) {
        if (is_array($pt) && isset($pt['id'])) {
            $patientNames[$pt['id']] = $pt['name'] ?? 'Man etaman ta';
        }
    }

    if (can('admin')) {
        $dischargedDir = DISCHARGED_DIR;
        if (file_exists($dischargedDir)) {
            $files = getArchiveKeys();
            if (is_array($files)) {
                foreach ($files as $file) {
                    if (archiveFileForKey($file)) {
                        $patients = getDischargedPatients($file);
                        if (is_array($patients)) {
                            foreach ($patients as $pt) {
                                if (is_array($pt) && isset($pt['id'])) {
                                    $patientNames[$pt['id']] = $pt['name'] ?? 'Man etaman ta';
                                }
                            }
                        }
                    }
                }
            }
        }
    }

?>
    <div class="container">
        <div class="card">
            <h2>Tz’ib’ re Chak Wachib’al</h2>

            <div class="tabs">
                <span class="tab active" onclick="showTab('logs')">Tz’ib’ re Chak</span>
                <span class="tab" onclick="showTab('photos')">Wachib’al Kamik</span>
            </div>

            <div id="logs" class="tab-content active">
                <div class="stats">
                    <p><strong>Ronoj K’ulmatajem Wachib’al:</strong> <?= count($photoEvents) ?></p>
                    <p><strong>Yawab’ Junwi:</strong> <?= count($patientIds) ?></p>
                </div>

                <?php if (empty($photoEvents)): ?>
                    <p>Maja k’o chak rech wachib’al xriqitaj pa tz’ib’.</p>
                <?php else: ?>
                    <div style="background:var(--primary); color:var(--text-inverse); padding:var(--spacing-md); font-family:monospace; max-height:500px; overflow-y:auto; border-radius:var(--border-radius);">
                        <?php foreach ($photoEvents as $event): ?>
                            <div style="padding:var(--spacing-xs) 0; border-bottom:1px solid var(--border-dark);">
                                <?= htmlspecialchars($event['line']) ?>
                                <?php if ($event['patient_id']): ?>
                                    <a href="?action=view&id=<?= $event['patient_id'] ?>" class="btn btn-sm" style="margin-left:10px; background:var(--primary-dark); color:var(--text-inverse); border-color:var(--text-inverse);">Chawila Yawab’</a>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <div id="photos" class="tab-content">
                <div class="stats">
                    <p><strong>Yawab’ rachi’ Wachib’al:</strong> <?= count($patientsWithPhotos) ?></p>
                </div>

                <?php if (empty($patientsWithPhotos)): ?>
                    <p>Maja k’o wachib’al kechakun xriqitaj che yawab’ b’im pa tz’ib’.</p>
                <?php else: ?>
                    <?php foreach ($patientsWithPhotos as $pid => $photos):
                        $patientName = $patientNames[$pid] ?? 'Yawab’ Man Etaman Ta';
                    ?>
                        <div class="card" style="margin-bottom:var(--spacing-lg);">
                            <h3><?= htmlspecialchars($patientName) ?> (ID: <?= $pid ?>)</h3>
                            <div class="photo-grid">
                                <?php foreach ($photos as $photo): ?>
                                    <?php if (is_array($photo)): ?>
                                    <div class="photo-card">
                                        <img src="<?= htmlspecialchars($photo['url'] ?? '#') ?>" alt="Wachib’al Yawab’" onclick="window.open(this.src, '_blank')" onerror="this.onerror=null; this.src='data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'200\' height=\'150\' viewBox=\'0 0 200 150\'%3E%3Crect width=\'200\' height=\'150\' fill=\'%23f0f0f0\'/%3E%3Ctext x=\'10\' y=\'75\' font-family=\'Courier New\' font-size=\'14\' fill=\'%23999\'%3EMan%20xriqitaj%20ta%20ri%20wachib%E2%80%99al%3C/text%3E%3C/svg%3E';" title="Chapitz’a’ che unimarisaxik">
                                        <div class="photo-info">
                                            Xjotesax: <?= isset($photo['uploaded']) ? date(DATE_SHORT, $photo['uploaded']) : '' ?><br>
                                            Ja: <?= $photo['room_num'] ?? '' ?><br>
                                        </div>
                                        <a href="?action=view&id=<?= $pid ?>" class="btn btn-sm">Chawila Yawab’</a>
                                    </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <script>
                function showTab(tabName) {
                    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
                    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
                    event.target.classList.add('active');
                    document.getElementById(tabName).classList.add('active');
                }
            </script>

            <div style="margin-top:var(--spacing-xl);">
                <a href="?action=logs" class="btn">← Ronoj Tz’ib’ Ucholajil</a>
                <a href="?action=photo_grid" class="btn btn-primary">Ronoj Wachib’al</a>
            </div>
        </div>
    </div>
<?php
    showFooter();
}

// ==================== ROOM PHOTOS FUNCTION ====================
function showRoomPhotos() {
    if (!can('view')) {
        showError('Xq’ataj ri b’ixikil');
        exit;
    }
    showHeader();

    $roomNum = $_GET['room'] ?? '';
    if (!$roomNum) {
        $allPhotos = getAllPhotos();
        $photosByRoom = [];
        if (is_array($allPhotos)) {
            foreach ($allPhotos as $photo) {
                if (!is_array($photo)) continue;
                $room = $photo['room_num'] ?? '';
                if (!isset($photosByRoom[$room])) {
                    $photosByRoom[$room] = [];
                }
                $photosByRoom[$room][] = $photo;
            }
        }

        $r = readJSONFile($GLOBALS['rF']);
        if (!is_array($r)) $r = [];
        
        $roomInfo = [];
        foreach ($r as $rm) {
            if (is_array($rm) && isset($rm['num'])) {
                $roomInfo[$rm['num']] = $rm;
            }
        }

        showAllRoomsPhotos($photosByRoom, $roomInfo);
        return;
    }

    $photos = getPatientPhotos(null, $roomNum);
    $r = readJSONFile($GLOBALS['rF']);
    if (!is_array($r)) $r = [];
    
    $roomInfo = null;
    foreach ($r as $rm) {
        if (is_array($rm) && ($rm['num'] ?? '') == $roomNum) {
            $roomInfo = $rm;
            break;
        }
    }

    if (!$roomInfo) {
        showError('Man xriqitaj ta ri ja');
        exit;
    }

    $patientPhotos = [];
    if (is_array($photos)) {
        foreach ($photos as $photo) {
            if (!is_array($photo)) continue;
            $patientId = $photo['patient_id'] ?? '';
            if (!isset($patientPhotos[$patientId])) {
                $patientPhotos[$patientId] = [];
            }
            $patientPhotos[$patientId][] = $photo;
        }
    }

    $p = readJSONFile($GLOBALS['pF']);
    if (!is_array($p)) $p = [];
    
    $patientNames = [];
    foreach ($p as $pt) {
        if (is_array($pt) && isset($pt['id'])) {
            $patientNames[$pt['id']] = $pt['name'] ?? 'Man etaman ta';
        }
    }

?>
    <div class="container">
        <a href="?action=rooms" class="btn" style="margin-bottom:var(--spacing-lg);">← Chatzalij</a>

        <div class="card">
            <div style="background:var(--primary); color:var(--text-inverse); padding:var(--spacing-lg); margin:-30px -30px 20px -30px; border-radius:var(--border-radius) var(--border-radius) 0 0;">
                <h2 style="color:var(--text-inverse);">Ja <?= htmlspecialchars($roomNum) ?> - <?= getDeptName($roomInfo['dept'] ?? '') ?></h2>
                <p>Ronoj Wachib’al: <?= is_array($photos) ? count($photos) : 0 ?> | Yawab’: <?= count($patientPhotos) ?></p>
            </div>

            <?php if (empty($photos)): ?>
                <p style="text-align:center;padding:40px;">Maja k’o wachib’al xriqitaj che we ja ri’.</p>
            <?php else: ?>
                <?php foreach ($patientPhotos as $patientId => $patientPhotoList):
                    $patientName = $patientNames[$patientId] ?? 'Yawab’ Man Etaman Ta';
                ?>
                    <div class="card" style="margin-bottom:var(--spacing-xl);">
                        <div style="background:var(--primary-dark); color:var(--text-inverse); padding:var(--spacing-md); margin:-20px -20px 20px -20px; border-radius:var(--border-radius) var(--border-radius) 0 0;">
                            <strong><?= htmlspecialchars($patientName) ?></strong> (ID: <?= htmlspecialchars($patientId) ?>) - <?= count($patientPhotoList) ?> (wachib’al)
                        </div>
                        <div class="photo-grid">
                            <?php foreach ($patientPhotoList as $photo): ?>
                                <?php if (is_array($photo)): ?>
                                <div class="photo-card">
                                    <img src="<?= htmlspecialchars($photo['url'] ?? '#') ?>" alt="Wachib’al Yawab’" onclick="window.open(this.src, '_blank')" onerror="this.onerror=null; this.src='data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'200\' height=\'150\' viewBox=\'0 0 200 150\'%3E%3Crect width=\'200\' height=\'150\' fill=\'%23f0f0f0\'/%3E%3Ctext x=\'10\' y=\'75\' font-family=\'Courier New\' font-size=\'14\' fill=\'%23999\'%3EMan%20xriqitaj%20ta%20ri%20wachib%E2%80%99al%3C/text%3E%3C/svg%3E';" title="Chapitz’a’ che unimarisaxik">
                                    <div class="photo-info">
                                        Xjotesax: <?= isset($photo['uploaded']) ? date(DATE_DISPLAY, $photo['uploaded']) : '' ?><br>
                                        Nimal: <?= round(($photo['size'] ?? 0) / 1024, 1) ?> KB<br>
                                    </div>
                                    <a href="?action=view&id=<?= $patientId ?>" class="btn btn-sm">Chawila Yawab’</a>
                                    <?php if (can('edit')): ?>
                                        <a href="?action=add_photo&id=<?= $patientId ?>" class="btn btn-sm btn-primary">Chatz’aqatisaj Wachib’al</a>
                                    <?php endif; ?>
                                </div>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
<?php
    showFooter();
}

function showAllRoomsPhotos($photosByRoom, $roomInfo) {
?>
    <div class="container">
        <div class="card">
            <h2>Ronoj Wachib’al Ja</h2>

            <div class="stats">
                <p><strong>Ronoj Wachib’al:</strong> <?= array_sum(array_map('count', $photosByRoom)) ?></p>
                <p><strong>Ja rachi’ Wachib’al:</strong> <?= count($photosByRoom) ?></p>
            </div>

            <?php if (empty($photosByRoom)): ?>
                <p style="text-align:center;padding:40px;">Maja k’o wachib’al xriqitaj pa jun ja.</p>
            <?php else: ?>
                <div class="grid grid-3">
                    <?php foreach ($photosByRoom as $roomNum => $photos):
                        $room = $roomInfo[$roomNum] ?? null;
                    ?>
                        <div class="card">
                            <h3>Ja <?= htmlspecialchars($roomNum) ?>
                                <?php if ($room): ?>
                                    <br><small><?= getDeptName($room['dept'] ?? '') ?></small>
                                <?php endif; ?>
                            </h3>
                            <div class="card-stats"><?= count($photos) ?> wachib’al</div>
                            <a href="?action=room_photos&room=<?= urlencode($roomNum) ?>" class="btn btn-primary">Chawila Wachib’al</a>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <div style="margin-top:var(--spacing-xl);">
                <a href="?action=rooms" class="btn">← Chatzalij</a>
                <a href="?action=photo_grid" class="btn btn-primary">Ronoj Wachib’al</a>
            </div>
        </div>
    </div>
<?php
    showFooter();
}

// ==================== STATISTICS FUNCTIONS ====================
function showStatistics() {
    if (!can('stats')) {
        showError('Xq’ataj ri b’ixikil');
        exit;
    }
    showHeader();

    $s = readJSONFile($GLOBALS['sF']);
    if (!is_array($s)) $s = ['daily' => [], 'weekly' => [], 'monthly' => [], 'yearly' => []];
    
    $tf = $_GET['timeframe'] ?? 'daily';
    $p = $_GET['period'] ?? date(DATE_SHORT);

    $ta = 0;
    $td = 0;

    $allPatients = readJSONFile($GLOBALS['pF']);
    if (!is_array($allPatients)) $allPatients = [];

    foreach ($allPatients as $patient) {
        if (!is_array($patient)) continue;
        if (isset($patient['status'])) {
            if ($patient['status'] == 'admitted') {
                $ta++;
            } elseif ($patient['status'] == 'discharged') {
                $td++;
            }
        }
    }

    if (can('admin')) {
        $dischargedDir = DISCHARGED_DIR;
        if (file_exists($dischargedDir)) {
            $dischargedFiles = getArchiveKeys();
            if (is_array($dischargedFiles)) {
                foreach ($dischargedFiles as $file) {
                    if (archiveFileForKey($file)) {
                        $patients = getDischargedPatients($file);
                        if (is_array($patients)) {
                            $td += count($patients);
                            $ta += count($patients);
                        }
                    }
                }
            }
        }
    }

    $pd = $s[$tf][$p] ?? [];
    $ds = $pd['depts'] ?? [];
    $tr = calcTrends($s, $tf, $p);

    // Gender statistics if enabled
    $genderStats = [];
    if (shouldIncludeGenderInStats()) {
        $genderStats = [
            'male' => 0,
            'female' => 0,
            'transgender_mtf' => 0,
            'transgender_ftm' => 0,
            'non_binary' => 0,
            'genderqueer' => 0,
            'intersex' => 0,
            'other' => 0,
            'prefer_not_to_say' => 0
        ];
        
        foreach ($allPatients as $patient) {
            if (!is_array($patient)) continue;
            $gender = $patient['gender'] ?? 'prefer_not_to_say';
            if (isset($genderStats[$gender])) {
                $genderStats[$gender]++;
            } else {
                $genderStats['other']++;
            }
        }
    }

?>
    <div class="container">
        <h1>Ajilanik</h1>

        <div class="grid grid-3" style="margin-bottom:var(--spacing-xl);">
            <div class="card">
                <div class="card-label">Ronoj Xeok (Ronoj Ramaj)</div>
                <div class="card-stats"><?= $ta ?></div>
            </div>
            <div class="card">
                <div class="card-label">Ronoj Xeel (Ronoj Ramaj)</div>
                <div class="card-stats"><?= $td ?></div>
            </div>
            <div class="card">
                <div class="card-label">Yawab’ Kamik</div>
                <div class="card-stats"><?= $ta - $td ?></div>
            </div>
        </div>

        <?php if (!empty($genderStats) && array_sum($genderStats) > 0): ?>
        <div class="card" style="margin-bottom:var(--spacing-xl);">
            <h3>Ajilab’al Yawab’</h3>
            <div class="grid grid-3">
                <?php foreach ($genderStats as $gender => $count): 
                    if ($count == 0) continue;
                    $percentage = $ta > 0 ? round(($count / $ta) * 100, 1) : 0;
                    $genderClass = str_replace('_', '-', $gender);
                ?>
                    <div class="card">
                        <div class="card-label">
                            <span class="gender-badge <?= $genderClass ?>"><?= getGenderName($gender) ?></span>
                        </div>
                        <div class="card-stats"><?= $count ?></div>
                        <div style="text-align:center;"><?= $percentage ?>%</div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <div class="card" style="margin-bottom:var(--spacing-lg);">
            <h3>Chacha’ Ramaj</h3>
            <div class="btn-group">
                <a href="?action=statistics&timeframe=daily&period=<?= date(DATE_SHORT) ?>" class="btn <?= $tf == 'daily' ? 'btn-primary' : '' ?>">Chi jujun q’ij</a>
                <a href="?action=statistics&timeframe=weekly&period=<?= date('Y-W') ?>" class="btn <?= $tf == 'weekly' ? 'btn-primary' : '' ?>">Chi jujun wuqq q’ij</a>
                <a href="?action=statistics&timeframe=monthly&period=<?= date('Y-m') ?>" class="btn <?= $tf == 'monthly' ? 'btn-primary' : '' ?>">Chi jujun ik’</a>
                <a href="?action=statistics&timeframe=yearly&period=<?= date('Y') ?>" class="btn <?= $tf == 'yearly' ? 'btn-primary' : '' ?>">Chi jujun junab’</a>
            </div>
            <?php if ($tf == 'daily'): ?>
                <div style="margin-top:var(--spacing-md);">
                    <label>Chacha’ Q’ij:</label>
                    <input type="date" id="datePicker" value="<?= $p ?>" onchange="window.location.href='?action=statistics&timeframe=daily&period='+this.value">
                </div>
            <?php endif; ?>
        </div>

        <div class="grid grid-2" style="margin-bottom:var(--spacing-xl);">
            <div class="card">
                <h3><?= formatPeriod($tf, $p) ?> Ronoj ilik</h3>
                <div class="card-stats"><?= ($pd['admitted'] ?? 0) + ($pd['discharged'] ?? 0) ?></div>
                <p style="text-align:center;">Xok: <strong><?= $pd['admitted'] ?? 0 ?></strong><br>Xel: <strong><?= $pd['discharged'] ?? 0 ?></strong></p>
            </div>
            <div class="card">
                <h3>Tzukunik re Ub’e</h3>
                <?php if (!empty($tr) && is_array($tr)): ?>
                    <p><strong>Ub’e Okib’al:</strong> <span><?= ($tr['admitted_trend'] ?? 0) >= 0 ? '📈' : '📉' ?> <?= abs($tr['admitted_trend'] ?? 0) ?>% <?= ($tr['admitted_trend'] ?? 0) >= 0 ? 'kk’iyar' : 'kqaj' ?></span></p>
                    <p><strong>Ub’e Elib’al:</strong> <span><?= ($tr['discharged_trend'] ?? 0) >= 0 ? '📈' : '📉' ?> <?= abs($tr['discharged_trend'] ?? 0) ?>% <?= ($tr['discharged_trend'] ?? 0) >= 0 ? 'kk’iyar' : 'kqaj' ?></span></p>
                <?php else: ?>
                    <p>Maja k’o retal ub’e</p>
                <?php endif; ?>
            </div>
        </div>

        <?php if (!empty($ds) && is_array($ds)): ?>
            <div class="card" style="margin-bottom:var(--spacing-xl);">
                <h3>Jachom chi jujun ja</h3>
                <div class="grid">
                    <?php foreach ($ds as $d => $dd): ?>
                        <?php if (is_array($dd)): ?>
                        <div class="card">
                            <strong><?= getDeptName($d) ?></strong><br>
                            Xok: <?= $dd['admitted'] ?? 0 ?><br>
                            Xel: <?= $dd['discharged'] ?? 0 ?>
                        </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <div class="card">
            <h3>Ojer Retal</h3>
            <div class="table-container">
                <table class="stats-table">
                    <thead>
                        <tr>
                            <th>Ramaj</th>
                            <th>Xok</th>
                            <th>Xel</th>
                            <th>Ronoj Jalwachinik</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $limit = 10;
                        $count = 0;
                        foreach (array_reverse($s[$tf] ?? []) as $pk => $d):
                            if (!is_array($d)) continue;
                            if ($count >= $limit) break;
                            $nc = ($d['admitted'] ?? 0) - ($d['discharged'] ?? 0);
                        ?>
                            <tr>
                                <td><?= formatPeriod($tf, $pk) ?></td>
                                <td><?= $d['admitted'] ?? 0 ?></td>
                                <td><?= $d['discharged'] ?? 0 ?></td>
                                <td><?= $nc >= 0 ? '+' : '' ?><?= $nc ?></td>
                            </tr>
                        <?php $count++;
                        endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div style="margin-top:20px;">
            <a href="?action=dashboard" class="btn">← Chatzalij</a>
            <?php if (can('admin')): ?>
                <a href="?action=discharged" class="btn btn-primary">Yawab’ Yakom</a>
            <?php endif; ?>
        </div>
    </div>
<?php
    showFooter();
}

function formatPeriod($tf, $p) {
    switch ($tf) {
        case 'daily':
            return date(DATE_DISPLAY, strtotime($p));
        case 'weekly':
            $parts = explode('-', $p);
            $y = $parts[0] ?? '';
            $w = $parts[1] ?? '';
            return "Wuqq $w, $y";
        case 'monthly':
            return date('F Y', strtotime($p . '-01'));
        case 'yearly':
            return "Junab’ $p";
        default:
            return $p;
    }
}

function calcTrends($s, $tf, $cp) {
    if (!is_array($s) || !isset($s[$tf])) return [];
    
    $ps = array_keys($s[$tf]);
    $ci = array_search($cp, $ps);
    if ($ci === false || $ci < 1) return [];
    
    $cd = $s[$tf][$cp];
    $pd = $s[$tf][$ps[$ci - 1]];
    
    if (!is_array($cd) || !is_array($pd)) return [];
    
    $at = ($pd['admitted'] ?? 0) > 0 ? (($cd['admitted'] ?? 0) - ($pd['admitted'] ?? 0)) / ($pd['admitted'] ?? 1) * 100 : 0;
    $dt = ($pd['discharged'] ?? 0) > 0 ? (($cd['discharged'] ?? 0) - ($pd['discharged'] ?? 0)) / ($pd['discharged'] ?? 1) * 100 : 0;
    
    return ['admitted_trend' => round($at, 1), 'discharged_trend' => round($dt, 1)];
}

// ==================== ORIGINAL FUNCTIONS ====================
function showDash() {
    $r = readJSONFile($GLOBALS['rF']);
    if (!is_array($r)) $r = [];
    
    $p = readJSONFile($GLOBALS['pF']);
    if (!is_array($p)) $p = [];
    
    $tr = count($r);
    $tb = 0;
    $ob = 0;
    
    foreach ($r as $rm) {
        if (is_array($rm)) {
            $tb += $rm['beds'] ?? 0;
            $ob += $rm['occ'] ?? 0;
        }
    }
    $ab = $tb - $ob;
    
    $tp = 0;
    $genderBreakdown = [];
    if (shouldShowGenderInList()) {
        $genderBreakdown = [
            'male' => 0,
            'female' => 0,
            'transgender_mtf' => 0,
            'transgender_ftm' => 0,
            'non_binary' => 0,
            'genderqueer' => 0,
            'intersex' => 0,
            'other' => 0,
            'prefer_not_to_say' => 0
        ];
    }
    
    foreach ($p as $pt) {
        if (is_array($pt) && isset($pt['status']) && $pt['status'] == 'admitted') {
            $tp++;
            if (shouldShowGenderInList() && isset($pt['gender'])) {
                $gender = $pt['gender'];
                if (isset($genderBreakdown[$gender])) {
                    $genderBreakdown[$gender]++;
                } else {
                    $genderBreakdown['other']++;
                }
            }
        }
    }

    $totalDischarged = 0;
    $totalPDFs = 0;
    if (can('admin')) {
        $dischargedDir = DISCHARGED_DIR;
        if (file_exists($dischargedDir)) {
            $dischargedFiles = getArchiveKeys();
            if (is_array($dischargedFiles)) {
                foreach ($dischargedFiles as $f) {
                    if (archiveFileForKey($f)) {
                        $fp = getDischargedPatients($f);
                        if (is_array($fp)) {
                            $totalDischarged += count($fp);
                            foreach ($fp as $pt) {
                                if (isset($pt['pdf_archive'])) {
                                    $totalPDFs++;
                                }
                            }
                        }
                    }
                }
            }
            
            $pdfFiles = glob($dischargedDir . '*.pdf');
            if (is_array($pdfFiles)) {
                $totalPDFs = max($totalPDFs, count($pdfFiles));
            }
        }
    }

    $totalPhotos = count(getAllPhotos());
    
    showHeader();
?>
    <div class="container">
        <h2>Nab’e wuj</h2>
        <div class="grid grid-4">
            <div class="card">
                <div class="card-label">Ronoj Ja</div>
                <div class="card-stats"><?= $tr ?></div>
            </div>
            <div class="card">
                <div class="card-label">Ronoj Warab’al</div>
                <div class="card-stats"><?= $tb ?></div>
            </div>
            <div class="card">
                <div class="card-label">Warab’al k’o Winaq</div>
                <div class="card-stats"><?= $ob ?></div>
            </div>
            <div class="card">
                <div class="card-label">Warab’al Tolon</div>
                <div class="card-stats"><?= $ab ?></div>
            </div>
            <div class="card">
                <div class="card-label">Yawab’ Kamik</div>
                <div class="card-stats"><?= $tp ?></div>
            </div>
            <?php if (shouldShowGenderInList() && !empty($genderBreakdown) && $tp > 0): ?>
                <div class="card">
                    <div class="card-label">Jachom pa Achi/Ixoq</div>
                    <div style="font-size:0.8rem;">
                        <?php 
                        $topGender = '';
                        $topCount = 0;
                        foreach ($genderBreakdown as $g => $c) {
                            if ($c > $topCount) {
                                $topCount = $c;
                                $topGender = $g;
                            }
                        }
                        if ($topGender && $topCount > 0) {
                            echo '<span class="gender-badge ' . str_replace('_', '-', $topGender) . '">' . getGenderName($topGender) . '</span><br>';
                            echo round(($topCount / $tp) * 100) . '% re yawab’';
                        }
                        ?>
                    </div>
                </div>
            <?php endif; ?>
            <?php if (can('admin')): ?>
                <div class="card">
                    <div class="card-label">Yawab’ Yakom</div>
                    <div class="card-stats"><?= $totalDischarged ?></div>
                </div>
                <div class="card">
                    <div class="card-label">PDF Yakom</div>
                    <div class="card-stats"><?= $totalPDFs ?></div>
                </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-label">Ronoj Wachib’al</div>
                <div class="card-stats"><?= $totalPhotos ?></div>
            </div>
        </div>
        <?php if (shouldRunAutoArchive()): ?>
            <div class="alert alert-success" style="text-align:center;">
                ⏰ Yakb’al rumal kachakun <?= archiveScheduleText() ?>
            </div>
        <?php endif; ?>
        <?php if (can('stats')): ?>
            <div style="margin-top:30px;text-align:center;display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
                <a href="?action=statistics" class="btn btn-primary">Ajilanik</a>
                <a href="?action=room_photos" class="btn btn-primary">Wachib’al Ja</a>
                <a href="?action=photo_grid" class="btn btn-primary">Ronoj Wachib’al</a>
                <?php if (can('admin')): ?>
                    <a href="?action=discharged" class="btn btn-primary">Yawab’ Yakom</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
<?php
    showFooter();
}

function showPatients() {
    $p = readJSONFile($GLOBALS['pF']);
    if (!is_array($p)) {
        $p = [];
        logMsg("PIXAB: Ri retal yawab’ man cholb’al ta, xjalwachix pa jun cholb’al maja k’o");
    }
    
    $r = readJSONFile($GLOBALS['rF']);
    if (!is_array($r)) {
        $r = [];
        logMsg("PIXAB: Ri retal ja man cholb’al ta, xjalwachix pa jun cholb’al maja k’o");
    }
    
    $rl = [];
    foreach ($r as $rm) {
        if (is_array($rm) && isset($rm['id'])) {
            $rl[$rm['id']] = $rm;
        }
    }

    $p = array_filter($p, function($pt) {
        return is_array($pt) && isset($pt['status']) && $pt['status'] === 'admitted';
    });

    $patientsWithPhotos = [];
    $photoCounts = [];
    $patientPhotos = [];
    
    if (is_array($p)) {
        foreach ($p as $pt) {
            if (!is_array($pt) || !isset($pt['id'])) {
                continue;
            }
            
            $photos = getPatientPhotos($pt['id']);
            $count = is_array($photos) ? count($photos) : 0;
            if ($count > 0) {
                $patientsWithPhotos[$pt['id']] = true;
                $photoCounts[$pt['id']] = $count;
                if (isset($photos[0]) && is_array($photos[0])) {
                    $patientPhotos[$pt['id']] = $photos[0];
                }
            }
        }
    }

    $searchQuery = $_GET['search'] ?? '';
    $searchType = $_GET['search_type'] ?? 'all';
    $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
    $perPage = MAX_PATIENTS_PER_PAGE;
    
    $filteredPatients = is_array($p) ? $p : [];
    if (!empty($searchQuery) && is_array($filteredPatients)) {
        $filteredPatients = array_filter($filteredPatients, function($pt) use ($searchQuery, $searchType, $rl, $photoCounts) {
            if (!is_array($pt)) return false;
            
            $searchLower = strtolower($searchQuery);
            
            switch ($searchType) {
                case 'id':
                    return isset($pt['id']) && stripos($pt['id'], $searchQuery) !== false;
                
                case 'name':
                    return isset($pt['name']) && stripos($pt['name'], $searchQuery) !== false;
                
                case 'gender':
                    $genderName = isset($pt['gender']) ? getGenderName($pt['gender']) : '';
                    return stripos($genderName, $searchQuery) !== false;
                
                case 'room':
                    $roomNum = '';
                    if (isset($pt['room_id']) && isset($rl[$pt['room_id']])) {
                        $roomNum = $rl[$pt['room_id']]['num'] ?? '';
                    }
                    return stripos($roomNum, $searchQuery) !== false;
                
                case 'department':
                    $deptName = isset($pt['department']) ? getDeptName($pt['department']) : '';
                    return stripos($deptName, $searchQuery) !== false;
                
                case 'status':
                    return isset($pt['status']) && stripos($pt['status'], $searchQuery) !== false;
                
                case 'complaint':
                    return isset($pt['complaint']) && stripos($pt['complaint'], $searchQuery) !== false;
                
                case 'has_photo':
                    $hasPhoto = isset($pt['id']) && ($photoCounts[$pt['id']] ?? 0) > 0;
                    $searchTerm = strtolower($searchQuery);
                    return ($hasPhoto && ($searchTerm === 'yes' || $searchTerm === '1' || $searchTerm === 'true')) ||
                           (!$hasPhoto && ($searchTerm === 'no' || $searchTerm === '0' || $searchTerm === 'false'));
                
                case 'all':
                default:
                    $roomNum = '';
                    if (isset($pt['room_id']) && isset($rl[$pt['room_id']])) {
                        $roomNum = $rl[$pt['room_id']]['num'] ?? '';
                    }
                    $deptName = isset($pt['department']) ? getDeptName($pt['department']) : '';
                    $genderName = isset($pt['gender']) ? getGenderName($pt['gender']) : '';
                    $hasPhoto = isset($pt['id']) && ($photoCounts[$pt['id']] ?? 0) > 0 ? 'yes' : 'no';
                    $complaint = isset($pt['complaint']) ? $pt['complaint'] : '';
                    
                    return (isset($pt['id']) && stripos($pt['id'], $searchQuery) !== false) ||
                           (isset($pt['name']) && stripos($pt['name'], $searchQuery) !== false) ||
                           stripos($genderName, $searchQuery) !== false ||
                           stripos($roomNum, $searchQuery) !== false ||
                           stripos($deptName, $searchQuery) !== false ||
                           (isset($pt['status']) && stripos($pt['status'], $searchQuery) !== false) ||
                           stripos($hasPhoto, $searchQuery) !== false ||
                           stripos($complaint, $searchQuery) !== false;
            }
        });
    }

    if (!is_array($filteredPatients)) {
        $filteredPatients = [];
    }

    $totalPatients = count($filteredPatients);
    $totalPages = ceil($totalPatients / $perPage);
    $offset = ($page - 1) * $perPage;
    $paginatedPatients = array_slice($filteredPatients, $offset, $perPage);

    $patientsByRoom = [];
    $roomDetails = [];
    
    foreach ($paginatedPatients as $pt) {
        if (!is_array($pt)) continue;
        
        $roomId = $pt['room_id'] ?? 0;
        $roomNum = $rl[$roomId]['num'] ?? 'Man etaman ta';
        $deptCode = $rl[$roomId]['dept'] ?? $pt['department'] ?? '';
        $deptName = getDeptName($deptCode);
        
        if (!isset($patientsByRoom[$roomId])) {
            $patientsByRoom[$roomId] = [
                'room_num' => $roomNum,
                'dept' => $deptName,
                'dept_code' => $deptCode,
                'total_beds' => $rl[$roomId]['beds'] ?? 0,
                'occupied' => $rl[$roomId]['occ'] ?? 0,
                'patients' => []
            ];
            
            $roomDetails[$roomId] = $rl[$roomId] ?? null;
        }
        
        $patientsByRoom[$roomId]['patients'][] = $pt;
    }

    uasort($patientsByRoom, function($a, $b) {
        if ($a['dept'] == $b['dept']) {
            return strnatcmp($a['room_num'], $b['room_num']);
        }
        return strcmp($a['dept'], $b['dept']);
    });

    showHeader();
?>
    <style>
        /* Room Group Styling */
        .room-group {
            margin-bottom: var(--spacing-xl);
            background: var(--bg-primary);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            overflow: hidden;
            box-shadow: var(--shadow-sm);
        }

        .room-group-header {
            background: var(--bg-tertiary);
            padding: var(--spacing-md) var(--spacing-lg);
            border-bottom: 2px solid var(--primary);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: var(--spacing-md);
        }

        .room-title {
            display: flex;
            align-items: center;
            gap: var(--spacing-md);
            flex-wrap: wrap;
        }

        .room-number {
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--text-primary);
            background: var(--bg-primary);
            padding: var(--spacing-xs) var(--spacing-md);
            border-radius: var(--border-radius);
            border: 1px solid var(--border-color);
        }

        .room-department {
            font-size: 0.9rem;
            color: var(--text-muted);
            font-weight: 500;
        }

        .room-stats {
            display: flex;
            gap: var(--spacing-lg);
            align-items: center;
        }

        .bed-stat {
            display: flex;
            align-items: center;
            gap: var(--spacing-xs);
            background: var(--bg-primary);
            padding: var(--spacing-xs) var(--spacing-md);
            border-radius: var(--border-radius);
            border: 1px solid var(--border-color);
            font-size: 0.9rem;
        }

        .bed-stat.available {
            border-left-color: var(--success);
        }

        .bed-stat.full {
            border-left-color: var(--danger);
        }

        .bed-stat.limited {
            border-left-color: var(--warning);
        }

        .photo-stat {
            display: flex;
            align-items: center;
            gap: var(--spacing-xs);
            color: var(--text-muted);
            font-size: 0.85rem;
        }

        .table-wrapper {
            padding: var(--spacing-lg);
            overflow-x: auto;
        }

        .patient-table {
            width: 100%;
            border-collapse: collapse;
        }

        .patient-table th {
            background: var(--bg-tertiary);
            color: var(--text-primary);
            font-weight: 600;
            font-size: 0.875rem;
            padding: var(--spacing-sm) var(--spacing-md);
            text-align: left;
            border-bottom: 2px solid var(--border-color);
            white-space: nowrap;
        }

        .patient-table td {
            padding: var(--spacing-sm) var(--spacing-md);
            border-bottom: 1px solid var(--border-light);
            color: var(--text-secondary);
            font-size: 0.875rem;
            vertical-align: middle;
        }

        .patient-table tbody tr:hover td {
            background: var(--bg-secondary);
        }

        .patient-table tbody tr:last-child td {
            border-bottom: none;
        }

        .photo-cell {
            width: 60px;
            text-align: center;
        }

        .photo-indicator {
            position: relative;
            display: inline-block;
        }

        .photo-count-badge-sm {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--primary);
            color: var(--text-inverse);
            font-size: 0.6rem;
            font-weight: 600;
            width: 16px;
            height: 16px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 1px solid var(--bg-primary);
        }

        .room-footer {
            padding: var(--spacing-md) var(--spacing-lg);
            border-top: 1px dashed var(--border-color);
            text-align: right;
        }

        .complaint-cell {
            max-width: 250px;
        }

        .complaint-text {
            display: inline-block;
            background: var(--bg-tertiary);
            padding: 2px var(--spacing-xs);
            border-radius: var(--border-radius);
            font-size: 0.8rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: 200px;
            border: 1px solid var(--border-color);
        }

        .complaint-text:hover {
            white-space: normal;
            overflow: visible;
            background: var(--bg-primary);
            box-shadow: var(--shadow-md);
            position: relative;
            z-index: 10;
            max-width: none;
        }

        .dept-badge {
            display: inline-block;
            background: var(--bg-tertiary);
            padding: 2px var(--spacing-xs);
            border-radius: var(--border-radius);
            font-size: 0.75rem;
            font-weight: 500;
        }

        .room-summary {
            display: flex;
            gap: var(--spacing-lg);
            margin-bottom: var(--spacing-lg);
            flex-wrap: wrap;
        }

        .summary-item {
            display: flex;
            align-items: center;
            gap: var(--spacing-xs);
            background: var(--bg-primary);
            padding: var(--spacing-xs) var(--spacing-md);
            border-radius: var(--border-radius);
            border: 1px solid var(--border-color);
            font-size: 0.85rem;
        }

        .summary-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            display: inline-block;
        }

        .summary-dot.available { background: var(--success); }
        .summary-dot.limited { background: var(--warning); }
        .summary-dot.full { background: var(--danger); }

        .pagination-info {
            text-align: center;
            margin: var(--spacing-md) 0;
            color: var(--text-muted);
        }
    </style>

    <div class="container">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:var(--spacing-lg); flex-wrap:wrap; gap:var(--spacing-md);">
            <div>
                <h2 style="margin-bottom:var(--spacing-xs);">Yawab’ Kamik</h2>
                <p class="text-muted"><?= $totalPatients ?> yawab’ pa <?= count($patientsByRoom) ?> ja</p>
            </div>
            <div class="btn-group">
                <a href="?action=room_photos" class="btn btn-primary">Wachib’al Ja</a>
                <a href="?action=photo_grid" class="btn btn-primary">Ronoj Wachib’al</a>
                <?php if (can('admin')): ?>
                    <a href="?action=discharged" class="btn btn-primary">Yawab’ Yakom</a>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="card" style="margin-bottom:var(--spacing-xl);">
            <h3>Chatzukuj Yawab’</h3>
            <form method="GET" action="">
                <input type="hidden" name="action" value="patients">
                <div class="filter-bar" style="margin:0;">
                    <div class="filter-group" style="flex:2;">
                        <label for="search">Chatzukuj:</label>
                        <input type="text" id="search" name="search" value="<?= htmlspecialchars($searchQuery) ?>" placeholder="Chaya tzij che tzukunik...">
                    </div>
                    <div class="filter-group">
                        <label for="search_type">Pa:</label>
                        <select id="search_type" name="search_type">
                            <option value="all" <?= $searchType == 'all' ? 'selected' : '' ?>>Ronoj Ucholaj</option>
                            <option value="id" <?= $searchType == 'id' ? 'selected' : '' ?>>ID Yawab’</option>
                            <option value="name" <?= $searchType == 'name' ? 'selected' : '' ?>>Ub’i’ Yawab’</option>
                            <option value="gender" <?= $searchType == 'gender' ? 'selected' : '' ?>>Achi/Ixoq</option>
                            <option value="room" <?= $searchType == 'room' ? 'selected' : '' ?>>Ajilab’al re Ja</option>
                            <option value="department" <?= $searchType == 'department' ? 'selected' : '' ?>>Ja</option>
                            <option value="complaint" <?= $searchType == 'complaint' ? 'selected' : '' ?>>Nima Oq’ej</option>
                            <option value="has_photo" <?= $searchType == 'has_photo' ? 'selected' : '' ?>>K’o Uwachib’al</option>
                        </select>
                    </div>
                    <div class="btn-group">
                        <button type="submit" class="btn btn-primary">Chatzukuj</button>
                        <?php if (!empty($searchQuery)): ?>
                            <a href="?action=patients" class="btn">Chesaj</a>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
            <?php if (!empty($searchQuery)): ?>
                <div style="margin-top:var(--spacing-md);">
                    Xriqitaj <strong><?= $totalPatients; ?></strong> (yawab’)
                </div>
            <?php endif; ?>
        </div>
        
        <p class="text-muted" style="margin-bottom:var(--spacing-lg);">Yawab’ xeel rumal kyakon <?= archiveScheduleText() ?>.</p>

        <div class="room-summary">
            <div class="summary-item">
                <span class="summary-dot available"></span>
                <span>K’o Warab’al Tolon</span>
            </div>
            <div class="summary-item">
                <span class="summary-dot limited"></span>
                <span>Xa jub’iq’ Tolon (≤2 warab’al)</span>
            </div>
            <div class="summary-item">
                <span class="summary-dot full"></span>
                <span>Nojinaq / Maja k’o Warab’al</span>
            </div>
        </div>

        <?php if (empty($paginatedPatients)): ?>
            <div class="empty-state">
                <p>Maja k’o yawab’ kamik junam rik’in ri katzukuj.</p>
                <?php if (!empty($searchQuery)): ?>
                    <p><a href="?action=patients" class="btn btn-primary">Chesaj Tzukunik</a></p>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <?php foreach ($patientsByRoom as $roomId => $room): 
                $availableBeds = $room['total_beds'] - $room['occupied'];
                $bedStatusClass = $availableBeds == 0 ? 'full' : ($availableBeds <= 2 ? 'limited' : 'available');
                $roomPhotoCount = 0;
                
                foreach ($room['patients'] as $pt) {
                    $roomPhotoCount += $photoCounts[$pt['id']] ?? 0;
                }
            ?>
                <div class="room-group">
                    <div class="room-group-header">
                        <div class="room-title">
                            <span class="room-number">Ja <?= htmlspecialchars($room['room_num']) ?></span>
                            <span class="room-department">
                                <?= htmlspecialchars($room['dept']) ?>
                            </span>
                        </div>
                        <div class="room-stats">
                            <span class="bed-stat <?= $bedStatusClass ?>">
                                <span>🛏️</span>
                                <?= $room['occupied'] ?>/<?= $room['total_beds'] ?> warab’al
                                <?php if ($availableBeds > 0): ?>
                                    (<?= $availableBeds ?> tolon)
                                <?php else: ?>
                                    (Nojinaq)
                                <?php endif; ?>
                            </span>
                            <?php if ($roomPhotoCount > 0): ?>
                                <span class="photo-stat">
                                    <span>📸</span> <?= $roomPhotoCount ?> wachib’al
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="table-wrapper">
                        <table class="patient-table">
                            <thead>
                                <tr>
                                    <th>Wachib’al</th>
                                    <th>ID Yawab’</th>
                                    <th>Ub’i’ Yawab’</th>
                                    <th>Junab’</th>
                                    <?php if (shouldShowGenderInList()): ?>
                                    <th>Achi/Ixoq</th>
                                    <?php endif; ?>
                                    <th>Ja</th>
                                    <th>Ja</th>
                                    <th>Nima Oq’ej</th>
                                    <th>Wachinem</th>
                                    <th>Chak</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($room['patients'] as $pt):
                                    $hasPhoto = isset($pt['id']) && isset($patientsWithPhotos[$pt['id']]);
                                    $photoCount = isset($pt['id']) ? ($photoCounts[$pt['id']] ?? 0) : 0;
                                    $firstPhoto = isset($pt['id']) ? ($patientPhotos[$pt['id']] ?? null) : null;
                                    $complaint = isset($pt['complaint']) ? trim($pt['complaint']) : '';
                                    $genderClass = isset($pt['gender']) ? str_replace('_', '-', $pt['gender']) : 'prefer-not';
                                ?>
                                    <tr>
                                        <td class="photo-cell">
                                            <div class="photo-indicator">
                                                <?php if ($hasPhoto && $firstPhoto && is_array($firstPhoto) && isset($firstPhoto['url'])): ?>
                                                    <img src="<?= htmlspecialchars($firstPhoto['url']) ?>" 
                                                         alt="Wachib’al Yawab’" 
                                                         class="patient-photo-thumb"
                                                         onclick="window.location.href='?action=view&id=<?= htmlspecialchars($pt['id'] ?? '') ?>'"
                                                         onerror="this.onerror=null; this.src='data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'40\' height=\'40\' viewBox=\'0 0 40 40\'%3E%3Crect width=\'40\' height=\'40\' fill=\'%23f0f0f0\'/%3E%3Ctext x=\'14\' y=\'26\' font-family=\'Courier New\' font-size=\'14\' fill=\'%23999\'%3E?%3C/text%3E%3C/svg%3E';"
                                                         style="width:40px; height:40px;">
                                                <?php else: ?>
                                                    <div style="width:40px; height:40px; background:var(--bg-tertiary); border-radius:var(--border-radius); display:flex; align-items:center; justify-content:center; color:var(--text-muted); font-weight:600; border:1px solid var(--border-color);">
                                                        <?= substr($pt['name'] ?? '?', 0, 1) ?>
                                                    </div>
                                                <?php endif; ?>
                                                <?php if ($photoCount > 1): ?>
                                                    <span class="photo-count-badge-sm"><?= $photoCount ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        
                                        <td><strong><?= htmlspecialchars($pt['id'] ?? '') ?></strong></td>
                                        
                                        <td>
                                            <a href="?action=view&id=<?= htmlspecialchars($pt['id'] ?? '') ?>" style="color:var(--text-primary); text-decoration:none; font-weight:500;">
                                                <?= htmlspecialchars($pt['name'] ?? 'Man etaman ta') ?>
                                            </a>
                                        </td>
                                        
                                        <td><?= $pt['age'] ?? '?' ?></td>
                                        
                                        <?php if (shouldShowGenderInList()): ?>
                                        <td>
                                            <span class="gender-badge <?= $genderClass ?>">
                                                <?= getGenderName($pt['gender'] ?? 'prefer_not_to_say') ?>
                                            </span>
                                        </td>
                                        <?php endif; ?>
                                        
                                        <td><span class="dept-badge"><?= htmlspecialchars($room['dept']) ?></span></td>
                                        
                                        <td>Ja <?= htmlspecialchars($room['room_num']) ?></td>
                                        
                                        <td class="complaint-cell">
                                            <?php if (!empty($complaint)): ?>
                                                <span class="complaint-text" title="<?= htmlspecialchars($complaint) ?>">
                                                    <?= htmlspecialchars(substr($complaint, 0, 30)) ?><?= strlen($complaint) > 30 ? '…' : '' ?>
                                                </span>
                                            <?php else: ?>
                                                <span style="color:var(--text-muted); font-style:italic;">Maja k’o</span>
                                            <?php endif; ?>
                                        </td>
                                        
                                        <td>
                                            <span class="status-badge status-admitted">Xok</span>
                                        </td>
                                        
                                        <td>
                                            <div class="btn-group" style="justify-content:flex-end;">
                                                <a href="?action=view&id=<?= htmlspecialchars($pt['id'] ?? '') ?>" class="btn btn-sm">Chawila</a>
                                                <?php if (can('edit') && isset($pt['id'])): ?>
                                                    <a href="?action=edit&id=<?= htmlspecialchars($pt['id']) ?>" class="btn btn-sm">Chutzirisaj</a>
                                                <?php endif; ?>
                                                <?php if (can('move') && isset($pt['id'])): ?>
                                                    <a href="?action=change&id=<?= htmlspecialchars($pt['id']) ?>" class="btn btn-sm">Chajalwachij Ja</a>
                                                <?php endif; ?>
                                                <?php if (can('discharge') && isset($pt['id'])): ?>
                                                    <a href="?action=discharge&id=<?= htmlspecialchars($pt['id']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Chesaj we yawab’ ri’?')">Chesaj</a>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <?php if (can('admit') && $availableBeds > 0): ?>
                        <div class="room-footer">
                            <a href="?action=admit&room_id=<?= $roomId ?>" class="btn btn-success btn-sm">
                                <span style="margin-right:4px;">➕</span> Chok’ama pa Ja <?= htmlspecialchars($room['room_num']) ?>
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>

            <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?action=patients&page=<?= $page-1 ?><?= !empty($searchQuery) ? '&search=' . urlencode($searchQuery) . '&search_type=' . $searchType : '' ?>" class="page-link">Nab’e</a>
                    <?php endif; ?>
                    
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <a href="?action=patients&page=<?= $i ?><?= !empty($searchQuery) ? '&search=' . urlencode($searchQuery) . '&search_type=' . $searchType : '' ?>" class="page-link <?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
                    <?php endfor; ?>
                    
                    <?php if ($page < $totalPages): ?>
                        <a href="?action=patients&page=<?= $page+1 ?><?= !empty($searchQuery) ? '&search=' . urlencode($searchQuery) . '&search_type=' . $searchType : '' ?>" class="page-link">Kepe</a>
                    <?php endif; ?>
                </div>
                <div class="pagination-info">
                    Kak’ut <?= $offset + 1 ?> - <?= min($offset + $perPage, $totalPatients) ?> chi kiwach <?= $totalPatients ?> yawab’
                </div>
            <?php endif; ?>

            <?php if (shouldRunAutoArchive()): ?>
                <div class="alert alert-success" style="margin-top:var(--spacing-lg);">
                    ⏰ Yakb’al rumal kachakun <?= archiveScheduleText() ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
<?php
    showFooter();
}

function showPatient() {
    $id = $_GET['id'] ?? '';
    $discharged = $_GET['discharged'] ?? 0;
    $ad = $_GET['date'] ?? '';

    if (!$id) {
        showError('Maja k’o yawab’');
        return;
    }

    if ($discharged) {
        if (!canViewDischarged()) {
            showError('Xq’ataj ri b’ixikil');
            return;
        }
        
        $patient = null;
        if ($ad) {
            $patients = getDischargedPatients($ad);
            foreach ($patients as $pt) {
                if (is_array($pt) && ($pt['id'] ?? '') == $id) {
                    $patient = $pt;
                    break;
                }
            }
        } else {
            $allDischarged = getDischargedPatients();
            foreach ($allDischarged as $pt) {
                if (is_array($pt) && ($pt['id'] ?? '') == $id) {
                    $patient = $pt;
                    break;
                }
            }
        }
        
        if (!$patient) {
            showError('Man xriqitaj ta ri yawab’');
            return;
        }
    } else {
        $p = readJSONFile($GLOBALS['pF']);
        if (!is_array($p)) $p = [];
        
        $pi = false;
        foreach ($p as $index => $pt) {
            if (is_array($pt) && ($pt['id'] ?? '') == $id) {
                $pi = $index;
                break;
            }
        }
        
        if ($pi === false) {
            showError('Man xriqitaj ta ri yawab’');
            return;
        }
        $patient = $p[$pi];
    }

    $r = readJSONFile($GLOBALS['rF']);
    if (!is_array($r)) $r = [];
    
    $ri = false;
    foreach ($r as $index => $rm) {
        if (is_array($rm) && ($rm['id'] ?? 0) == ($patient['room_id'] ?? 0)) {
            $ri = $index;
            break;
        }
    }
    
    $rm = $ri !== false ? $r[$ri] : null;

    $photos = getPatientPhotos($id);
    $photoCount = is_array($photos) ? count($photos) : 0;
    
    $pdfFile = $patient['pdf_archive'] ?? null;
    $pdfPath = $pdfFile ? DISCHARGED_DIR . $pdfFile : null;
    
    $genderClass = isset($patient['gender']) ? str_replace('_', '-', $patient['gender']) : 'prefer-not';

    showHeader();
?>
    <div class="container">
        <div class="card">
            <?php if ($discharged): ?>
                <div style="background:var(--primary-dark); color:var(--text-inverse); padding:var(--spacing-md); margin:-30px -30px 20px -30px; border-radius:var(--border-radius) var(--border-radius) 0 0; display:flex; justify-content:space-between; align-items:center;">
                    <span>TZ’IB’ YAWAB’ YAKOM</span>
                    <?php if ($pdfPath && file_exists($pdfPath)): ?>
                        <a href="<?= $pdfPath ?>" target="_blank" class="btn btn-sm" style="background:var(--text-inverse); color:var(--primary);">📄 Chawila PDF</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:var(--spacing-xl);">
                <h2 style="margin-bottom:0;">Ub’i’ Yawab’: <?= htmlspecialchars($patient['name'] ?? '') ?></h2>
                <?php if ($photoCount > 0): ?>
                    <span class="status-badge status-admitted"><?= $photoCount ?> (wachib’al)</span>
                <?php endif; ?>
            </div>

            <?php if (!empty($photos) && is_array($photos)): ?>
                <div class="photo-grid" style="margin-bottom:var(--spacing-xl);">
                    <?php foreach ($photos as $photo): ?>
                        <?php if (is_array($photo)): ?>
                        <div class="photo-card">
                            <img src="<?= htmlspecialchars($photo['url'] ?? '#') ?>" alt="Wachib’al Yawab’" onclick="window.open(this.src, '_blank')" onerror="this.onerror=null; this.src='data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'200\' height=\'150\' viewBox=\'0 0 200 150\'%3E%3Crect width=\'200\' height=\'150\' fill=\'%23f0f0f0\'/%3E%3Ctext x=\'10\' y=\'75\' font-family=\'Courier New\' font-size=\'14\' fill=\'%23999\'%3EMan%20xriqitaj%20ta%20ri%20wachib%E2%80%99al%3C/text%3E%3C/svg%3E';" title="Chapitz’a’ che unimarisaxik">
                            <div class="photo-info">
                                Xjotesax: <?= isset($photo['uploaded']) ? date(DATE_DISPLAY, $photo['uploaded']) : '' ?><br>
                                Ja: <?= htmlspecialchars($photo['room_num'] ?? '') ?><br>
                            </div>
                        </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <div class="grid grid-2">
                <div class="info-item">
                    <div class="label">ID Yawab’</div>
                    <div class="info-value"><?= htmlspecialchars($patient['id'] ?? '') ?></div>
                </div>
                <div class="info-item">
                    <div class="label">Junab’</div>
                    <div class="info-value"><?= $patient['age'] ?? '?' ?></div>
                </div>
                <div class="info-item">
                    <div class="label">Achi/Ixoq</div>
                    <div class="info-value">
                        <span class="gender-badge <?= $genderClass ?>">
                            <?= getGenderName($patient['gender'] ?? 'prefer_not_to_say') ?>
                        </span>
                    </div>
                </div>
                <div class="info-item">
                    <div class="label">Ja</div>
                    <div class="info-value"><?= getDeptName($patient['department'] ?? '') ?></div>
                </div>
                <?php if (!$discharged && $rm): ?>
                    <div class="info-item">
                        <div class="label">Ajilab’al re Ja</div>
                        <div class="info-value">Ja <?= htmlspecialchars($rm['num'] ?? '') ?></div>
                    </div>
                <?php elseif ($discharged && isset($patient['room_num'])): ?>
                    <div class="info-item">
                        <div class="label">Ajilab’al re Ja</div>
                        <div class="info-value">Ja <?= htmlspecialchars($patient['room_num']) ?></div>
                    </div>
                <?php endif; ?>
                <div class="info-item">
                    <div class="label">Wachinem</div>
                    <div class="info-value"><?= ['admitted' => 'Xok', 'discharged' => 'Xel'][$patient['status'] ?? ''] ?? htmlspecialchars(ucfirst($patient['status'] ?? 'man etaman ta')) ?></div>
                </div>
                <div class="info-item">
                    <div class="label">Q’ij re Okib’al</div>
                    <div class="info-value"><?= isset($patient['admit_date']) ? formatDate($patient['admit_date']) : '' ?></div>
                </div>
                <?php if (($patient['status'] ?? '') == 'discharged'): ?>
                    <div class="info-item">
                        <div class="label">Q’ij re Elik</div>
                        <div class="info-value"><?= isset($patient['discharge_date']) ? formatDate($patient['discharge_date']) : '' ?></div>
                    </div>
                <?php endif; ?>
            </div>

            <?php if (isset($patient['complaint']) && $patient['complaint']): ?>
                <div class="info-item">
                    <div class="label">Nima Oq’ej</div>
                    <div class="info-value"><?= nl2br(htmlspecialchars($patient['complaint'])) ?></div>
                </div>
            <?php endif; ?>

            <?php if (isset($patient['history']) && $patient['history']): ?>
                <div class="info-item">
                    <div class="label">Ojer Kunanik</div>
                    <div class="info-value"><?= nl2br(htmlspecialchars($patient['history'])) ?></div>
                </div>
            <?php endif; ?>

            <?php if (isset($patient['allergies']) && $patient['allergies']): ?>
                <div class="info-item">
                    <div class="label">Alergia</div>
                    <div class="info-value"><?= nl2br(htmlspecialchars($patient['allergies'])) ?></div>
                </div>
            <?php endif; ?>

            <?php if (isset($patient['vital_signs']) && $patient['vital_signs']): ?>
                <div class="info-item">
                    <div class="label">Retal re K’aslemal</div>
                    <div class="info-value"><?= nl2br(htmlspecialchars($patient['vital_signs'])) ?></div>
                </div>
            <?php endif; ?>

            <?php if (isset($patient['current_meds']) && $patient['current_meds']): ?>
                <div class="info-item">
                    <div class="label">Kunab’al Kamik</div>
                    <div class="info-value"><?= nl2br(htmlspecialchars($patient['current_meds'])) ?></div>
                </div>
            <?php endif; ?>

            <?php if (isset($patient['prescribed_meds']) && $patient['prescribed_meds']): ?>
                <div class="info-item">
                    <div class="label">Kunab’al Tz’ib’am</div>
                    <div class="info-value"><?= nl2br(htmlspecialchars($patient['prescribed_meds'])) ?></div>
                </div>
            <?php endif; ?>

            <?php if (isset($patient['doctor_notes']) && $patient['doctor_notes']): ?>
                <div class="info-item">
                    <div class="label">Tz’ib’ Ajkun</div>
                    <div class="info-value"><?= nl2br(htmlspecialchars($patient['doctor_notes'])) ?></div>
                </div>
            <?php endif; ?>

            <?php if (isset($patient['nurse_notes']) && $patient['nurse_notes']): ?>
                <div class="info-item">
                    <div class="label">Tz’ib’ Ajchajinel</div>
                    <div class="info-value"><?= nl2br(htmlspecialchars($patient['nurse_notes'])) ?></div>
                </div>
            <?php endif; ?>

            <?php if (($patient['status'] ?? '') == 'discharged' && isset($patient['discharge'])): ?>
                <div class="info-item">
                    <div class="label">Ch’utitzijob’al Elib’al</div>
                    <div class="info-value"><?= nl2br(htmlspecialchars($patient['discharge']['summary'] ?? '')) ?></div>
                </div>
                <div class="info-item">
                    <div class="label">Wachinem are xel</div>
                    <div class="info-value"><?= htmlspecialchars($patient['discharge']['cond'] ?? '') ?></div>
                </div>
                <?php if ($patient['discharge']['follow'] ?? ''): ?>
                    <div class="info-item">
                        <div class="label">Pixab’ re Terenik</div>
                        <div class="info-value"><?= nl2br(htmlspecialchars($patient['discharge']['follow'])) ?></div>
                    </div>
                <?php endif; ?>
                <?php if (!renderPrescriptionBlock($patient) && ($patient['discharge']['meds'] ?? '')): ?>
                    <div class="info-item">
                        <div class="label">Kunab’al re Elib’al</div>
                        <div class="info-value"><?= nl2br(htmlspecialchars($patient['discharge']['meds'])) ?></div>
                    </div>
                <?php endif; ?>
                <?php if ($patient['discharge']['doctor_final_notes'] ?? ''): ?>
                    <div class="info-item">
                        <div class="label">Ruk’isb’al Tz’ib’ Ajkun</div>
                        <div class="info-value"><?= nl2br(htmlspecialchars($patient['discharge']['doctor_final_notes'])) ?></div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            <?php renderPatientTimeline($patient); ?>

            <div style="margin-top:30px;display:flex;gap:10px;flex-wrap:wrap;">
                <?php if ($discharged): ?>
                    <a href="?action=discharged<?= $ad ? '&date=' . $ad : '' ?>" class="btn">← Chatzalij</a>
                    <a href="?action=discharge_photos&date=<?= $ad ?>" class="btn btn-primary">Chawila Wachib’al</a>
                    <?php if ($pdfPath && file_exists($pdfPath)): ?>
                        <a href="<?= $pdfPath ?>" target="_blank" class="btn btn-primary">Chaqasaj PDF</a>
                    <?php endif; ?>
                <?php else: ?>
                    <a href="?action=patients" class="btn">← Chatzalij</a>
                    <?php if (can('edit') && ($patient['status'] ?? '') == 'admitted'): ?>
                        <a href="?action=edit&id=<?= $id ?>" class="btn btn-primary">Chutzirisaj</a>
                        <a href="?action=add_photo&id=<?= $id ?>" class="btn btn-primary">Chatz’aqatisaj Wachib’al</a>
                    <?php endif; ?>
                    <?php if (can('move') && ($patient['status'] ?? '') == 'admitted'): ?>
                        <a href="?action=change&id=<?= htmlspecialchars($id) ?>&return=view" class="btn btn-primary">Chajalwachij Ja</a>
                    <?php endif; ?>
                    <?php if (can('discharge') && ($patient['status'] ?? '') == 'admitted'): ?>
                        <a href="?action=discharge&id=<?= $id ?>" class="btn btn-danger">Chesaj</a>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if (($patient['status'] ?? '') == 'discharged'): ?>
                    <?php if (canReadmit()): ?>
                        <a href="?action=readmit&id=<?= urlencode($id) ?><?= $discharged ? '&date=' . urlencode($ad) : '' ?>" class="btn"><i class="fas fa-undo"></i> Chatzalij pa yawab’</a>
                    <?php endif; ?>
                    <?php if (getPrescriptionItems($patient)): ?>
                        <a href="?action=prescription&id=<?= $id ?><?= $discharged ? '&discharged=1&date=' . $ad : '' ?>" target="_blank" class="btn btn-primary"><i class="fas fa-prescription"></i> Chatz’ib’aj Wujkunab’al</a>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if (!empty($photos) && !$discharged): ?>
                    <a href="?action=room_photos&room=<?= $photos[0]['room_num'] ?? '' ?>" class="btn btn-primary">Chawila Wachib’al Ja</a>
                <?php endif; ?>
                <?php if (!empty($photos)): ?>
                    <a href="?action=photo_grid&filter=<?= $discharged ? 'discharged' : 'all' ?>" class="btn btn-primary">Chawila Ronoj Wachib’al</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php
    showFooter();
}

function showRooms() {
    $r = readJSONFile($GLOBALS['rF']);
    if (!is_array($r)) $r = [];
    
    $p = readJSONFile($GLOBALS['pF']);
    if (!is_array($p)) $p = [];
    
    $g = [];
    foreach ($r as $rm) {
        if (!is_array($rm)) continue;
        $d = $rm['dept'] ?? '';
        if (!isset($g[$d])) $g[$d] = [];
        $g[$d][] = $rm;
    }

    $roomPhotoCounts = [];
    $roomPatientPhotos = [];
    
    foreach ($r as $rm) {
        if (!is_array($rm)) continue;
        $roomNum = $rm['num'] ?? '';
        
        $photos = getPatientPhotos(null, $roomNum);
        $roomPhotoCounts[$roomNum] = is_array($photos) ? count($photos) : 0;
        
        $roomPatients = array_filter($p, function($pt) use ($rm) {
            return is_array($pt) && 
                   isset($pt['room_id']) && 
                   $pt['room_id'] == $rm['id'] && 
                   $pt['status'] == 'admitted';
        });
        
        $patientPhotoData = [];
        foreach ($roomPatients as $patient) {
            $patientId = $patient['id'] ?? '';
            if ($patientId) {
                $patientPhotos = getPatientPhotos($patientId);
                if (!empty($patientPhotos)) {
                    $patientPhotoData[$patientId] = [
                        'patient' => $patient,
                        'photos' => $patientPhotos,
                        'count' => count($patientPhotos)
                    ];
                }
            }
        }
        
        if (!empty($patientPhotoData)) {
            $roomPatientPhotos[$roomNum] = $patientPhotoData;
        }
    }
    
    $totalPhotos = array_sum($roomPhotoCounts);

    showHeader();
?>
    <div class="container">
        <div class="card" style="margin-bottom:var(--spacing-xl);">
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:var(--spacing-md);">
                <div>
                    <h2>Taq ja</h2>
                    <p style="color:var(--text-muted);">Okinaq rachi’ wachib’al yawab’ kamik</p>
                </div>
                <div style="display:flex; gap:10px; flex-wrap:wrap;">
                    <a href="?action=room_photos" class="btn btn-primary">
                        Chawila Ronoj Wachib’al (<?= number_format($totalPhotos) ?>)
                    </a>
                    <a href="?action=photo_grid" class="btn btn-outline">
                        Ronoj wachib’al
                    </a>
                </div>
            </div>
        </div>

        <div class="grid grid-4" style="margin-bottom:var(--spacing-xl);">
            <?php
            $totalRooms = count($r);
            $totalBeds = array_sum(array_column($r, 'beds'));
            $occupiedBeds = array_sum(array_column($r, 'occ'));
            $roomsWithPhotos = count(array_filter($roomPhotoCounts));
            ?>
            <div class="card">
                <div class="card-label">Ronoj Ja</div>
                <div class="card-stats"><?= $totalRooms ?></div>
            </div>
            <div class="card">
                <div class="card-label">Ronoj Warab’al</div>
                <div class="card-stats"><?= $totalBeds ?></div>
            </div>
            <div class="card">
                <div class="card-label">Warab’al k’o Winaq</div>
                <div class="card-stats"><?= $occupiedBeds ?></div>
            </div>
            <div class="card">
                <div class="card-label">Ja rachi’ Wachib’al</div>
                <div class="card-stats"><?= $roomsWithPhotos ?></div>
            </div>
        </div>

        <?php if (empty($g)): ?>
            <div class="empty-state">
                <p>Maja k’o ja xriqitaj</p>
                <?php if (can('manage')): ?>
                    <a href="?action=manage" class="btn btn-primary">Chatz’aqatisaj Ja</a>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <?php foreach ($g as $d => $rooms): ?>
                <div class="dept-section">
                    <div class="dept-header">
                        <h2><?= htmlspecialchars(getDeptName($d)) ?></h2>
                        <div class="dept-stats">
                            <?php 
                            $totalBeds = array_sum(array_column($rooms, 'beds'));
                            $occupiedBeds = array_sum(array_column($rooms, 'occ'));
                            $totalRooms = count($rooms);
                            $availableBeds = $totalBeds - $occupiedBeds;
                            $deptPhotos = 0;
                            foreach ($rooms as $rm) {
                                $deptPhotos += $roomPhotoCounts[$rm['num'] ?? ''] ?? 0;
                            }
                            ?>
                            <?= $totalRooms ?> ja • <?= $totalBeds ?> warab’al • <?= $occupiedBeds ?> k’o winaq • 
                            <strong class="<?= $availableBeds > 0 ? 'text-success' : 'text-danger' ?>">
                                <?= $availableBeds ?> tolon
                            </strong>
                            <?php if ($deptPhotos > 0): ?>
                                •  <?= $deptPhotos ?> wachib’al
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="rooms-grid">
                        <?php foreach ($rooms as $rm):
                            if (!is_array($rm)) continue;
                            
                            $occ = (int)($rm['occ'] ?? 0);
                            $tot = (int)($rm['beds'] ?? 0);
                            $perc = $tot > 0 ? round(($occ / $tot) * 100) : 0;
                            $available = $tot - $occ;
                            $isFull = $available <= 0;
                            $photoCount = $roomPhotoCounts[$rm['num'] ?? ''] ?? 0;
                            $roomNum = htmlspecialchars($rm['num'] ?? '');
                            
                            $roomPatients = array_filter($p, function($pt) use ($rm) {
                                return is_array($pt) && 
                                       isset($pt['room_id']) && 
                                       $pt['room_id'] == $rm['id'] && 
                                       $pt['status'] == 'admitted';
                            });
                            
                            $roomPhotoData = $roomPatientPhotos[$roomNum] ?? [];
                        ?>
                            <div class="room-card" style="<?= $isFull ? 'opacity:0.9;' : '' ?>">
                                <div class="room-header">
                                    <h3>Ja <?= $roomNum ?></h3>
                                    <?php if ($photoCount > 0): ?>
                                        <span class="badge" style="background:var(--primary); color:var(--text-inverse);">
                                             <?= $photoCount ?> wachib’al
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div style="margin-bottom:var(--spacing-sm);">
                                    <?php if ($isFull): ?>
                                        <span class="status-badge status-discharged" style="background:var(--bg-tertiary); color:var(--text-muted); border-color:var(--border-color);">
                                            🔴 Nojinaq
                                        </span>
                                    <?php else: ?>
                                        <span class="status-badge status-admitted">
                                            🟢 <?= $available ?> warab’al tolon
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="room-stats">
                                    <div class="stat-item">
                                        <div class="stat-label">Ronoj Warab’al</div>
                                        <div class="stat-value"><?= $tot ?></div>
                                    </div>
                                    <div class="stat-item">
                                        <div class="stat-label">K’o winaq</div>
                                        <div class="stat-value"><?= $occ ?></div>
                                    </div>
                                    <div class="stat-item">
                                        <div class="stat-label">Tolon</div>
                                        <div class="stat-value <?= $isFull ? 'text-danger' : 'text-success' ?>">
                                            <?= $available ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="occupancy-container">
                                    <div class="occupancy-header">
                                        <span>Okinaq</span>
                                        <span><?= $perc ?>%</span>
                                    </div>
                                    <div class="progress-bar">
                                        <div class="progress-fill" style="width: <?= $perc ?>%; <?= $isFull ? 'background:var(--danger);' : '' ?>"></div>
                                    </div>
                                </div>

                                <?php if ($occ > 0 && !empty($roomPatients)): ?>
                                    <div style="margin:var(--spacing-md) 0;">
                                        <div style="font-size:0.75rem; font-weight:600; margin-bottom:var(--spacing-sm); color:var(--text-muted); display:flex; justify-content:space-between;">
                                            <span>Yawab’ Kamik:</span>
                                            <?php if ($photoCount > 0): ?>
                                                <span class="photo-count-badge"> <?= $photoCount ?> ronojel</span>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <div style="display:flex; flex-direction:column; gap:var(--spacing-sm);">
                                            <?php foreach ($roomPatients as $patient): 
                                                $patientId = $patient['id'] ?? '';
                                                $patientPhotos = $roomPhotoData[$patientId]['photos'] ?? [];
                                                $hasPhotos = !empty($patientPhotos);
                                                $genderClass = isset($patient['gender']) ? str_replace('_', '-', $patient['gender']) : 'prefer-not';
                                            ?>
                                                <div style="display:flex; align-items:center; gap:var(--spacing-sm); padding:var(--spacing-xs); background:var(--bg-secondary); border-radius:var(--border-radius);">
                                                    <div style="flex-shrink:0;">
                                                        <?php if ($hasPhotos): 
                                                            $firstPhoto = $patientPhotos[0];
                                                        ?>
                                                            <img src="<?= htmlspecialchars($firstPhoto['url']) ?>" 
                                                                 alt="Yawab’" 
                                                                 class="patient-photo-thumb" 
                                                                 style="width:40px; height:40px; border-radius:var(--border-radius); cursor:pointer;"
                                                                 onclick="openPhotoModal('<?= $firstPhoto['url'] ?>', '<?= htmlspecialchars($patient['name'] ?? '') ?>')"
                                                                 onerror="this.onerror=null; this.src='data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'40\' height=\'40\' viewBox=\'0 0 40 40\'%3E%3Crect width=\'40\' height=\'40\' fill=\'%23f0f0f0\'/%3E%3Ctext x=\'5\' y=\'25\' font-family=\'Courier New\' font-size=\'10\' fill=\'%23999\'%3EMaja%20k%E2%80%99o%20wachib%E2%80%99al%3C/text%3E%3C/svg%3E';">
                                                        <?php else: ?>
                                                            <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='40' height='40' viewBox='0 0 40 40'%3E%3Crect width='40' height='40' fill='%23f0f0f0'/%3E%3Ctext x='5' y='25' font-family='Courier New' font-size='10' fill='%23999'%3EMaja%20k%E2%80%99o%20wachib%E2%80%99al%3C/text%3E%3C/svg%3E" 
                                                                 alt="Maja k’o wachib’al" 
                                                                 class="patient-photo-thumb"
                                                                 style="width:40px; height:40px; border-radius:var(--border-radius); opacity:0.5;">
                                                        <?php endif; ?>
                                                    </div>
                                                    
                                                    <div style="flex:1; min-width:0;">
                                                        <div style="display:flex; justify-content:space-between; align-items:center;">
                                                            <a href="?action=view&id=<?= $patientId ?>" style="color:var(--text-primary); text-decoration:none; font-weight:500; font-size:0.9rem;">
                                                                <?= htmlspecialchars($patient['name'] ?? 'Man etaman ta') ?>
                                                            </a>
                                                            <?php if ($hasPhotos): ?>
                                                                <span class="photo-count-badge" style="font-size:0.7rem;" title="<?= count($patientPhotos) ?> wachib’al">
                                                                     <?= count($patientPhotos) ?>
                                                                </span>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div style="display:flex; gap:var(--spacing-sm); font-size:0.7rem; color:var(--text-muted); flex-wrap:wrap;">
                                                            <span>ID: <?= $patientId ?></span>
                                                            <span class="gender-badge <?= $genderClass ?>" style="font-size:0.6rem; padding:1px 4px;">
                                                                <?= getGenderName($patient['gender'] ?? 'prefer_not_to_say') ?>
                                                            </span>
                                                            <?php if (!empty($patient['complaint'])): ?>
                                                                <span title="<?= htmlspecialchars($patient['complaint']) ?>">
                                                                     <?= substr(htmlspecialchars($patient['complaint']), 0, 20) ?><?= strlen($patient['complaint']) > 20 ? '...' : '' ?>
                                                                </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <?php if (count($patientPhotos) > 1): ?>
                                                    <div style="display:flex; gap:2px; margin-left:48px; margin-bottom:var(--spacing-xs); flex-wrap:wrap;">
                                                        <?php foreach (array_slice($patientPhotos, 1, 3) as $photo): ?>
                                                            <img src="<?= htmlspecialchars($photo['url']) ?>" 
                                                                 alt="Wachib’al Yawab’" 
                                                                 style="width:25px; height:25px; border-radius:3px; cursor:pointer; border:1px solid var(--border-color);"
                                                                 onclick="openPhotoModal('<?= $photo['url'] ?>', '<?= htmlspecialchars($patient['name'] ?? '') ?>')"
                                                                 onerror="this.style.display='none';">
                                                        <?php endforeach; ?>
                                                        <?php if (count($patientPhotos) > 4): ?>
                                                            <span style="font-size:0.7rem; color:var(--text-muted); align-self:center;">
                                                                +<?= count($patientPhotos) - 4 ?> chik
                                                            </span>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <?php if ($photoCount > 0 && empty($roomPatients)): 
                                    $roomPhotos = getPatientPhotos(null, $roomNum);
                                ?>
                                    <div style="margin:var(--spacing-md) 0;">
                                        <div style="font-size:0.75rem; font-weight:600; margin-bottom:var(--spacing-xs); color:var(--text-muted);">
                                            Wachib’al Ja:
                                        </div>
                                        <div style="display:flex; gap:5px; flex-wrap:wrap;">
                                            <?php foreach (array_slice($roomPhotos, 0, 4) as $photo): ?>
                                                <img src="<?= htmlspecialchars($photo['url']) ?>" 
                                                     alt="Wachib’al Ja" 
                                                     style="width:40px; height:40px; border-radius:var(--border-radius); cursor:pointer; border:1px solid var(--border-color);"
                                                     onclick="openPhotoModal('<?= $photo['url'] ?>', 'Ja <?= $roomNum ?> Wachib’al')"
                                                     onerror="this.style.display='none';">
                                            <?php endforeach; ?>
                                            <?php if ($photoCount > 4): ?>
                                                <span style="font-size:0.7rem; color:var(--text-muted); align-self:center;">
                                                    +<?= $photoCount - 4 ?> chik
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <div class="card-footer" style="display:flex; gap:var(--spacing-xs); margin-top:auto;">
                                    <?php if (!$isFull && can('admit')): ?>
                                        <a href="?action=admit&room_id=<?= $rm['id'] ?>" class="btn btn-sm btn-success" style="flex:1;">
                                            Chok’ama
                                        </a>
                                    <?php endif; ?>
                                    <a href="?action=room_photos&room=<?= urlencode($roomNum) ?>" class="btn btn-sm btn-outline" style="flex:<?= $isFull && !can('admit') ? '1' : '0.5' ?>;">
                                         Chawila <?= $photoCount ?>
                                    </a>
                                    <?php if ($occ > 0 && can('edit')): ?>
                                        <a href="?action=add_photo&room=<?= urlencode($roomNum) ?>" class="btn btn-sm btn-primary" title="Chatz’aqatisaj Wachib’al">
                                            ➕
                                        </a>
                                    <?php endif; ?>
                                </div>

                                <?php if ($isFull): ?>
                                    <div style="margin-top:var(--spacing-sm); padding:var(--spacing-xs); background:var(--bg-tertiary); border-radius:var(--border-radius); text-align:center; font-size:0.7rem; color:var(--text-muted);">
                                        ⚠️ Ri ja nojinaq - maja k’o warab’al tolon
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <div id="photoModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.9); z-index:2000; justify-content:center; align-items:center; cursor:pointer;" onclick="closePhotoModal()">
            <div style="position:relative; max-width:90%; max-height:90%;">
                <img id="modalImage" src="" alt="Wachib’al nimarisam" style="max-width:100%; max-height:90vh; border:3px solid white; border-radius:var(--border-radius);">
                <div id="modalCaption" style="color:white; text-align:center; padding:var(--spacing-sm); font-size:0.9rem;"></div>
                <button onclick="closePhotoModal()" style="position:absolute; top:10px; right:10px; background:white; border:none; border-radius:50%; width:30px; height:30px; cursor:pointer;">✕</button>
            </div>
        </div>

        <script>
        function openPhotoModal(src, caption) {
            document.getElementById('modalImage').src = src;
            document.getElementById('modalCaption').innerText = caption || 'Wachib’al Yawab’';
            document.getElementById('photoModal').style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }

        function closePhotoModal() {
            document.getElementById('photoModal').style.display = 'none';
            document.body.style.overflow = 'auto';
        }

        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closePhotoModal();
            }
        });
        </script>

        <div style="margin-top: var(--spacing-xl); padding: var(--spacing-md); background: var(--bg-primary); border: 1px solid var(--border-color); border-radius: var(--border-radius);">
            <div style="display: flex; justify-content: space-between; align-items: center; color: var(--text-muted); font-size: 0.875rem; flex-wrap:wrap; gap:var(--spacing-sm);">
                <span>
                    <span class="status-badge status-admitted" style="margin-right:10px;">🟢 Tolon</span>
                    <span class="status-badge status-discharged" style="margin-right:10px;">🔴 Nojinaq</span>
                    <span class="badge" style="background:var(--primary); color:var(--text-inverse);">K’o Uwachib’al</span>
                </span>
                <span>Ronoj Wachib’al: <?= $totalPhotos ?> | Ruk’isb’al K’ak’arisanik: <?= now() ?></span>
            </div>
        </div>
    </div>
<?php
    showFooter();
}

function showAdmitForm() {
    global $depts, $genders;
    $r = readJSONFile($GLOBALS['rF']);
    if (!is_array($r)) $r = [];
    
    $rooms_by_dept = [];
    foreach ($r as $rm) {
        if (!is_array($rm)) continue;
        if (($rm['occ'] ?? 0) < ($rm['beds'] ?? 0)) {
            $dept_key = $rm['dept'] ?? 'general';
            if (!isset($rooms_by_dept[$dept_key])) {
                $rooms_by_dept[$dept_key] = [];
            }
            $rooms_by_dept[$dept_key][] = $rm;
        }
    }
    
    showHeader();
?>
    <div class="container">
        <div class="form-container" style="max-width:900px;">
            <h2>Chok’ama K’ak’ Yawab’</h2>

            <form method="POST" action="?action=admit" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

                <div class="form-grid">
                    <div class="form-group">
                        <label class="required">Ub’i’ Yawab’</label>
                        <input type="text" name="name" required placeholder="jas Tecum Tzoc">
                        <span class="example-hint">Sarah Johnson, Michael Chen</span>
                    </div>
                    
                    <div class="form-group">
                        <label class="required">Junab’</label>
                        <input type="number" name="age" min="0" max="120" required placeholder="jas 45">
                        <span class="example-hint">35</span>
                    </div>
                    
                    <div class="form-group <?= isGenderRequired() ? 'required' : '' ?>">
                        <label <?= isGenderRequired() ? 'class="required"' : '' ?>>Achi/Ixoq</label>
                        <select name="gender" <?= isGenderRequired() ? 'required' : '' ?>>
                            <option value="">Chacha’ Achi/Ixoq</option>
                            <?php foreach (getGenderOptions() as $code => $name): ?>
                                <option value="<?= $code ?>" <?= $code == getDefaultGender() ? 'selected' : '' ?>>
                                    <?= $name ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <span class="example-hint">Chacha’ we achi o ixoq ri yawab’</span>
                    </div>
                    <br>
                    <div class="form-group">
                        <label class="required">Ja</label>
                        <select name="dept" id="departmentSelect" required onchange="updateRooms()">
                            <option value="">Chacha’ K’olb’al</option>
                            <?php foreach ($depts as $k => $v): ?>
                                <option value="<?= $k ?>"><?= $v ?></option>
                            <?php endforeach; ?>
                        </select>
                        <span class="example-hint">Chacha’ k’olb’al che rilik ja tolon</span>
                    </div>
                    
                    <div class="form-group">
                        <label class="required">Ajilab’al re Ja</label>
                        <select name="room_id" id="roomSelect" required>
                            <option value="">Nab’e chacha’ jun k’olb’al</option>
                        </select>
                        <span class="example-hint">Ja tolon pa k’olb’al cha’om</span>
                    </div>
                </div>

                <div class="card" style="margin:var(--spacing-lg) 0; background:var(--bg-secondary);">
                    <h3 style="margin-bottom:var(--spacing-md);">Wachib’al Yawab’ (We kawaj)</h3>
                    <div class="photo-upload-area" id="photoDropArea">
                        <p>Chakelesaj chaya ri wachib’al waral o chapitz’a’ che rucha’ik</p>
                        <p class="photo-info" style="font-size:0.8rem; color:var(--text-muted);">Nim nimal: <?= getMaxUploadSize() ?> | PNG o JPG (kajalwachix pa PNG rumal)</p>
                        <button type="button" class="btn" id="cameraButton" style="margin-top:var(--spacing-sm);">📱 Chakuj Cámara</button>
                    </div>

                    <input type="file" name="patient_photo" id="photoInput" accept="image/png,image/jpeg,image/webp" style="display:none;">

                    <div id="photoPreviewContainer" style="text-align:center; margin-top:var(--spacing-lg);">
                        <img id="photoPreview" class="photo-preview" src="#" alt="Nab’e ilik" style="max-width:200px; max-height:200px; border:2px solid var(--border-color); border-radius:var(--border-radius); display:none; margin:0 auto;">
                        <button type="button" id="removePhoto" class="btn btn-danger" style="display:none; margin-top:var(--spacing-md);">Chesaj</button>
                    </div>
                </div>

                <div class="card" style="margin:var(--spacing-lg) 0;">
                    <h3 style="margin-bottom:var(--spacing-md);">Retal Kunanik</h3>
                    
                    <div class="form-group full-width">
                        <label class="required">Nima Oq’ej</label>
                        <textarea name="complaint" required rows="4" placeholder="jas Q’axomal pa uk’u’x rachi’ man kuxlan ta"></textarea>
                        <span class="example-hint">"Nim q’axomal pa pam pa uwiqiq’ikim", "K’ax uxlab’ rachi’ ch’uch’ik"</span>
                    </div>

                    <div class="form-group full-width">
                        <label>Retal re K’aslemal</label>
                        <textarea name="vital_signs" rows="2" placeholder="BP: 120/80, HR: 72, Temp: 98.6°F, RR: 16, O2: 98%"></textarea>
                        <span class="example-hint">BP: 120/80, HR: 72 bpm, Temp: 98.6°F, RR: 16, O2 Sat: 98%</span>
                    </div>

                    <div class="form-grid">
                        <div class="form-group">
                            <label>Ojer Kunanik</label>
                            <textarea name="history" rows="3" placeholder="jas Naj uchuq’ab’ kik’, kab’ yab’il ruk’ojlem 2"></textarea>
                            <span class="example-hint">Naj uchuq’ab’ kik’ (xilitaj 2018), kab’ yab’il ruk’ojlem 2 , asma</span>
                        </div>

                        <div class="form-group">
                            <label>Alergia</label>
                            <textarea name="allergies" rows="3" placeholder="jas Penicilina, Sulfa"></textarea>
                            <span class="example-hint">Penicilina (kaq tz’umal), kunab’al Sulfa, Látex</span>
                        </div>
                    </div>

                    <div class="form-grid">
                        <div class="form-group">
                            <label>Kunab’al Kamik</label>
                            <textarea name="current_meds" rows="3" placeholder="jas Lisinopril 10mg chi jujun q’ij"></textarea>
                            <span class="example-hint">Lisinopril 10mg chi jujun q’ij, Metformin 500mg BID</span>
                        </div>

                        <div class="form-group">
                            <label>Kunab’al Tz’ib’am</label>
                            <textarea name="prescribed_meds" rows="3" placeholder="jas Amoxicillin 500mg TID"></textarea>
                            <span class="example-hint">Amoxicillin 500mg TID x7 q’ij, Ibuprofen 400mg PRN q’axomal</span>
                        </div>
                    </div>
                </div>

                <div class="form-grid">
                    <div class="form-group">
                        <label>Tz’ib’ Ajkun</label>
                        <textarea name="doctor_notes" rows="5" placeholder="jas Ri yawab’ xopan rachi’..."></textarea>
                        <span class="example-hint">"Ri yawab’ xopan rachi’ q’axomal pa uk’u’x xtikitaj aninaq. Ri EKG kuk’ut sinus tachycardia."</span>
                    </div>

                    <div class="form-group">
                        <label>Tz’ib’ Ajchajinel</label>
                        <textarea name="nurse_notes" rows="5" placeholder="jas Ri yawab’ retaman, xtikitaj IV..."></textarea>
                        <span class="example-hint">"Ri yawab’ retaman x3. Xtikitaj IV pa umox q’ab’. Ri retal k’aslemal utz."</span>
                    </div>
                </div>

                <div style="display:flex;gap:15px;margin-top:30px;justify-content:center;">
                    <button type="submit" class="btn btn-primary btn-lg">Chok’ama Yawab’</button>
                    <a href="?action=patients" class="btn btn-lg" style="background:var(--text-muted); color:var(--text-inverse);">Chatanab’a</a>
                </div>
            </form>
        </div>
    </div>

    <script>
        const roomsByDept = <?= json_encode($rooms_by_dept) ?>;
        const deptNames = <?= json_encode($GLOBALS['depts']) ?>;

        function updateRooms() {
            const deptSelect = document.getElementById('departmentSelect');
            const roomSelect = document.getElementById('roomSelect');
            const selectedDept = deptSelect.value;

            roomSelect.innerHTML = '';

            if (!selectedDept) {
                const option = document.createElement('option');
                option.value = '';
                option.textContent = 'Nab’e chacha’ jun k’olb’al';
                roomSelect.appendChild(option);
                return;
            }

            const deptRooms = roomsByDept[selectedDept] || [];

            if (deptRooms.length === 0) {
                const option = document.createElement('option');
                option.value = '';
                option.textContent = 'Maja k’o ja tolon pa ' + (deptNames[selectedDept] || selectedDept);
                roomSelect.appendChild(option);
                
                const roomInfo = document.createElement('div');
                roomInfo.className = 'alert alert-error';
                roomInfo.style.margin = 'var(--spacing-sm) 0';
                roomInfo.textContent = '⚠️ Maja k’o warab’al tolon pa we k’olb’al ri’';
                
                const existingInfo = document.querySelector('.room-info-message');
                if (existingInfo) existingInfo.remove();
                
                roomInfo.classList.add('room-info-message');
                roomSelect.parentNode.appendChild(roomInfo);
                return;
            }

            const existingInfo = document.querySelector('.room-info-message');
            if (existingInfo) existingInfo.remove();

            const defaultOption = document.createElement('option');
            defaultOption.value = '';
            defaultOption.textContent = 'Chacha’ Ja';
            roomSelect.appendChild(defaultOption);

            deptRooms.forEach(room => {
                const option = document.createElement('option');
                option.value = room.id;
                
                const availableBeds = room.beds - room.occ;
                const bedText = availableBeds === 1 ? 'warab’al' : 'warab’al';
                
                option.textContent = `Ja ${room.num} (${availableBeds} ${bedText} tolon)`;
                
                roomSelect.appendChild(option);
            });

            const totalBeds = deptRooms.reduce((sum, room) => sum + (room.beds - room.occ), 0);
            const roomCount = deptRooms.length;
            
            const info = document.createElement('div');
            info.className = 'card';
            info.style.margin = 'var(--spacing-sm) 0';
            info.style.padding = 'var(--spacing-sm)';
            info.style.background = 'var(--bg-secondary)';
            info.innerHTML = `<strong>📊 Ch’utitzijob’al K’olb’al:</strong> ${roomCount} ja tolon rachi’ ${totalBeds} ronoj warab’al`;
            
            info.classList.add('room-info-message');
            roomSelect.parentNode.appendChild(info);
        }

(function () {
    var LIMIT = <?= (int)getEffectiveUploadLimit() ?>;
    var input = document.getElementById('photoInput');
    var area = document.getElementById('photoDropArea');
    var preview = document.getElementById('photoPreview');
    var removeBtn = document.getElementById('removePhoto');
    var camBtn = document.getElementById('cameraButton');

    // No fixed "capture": otherwise phones only open the camera and never the gallery/files.
    input.removeAttribute('capture');
    input.setAttribute('accept', 'image/png,image/jpeg,image/webp');

    // Always deliver a PNG that fits the server limit (phone photos are converted + scaled down)
    function toPng(file) {
        return new Promise(function (resolve, reject) {
            var url = URL.createObjectURL(file);
            var img = new Image();
            img.onload = function () {
                URL.revokeObjectURL(url);
                var w = img.naturalWidth, h = img.naturalHeight;
                if (file.type === 'image/png' && file.size <= LIMIT && Math.max(w, h) <= 2000) { resolve(file); return; }
                var sizes = [1600, 1280, 1024, 800, 640, 480], i = 0;
                (function attempt() {
                    var max = sizes[i], sc = Math.min(1, max / Math.max(w, h));
                    var c = document.createElement('canvas');
                    c.width = Math.max(1, Math.round(w * sc)); c.height = Math.max(1, Math.round(h * sc));
                    c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
                    c.toBlob(function (blob) {
                        if (!blob) { reject(new Error('Man xjalwachix ta ri wachib’al')); return; }
                        if (blob.size <= LIMIT) {
                            var name = (file.name || 'photo').replace(/\.[^.]+$/, '') + '.png';
                            resolve(new File([blob], name, { type: 'image/png' }));
                        } else if (i >= sizes.length - 1) {
                            reject(new Error('Ri wachib’al nim na stape’ xch’utinarisax'));
                        } else { i++; attempt(); }
                    }, 'image/png');
                })();
            };
            img.onerror = function () { URL.revokeObjectURL(url); reject(new Error('We wuj ri’ man wachib’al ta kasik’ix (ri browser man kuk’ul ta HEIC - chacha’ JPG o PNG)')); };
            img.src = url;
        });
    }

    function setFile(file) {
        if (!file) return;
        if (!/^image\//.test(file.type) && !/\.(png|jpe?g|webp)$/i.test(file.name)) { alert('Chacha’ jun wachib’al PNG o JPG.'); return; }
        toPng(file).then(function (png) {
            var dt = new DataTransfer(); dt.items.add(png); input.files = dt.files;
            var reader = new FileReader();
            reader.onload = function (e) {
                preview.src = e.target.result; preview.style.display = 'block';
                area.style.display = 'none'; removeBtn.style.display = 'inline-block';
            };
            reader.readAsDataURL(png);
        }).catch(function (err) { alert(err.message); input.value = ''; });
    }

    function reset() {
        input.value = ''; preview.src = '#'; preview.style.display = 'none';
        area.style.display = 'block'; removeBtn.style.display = 'none';
    }

    area.addEventListener('click', function () { input.removeAttribute('capture'); input.click(); });
    camBtn.addEventListener('click', function (e) { e.stopPropagation(); input.setAttribute('capture', 'environment'); input.click(); });
    input.addEventListener('change', function () { setFile(input.files[0]); });
    removeBtn.addEventListener('click', reset);
    area.addEventListener('dragover', function (e) { e.preventDefault(); area.style.background = 'var(--bg-tertiary)'; });
    area.addEventListener('dragleave', function (e) { e.preventDefault(); area.style.background = 'var(--bg-secondary)'; });
    area.addEventListener('drop', function (e) {
        e.preventDefault(); area.style.background = 'var(--bg-secondary)';
        setFile(e.dataTransfer.files[0]);
    });
})();

        document.addEventListener('DOMContentLoaded', function() {
            updateRooms();
        });
    </script>
<?php
    showFooter();
}

function admitPatient() {
    $n = trim($_POST['name'] ?? '');
    $a = intval($_POST['age'] ?? 0);
    $g = $_POST['gender'] ?? DEFAULT_GENDER;
    $d = $_POST['dept'] ?? '';
    $rid = intval($_POST['room_id'] ?? 0);
    $comp = trim($_POST['complaint'] ?? '');

    if (!$n || !$a || !$d || !$rid || !$comp) {
        $_SESSION['error'] = 'Maja k’o ucholaj rajawaxik';
        header('Location: ?action=admit');
        exit;
    }

    if (isGenderRequired() && empty($g)) {
        $_SESSION['error'] = 'Rajawaxik achi/ixoq';
        header('Location: ?action=admit');
        exit;
    }

    $p = readJSONFile($GLOBALS['pF']);
    $r = readJSONFile($GLOBALS['rF']);

    $ri = array_search($rid, array_column($r, 'id'));
    if ($ri === false || $r[$ri]['occ'] >= $r[$ri]['beds']) {
        $_SESSION['error'] = 'Ri ja man tolon ta';
        header('Location: ?action=admit');
        exit;
    }

    $id = generatePatientId();

    $photoInfo = null;
    if (isset($_FILES['patient_photo']) && $_FILES['patient_photo']['error'] !== UPLOAD_ERR_NO_FILE) {
        $roomNum = $r[$ri]['num'];
        $photoInfo = handlePhotoUpload($id, $roomNum);
        if (!$photoInfo['success']) {
            $_SESSION['error'] = 'Wachib’al: jotesaxik man xel ta: ' . $photoInfo['message'];
            header('Location: ?action=admit');
            exit;
        }
        logMsg("Wachib’al xjotesax che yawab’ $id");
    }

    $pt = [
        'id' => $id,
        'name' => $n,
        'age' => $a,
        'gender' => $g,
        'department' => $d,
        'room_id' => $rid,
        'room_num' => $r[$ri]['num'],
        'admit_date' => now(),
        'status' => 'admitted',
        'complaint' => $comp,
        'history' => trim($_POST['history'] ?? ''),
        'allergies' => trim($_POST['allergies'] ?? ''),
        'vital_signs' => trim($_POST['vital_signs'] ?? ''),
        'current_meds' => trim($_POST['current_meds'] ?? ''),
        'prescribed_meds' => trim($_POST['prescribed_meds'] ?? ''),
        'doctor_notes' => trim($_POST['doctor_notes'] ?? ''),
        'nurse_notes' => trim($_POST['nurse_notes'] ?? ''),
        'has_photo' => $photoInfo ? true : false
    ];
    addTimelineEvent($pt, 'admit', 'Xok', 'Ja ' . $r[$ri]['num'] . ' (' . getDeptName($d) . ')');

    $p[] = $pt;
    $r[$ri]['occ']++;

    writeJSONFile($GLOBALS['pF'], $p);
    writeJSONFile($GLOBALS['rF'], $r);

    updateStats('admitted', $d);
    logMsg("Xok: $n ($id) pa Ja {$r[$ri]['num']} - Achi/Ixoq: " . getGenderName($g));

    $_SESSION['success'] = 'Yawab’ utz xok' . ($photoInfo ? ' rachi’ wachib’al' : '');
    header('Location: ?action=patients');
    exit;
}

// ==================== DISCHARGE PRESCRIPTION (ONTSLAGRECEPT) ====================
function rxClean($v, $max = 120) {
    $v = preg_replace('/\s+/', ' ', trim((string)$v));
    return function_exists('mb_substr') ? mb_substr($v, 0, $max) : substr($v, 0, $max);
}

// Reads the medication rows posted by the discharge form (rx_name[], rx_strength[], ...).
function buildPrescriptionItemsFromPost() {
    $names = $_POST['rx_name'] ?? [];
    if (!is_array($names)) return [];
    $get = function ($key, $i) {
        return (isset($_POST[$key]) && is_array($_POST[$key])) ? ($_POST[$key][$i] ?? '') : '';
    };
    $items = [];
    foreach ($names as $i => $name) {
        $name = rxClean($name);
        if ($name === '') continue;
        $items[] = [
            'name'         => $name,
            'strength'     => rxClean($get('rx_strength', $i), 60),
            'dose'         => rxClean($get('rx_dose', $i), 80),
            'frequency'    => rxClean($get('rx_freq', $i), 80),
            'duration'     => rxClean($get('rx_duration', $i), 60),
            'instructions' => rxClean($get('rx_instr', $i), 300),
        ];
        if (count($items) >= 20) break;
    }
    return $items;
}

// Plain-text version, kept in discharge['meds'] so the archive, PDF and summary keep working.
function prescriptionToText($items, $notes = '') {
    $lines = [];
    foreach ($items as $it) {
        $line = $it['name'];
        if ($it['strength'] !== '') $line .= ' ' . $it['strength'];
        $parts = array_filter([$it['dose'], $it['frequency'], $it['duration']], function ($x) { return $x !== ''; });
        if ($parts) $line .= ' - ' . implode(', ', $parts);
        if ($it['instructions'] !== '') $line .= ' (' . $it['instructions'] . ')';
        $lines[] = $line;
    }
    if (trim($notes) !== '') $lines[] = trim($notes);
    return implode("\n", $lines);
}

function getPrescriptionItems($patient) {
    $rx = $patient['discharge']['prescription']['items'] ?? [];
    return is_array($rx) ? $rx : [];
}

// Table shown on the patient / archive detail pages.
function renderPrescriptionBlock($patient) {
    $items = getPrescriptionItems($patient);
    if (!$items) return false;
    $rx = $patient['discharge']['prescription'];
    ?>
    <div class="info-item">
        <div class="label">Wujkunab’al re Elib’al (Ontslagrecept) &middot; <?= htmlspecialchars($rx['number'] ?? '') ?></div>
        <div class="info-value">
            <div class="table-responsive"><table class="records-table">
                <thead><tr><th>Kunab’al</th><th>Uchuq’ab’</th><th>Echab’al</th><th>Jarupa</th><th>Ramaj</th><th>Pixab’</th></tr></thead>
                <tbody>
                <?php foreach ($items as $it): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($it['name'] ?? '') ?></strong></td>
                        <td><?= htmlspecialchars($it['strength'] ?? '') ?></td>
                        <td><?= htmlspecialchars($it['dose'] ?? '') ?></td>
                        <td><?= htmlspecialchars($it['frequency'] ?? '') ?></td>
                        <td><?= htmlspecialchars($it['duration'] ?? '') ?></td>
                        <td><?= htmlspecialchars($it['instructions'] ?? '') ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table></div>
            <?php if (trim($rx['notes'] ?? '') !== ''): ?>
                <div style="margin-top:6px;"><strong>Tz’ib’:</strong> <?= nl2br(htmlspecialchars($rx['notes'])) ?></div>
            <?php endif; ?>
            <div class="text-muted" style="margin-top:6px;font-size:12px;">
                Xtz’ib’ax rumal <?= htmlspecialchars($rx['prescriber'] ?? '') ?> pa <?= htmlspecialchars(formatDate($rx['date'] ?? '')) ?>
            </div>
        </div>
    </div>
    <?php
    return true;
}

// Finds a discharged patient the same way printSummary() does (live file or archive).
function findDischargedPatientForDocument($id, $discharged, $ad) {
    if ($discharged) {
        if (!canViewDischarged()) return [null, 'Xq’ataj ri b’ixikil'];
        $list = $ad ? getDischargedPatients($ad) : getDischargedPatients();
        foreach ($list as $pt) {
            if (is_array($pt) && ($pt['id'] ?? '') == $id) return [$pt, ''];
        }
        return [null, 'Man xriqitaj ta ri yawab’'];
    }
    $p = readJSONFile($GLOBALS['pF']);
    $pi = array_search($id, array_column($p, 'id'));
    if ($pi === false || ($p[$pi]['status'] ?? '') !== 'discharged') return [null, 'Maja kel'];
    return [$p[$pi], ''];
}

function printPrescription() {
    $id = $_GET['id'] ?? '';
    $discharged = $_GET['discharged'] ?? 0;
    $ad = $_GET['date'] ?? '';
    if (!$id) { showError('Maja k’o yawab’'); return; }

    list($patient, $err) = findDischargedPatientForDocument($id, $discharged, $ad);
    if (!$patient) { showError($err); return; }

    $items = getPrescriptionItems($patient);
    if (!$items) { showError('Maja k’o wujkunab’al che we yawab’ ri’'); return; }
    $rx = $patient['discharge']['prescription'];
    $notes = trim($rx['notes'] ?? '');
    $currentUser = $_SESSION['user'] ?? null;
    $printedBy = $currentUser['name'] ?? $currentUser['user'] ?? 'Okisanel Man Etaman Ta';
    logMsg("Wujkunab’al xtz’ib’ax: {$patient['name']} ($id) - " . ($rx['number'] ?? ''));
?>
<!DOCTYPE html>
<html lang="quc">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wujkunab’al re Elib’al - <?= htmlspecialchars($patient['name']) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="hospital.css">
    <link rel="stylesheet" href="style.css">
    <style>
        .rx-wrap { max-width: 900px; margin: 0 auto; }
        .rx-title { font-size: 20px; font-weight: 700; letter-spacing: .5px; text-transform: uppercase; margin: 6px 0 2px; }
        .rx-sub { color: var(--muted); font-size: 12px; margin-bottom: 14px; }
        .rx-symbol { font-size: 34px; font-weight: 700; font-family: Georgia, serif; line-height: 1; margin: 14px 0 6px; }
        .rx-table th, .rx-table td { font-size: 13px; }
        .rx-sign { display: flex; gap: 40px; margin-top: 46px; flex-wrap: wrap; }
        .rx-sign div { flex: 1; min-width: 220px; border-top: 1px solid #000; padding-top: 4px; font-size: 12px; color: var(--ink-soft); }
        .rx-actions { margin-top: 18px; display: flex; gap: 10px; }
        @media print { body { background: #fff; padding: 0; } .rx-actions { display: none; } .app-container { border: none; box-shadow: none; padding: 0; } }
    </style>
</head>
<body>
<div class="app-container rx-wrap">
    <div class="header">
        <div>
            <h1>
                <?php if (file_exists(HOSPITAL_LOGO)): ?><img src="<?= HOSPITAL_LOGO ?>" class="header-logo" alt=""><?php endif; ?>
                <?= HOSPITAL_NAME ?> <small><?= HOSPITAL_ADDRESS ?> &middot; <?= HOSPITAL_PHONE ?></small>
            </h1>
        </div>
    </div>

    <div class="rx-title">Wujkunab’al re Elib’al <small style="font-weight:300;text-transform:none;">(Ontslagrecept)</small></div>
    <div class="rx-sub">
        Aj. <?= htmlspecialchars($rx['number'] ?? '') ?> &middot; Yo’om <?= htmlspecialchars(formatDate($rx['date'] ?? '')) ?>
        &middot; Xtz’ib’ax <?= date('d-m-Y H:i') ?> rumal <?= htmlspecialchars($printedBy) ?>
    </div>

    <div class="detail-grid">
        <div class="detail-item"><div class="label">Yawab’</div><div class="value"><?= htmlspecialchars($patient['name']) ?></div></div>
        <div class="detail-item"><div class="label">ID Yawab’</div><div class="value"><?= htmlspecialchars($patient['id']) ?></div></div>
        <div class="detail-item"><div class="label">Junab’</div><div class="value"><?= htmlspecialchars((string)($patient['age'] ?? '')) ?></div></div>
        <div class="detail-item"><div class="label">Ja</div><div class="value"><?= htmlspecialchars(getDeptName($patient['department'] ?? '')) ?></div></div>
        <div class="detail-item"><div class="label">Xok</div><div class="value"><?= htmlspecialchars(formatDate($patient['admit_date'] ?? '')) ?></div></div>
        <div class="detail-item"><div class="label">Xel</div><div class="value"><?= htmlspecialchars(formatDate($patient['discharge_date'] ?? '')) ?></div></div>
        <div class="detail-item full-width"><div class="label">Alergia</div><div class="value"><?= htmlspecialchars(($patient['allergies'] ?? '') !== '' ? $patient['allergies'] : 'Maja k’o tz’ib’am') ?></div></div>
    </div>

    <div class="rx-symbol">&#8478;</div>
    <div class="table-responsive">
        <table class="records-table rx-table">
            <thead><tr><th>#</th><th>Kunab’al</th><th>Uchuq’ab’</th><th>Echab’al</th><th>Jarupa</th><th>Ramaj</th><th>Pixab’</th></tr></thead>
            <tbody>
            <?php foreach ($items as $n => $it): ?>
                <tr>
                    <td><?= $n + 1 ?></td>
                    <td><strong><?= htmlspecialchars($it['name'] ?? '') ?></strong></td>
                    <td><?= htmlspecialchars($it['strength'] ?? '') ?></td>
                    <td><?= htmlspecialchars($it['dose'] ?? '') ?></td>
                    <td><?= htmlspecialchars($it['frequency'] ?? '') ?></td>
                    <td><?= htmlspecialchars($it['duration'] ?? '') ?></td>
                    <td><?= htmlspecialchars($it['instructions'] ?? '') ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <?php if ($notes !== ''): ?>
        <div class="message info" style="margin-top:12px;"><strong>Tz’ib’:</strong> <?= nl2br(htmlspecialchars($notes)) ?></div>
    <?php endif; ?>

    <div class="rx-sign">
        <div>Ajtz’ib’ wujkunab’al: <?= htmlspecialchars($rx['prescriber'] ?? '') ?><?= !empty($rx['prescriber_role']) ? ' (' . htmlspecialchars($rx['prescriber_role']) . ')' : '' ?><br>Juch’ / retal</div>
        <div>Ajkunab’al kuya kunab’al<br>Q’ij &amp; juch’</div>
    </div>

    <div class="footer">
        <?= HOSPITAL_NAME ?> &middot; <?= HOSPITAL_ADDRESS ?> &middot; Ch’aw <?= HOSPITAL_PHONE ?><br>
        Man utz ta we maja k’o ujuch’ ri ajtz’ib’ &middot; <?= htmlspecialchars($rx['number'] ?? '') ?>
    </div>

    <?php if (!empty($_GET['autoprint'])): ?>
    <script>
        // Opened right after discharge: start the print dialog automatically
        window.addEventListener('load', function () { setTimeout(function () { window.print(); }, 400); });
    </script>
    <?php endif; ?>
    <div class="rx-actions">
        <button class="btn btn-primary" onclick="window.print()"><i class="fas fa-print"></i>&nbsp;Chatz’ib’aj</button>
        <button class="btn" onclick="if (window.opener) { window.close(); } else { window.location.href='?action=discharged'; }">Chatz’apij</button>
    </div>
</div>
</body>
</html>
<?php
}

function showDischargeForm() {
    $id = $_GET['id'] ?? '';
    if (!$id) {
        header('Location: ?action=patients');
        exit;
    }

    $p = readJSONFile($GLOBALS['pF']);
    $pi = array_search($id, array_column($p, 'id'));

    if ($pi === false || $p[$pi]['status'] !== 'admitted') {
        header('Location: ?action=patients');
        exit;
    }

    $pt = $p[$pi];
    $photos = getPatientPhotos($id);
    $photoCount = count($photos);
    $genderClass = isset($pt['gender']) ? str_replace('_', '-', $pt['gender']) : 'prefer-not';

    showHeader();
?>
    <div class="container">
        <div class="form-container" style="max-width:900px;">
            <h2>Chesaj Yawab’ <span class="status-badge status-admitted"><?= $photoCount ?></span></h2>

            <div class="patient-info">
                <p><strong>Ub’i’ Yawab’:</strong> <?= htmlspecialchars($pt['name']) ?> (ID: <?= $pt['id'] ?>)</p>
                <p><strong>Achi/Ixoq:</strong> <span class="gender-badge <?= $genderClass ?>"><?= getGenderName($pt['gender'] ?? 'prefer_not_to_say') ?></span></p>
                <p><strong>Tz’ib’:</strong> Ri yawab’ xel kyakon na <?= archiveScheduleText() ?> (kepe: <?= date('d-m-Y H:i', nextArchiveRun()) ?>)<?= PHOTO_DELETE_ON_ARCHIVE ? ' rachi’ ri uwachib’al kesax na' : '' ?>.</p>
            </div>

            <?php if ($photoCount > 0): ?>
                <div class="card" style="margin-bottom:var(--spacing-xl);">
                    <h3>Wachib’al Yawab’ (<?= $photoCount ?>)</h3>
                    <p class="text-muted">We wachib’al ri’ kek’oji na pa ri peraj re yawab’ yakom.</p>
                    <div class="photo-grid" style="grid-template-columns:repeat(auto-fill, minmax(100px, 1fr));">
                        <?php foreach ($photos as $photo): ?>
                            <div class="photo-card" style="padding:var(--spacing-sm);">
                                <img src="<?= htmlspecialchars($photo['url']) ?>" alt="Wachib’al Yawab’" onclick="window.open(this.src, '_blank')" style="height:80px;" title="Xjotesax: <?= date(DATE_SHORT, $photo['uploaded']) ?>">
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

            <form method="POST" action="?action=discharge">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <input type="hidden" name="id" value="<?= $id ?>">

                <div class="form-group">
                    <label class="required">Ch’utitzijob’al Elib’al</label>
                    <textarea name="summary" required rows="3"></textarea>
                </div>

                <div class="form-group">
                    <label>Pixab’ re Terenik</label>
                    <textarea name="follow" rows="2"></textarea>
                </div>

                <div class="form-group">
                    <label>Wujkunab’al re Elib’al (Ontslagrecept)</label>
                    <p class="text-muted" style="margin-bottom:8px;">Chacha’ jujun kunab’al kuk’am ri yawab’ pa rachoch pa ri cholb’al - echab’al, jarupa rachi’ ramaj kenojisax rachi’ kejalwachix na (o chacha’ &quot;Jun chik&quot; che rutz’ib’axik kunab’al). Ri wujkunab’al katz’ib’ax kab’an rumal. Chaya kan maja k’o we maja k’o kunab’al tz’ib’am.</p>
                    <div id="rxRows"></div>
                    <button type="button" class="btn btn-sm" id="rxAdd" style="margin-top:8px;"><i class="fas fa-plus"></i>&nbsp;Chatz’aqatisaj kunab’al</button>
                </div>

                <div class="form-group">
                    <label>Jun chik tz’ib’ re kunab’al</label>
                    <textarea name="dmeds" rows="2" placeholder="jas chatanab’a ri nab’e kunab’al, utzij ajkunab’al"></textarea>
                </div>

                <?php
                    $stdMeds  = getMedications(true);
                    $stdFreq  = $GLOBALS['standardFrequencies'] ?? [];
                    $stdDur   = $GLOBALS['standardDurations'] ?? [];
                ?>
                <datalist id="rxFreqList"><?php foreach ($stdFreq as $f): ?><option value="<?= htmlspecialchars($f) ?>"><?php endforeach; ?></datalist>
                <datalist id="rxDurList"><?php foreach ($stdDur as $d): ?><option value="<?= htmlspecialchars($d) ?>"><?php endforeach; ?></datalist>

                <script>
                (function () {
                    var box = document.getElementById('rxRows');
                    var MEDS = <?= json_encode($stdMeds, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
                    var OTHER = '__other__';
                    var counter = 0;

                    function el(tag, css, text) {
                        var e = document.createElement(tag);
                        if (css) e.style.cssText = css;
                        if (text) e.textContent = text;
                        return e;
                    }
                    function labelled(label, input, span) {
                        var w = el('div'); w.style.gridColumn = span;
                        w.appendChild(el('label', 'display:block;font-size:11px;font-weight:600;margin-bottom:2px;', label));
                        input.style.width = '100%';
                        w.appendChild(input);
                        return w;
                    }
                    function textInput(name, ph, max, listId) {
                        var i = document.createElement('input');
                        i.type = 'text'; i.name = name + '[]'; i.placeholder = ph; i.maxLength = max || 300;
                        if (listId) i.setAttribute('list', listId);
                        return i;
                    }

                    function addRow() {
                        var id = ++counter;
                        var row = el('div', 'border:1px solid var(--border-soft);border-radius:var(--radius);padding:10px;margin-bottom:8px;background:var(--surface-alt);');
                        var grid = el('div', 'display:grid;grid-template-columns:repeat(4,1fr);gap:8px;');

                        // --- Medication dropdown (standard medications) ---
                        var pick = document.createElement('select');
                        var first = document.createElement('option');
                        first.value = ''; first.textContent = 'Chacha’ kunab’al...';
                        pick.appendChild(first);
                        var groups = {};
                        MEDS.forEach(function (m, idx) {
                            var cat = m.category || 'Jun chik';
                            if (!groups[cat]) {
                                groups[cat] = document.createElement('optgroup'); groups[cat].label = cat;
                                pick.appendChild(groups[cat]);
                            }
                            var o = document.createElement('option'); o.value = idx;
                            o.textContent = m.name + (m.strength ? ' ' + m.strength : '') + (m.dose || m.frequency ? ' - ' + [m.dose, m.frequency].filter(Boolean).join(', ') : '');
                            groups[cat].appendChild(o);
                        });
                        var oo = document.createElement('option');
                        oo.value = OTHER; oo.textContent = 'Jun chik (chatz’ib’aj ub’i’)...';
                        pick.appendChild(oo);

                        // rx_name[] is the field the server reads; it is filled from the dropdown
                        var name = textInput('rx_name', 'Chatz’ib’aj ub’i’ kunab’al', 120);
                        name.style.display = 'none';
                        name.style.marginTop = '4px';

                        var wMed = labelled('Kunab’al *', pick, 'span 2');
                        wMed.appendChild(name);

                        var strength = textInput('rx_strength', 'e.g. 500 mg kunab’al', 60);

                        var dose = textInput('rx_dose', 'e.g. 1 kunab’al', 80);
                        var freq = textInput('rx_freq', 'Chacha’ o chatz’ib’aj', 80, 'rxFreqList');
                        var dur = textInput('rx_duration', 'Chacha’ o chatz’ib’aj', 60, 'rxDurList');
                        var instr = textInput('rx_instr', 'jas rachi’ wa', 300);

                        pick.onchange = function () {
                            if (pick.value === OTHER) {
                                name.style.display = 'block'; name.value = ''; name.required = true; name.focus();
                                return;
                            }
                            name.style.display = 'none'; name.required = false;
                            if (pick.value === '') { name.value = ''; return; }
                            // fill every field from the predefined medication (all remain editable)
                            var m = MEDS[parseInt(pick.value, 10)];
                            name.value = m.name;
                            strength.value = m.strength || '';
                            dose.value = m.dose || '';
                            freq.value = m.frequency || '';
                            dur.value = m.duration || '';
                            instr.value = m.instructions || '';
                        };

                        grid.appendChild(wMed);
                        grid.appendChild(labelled('Uchuq’ab’ / ruk’ojlem', strength, 'span 1'));
                        grid.appendChild(labelled('Echab’al', dose, 'span 1'));
                        grid.appendChild(labelled('Jarupa', freq, 'span 1'));
                        grid.appendChild(labelled('Ramaj', dur, 'span 1'));
                        grid.appendChild(labelled('Pixab’', instr, 'span 2'));

                        var rm = document.createElement('button');
                        rm.type = 'button'; rm.className = 'btn btn-sm btn-danger'; rm.textContent = 'Chesaj';
                        rm.style.marginTop = '8px';
                        rm.onclick = function () { box.removeChild(row); };
                        row.appendChild(grid); row.appendChild(rm); box.appendChild(row);
                    }
                    document.getElementById('rxAdd').onclick = addRow;
                })();
                </script>

                <div class="form-group">
                    <label class="required">Wachinem are xel</label>
                    <select name="condition" required>
                        <option value="">Chacha’</option>
                        <option value="Sib’alaj utz">Sib’alaj utz</option>
                        <option value="Utz">Utz</option>
                        <option value="Nik’aj">Nik’aj</option>
                        <option value="Itzel">Itzel</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Ruk’isb’al Tz’ib’ Ajkun</label>
                    <textarea name="doctor_final_notes" rows="3"></textarea>
                </div>

                <div style="display:flex;gap:15px;margin-top:30px;">
                    <button type="submit" class="btn btn-danger">Chaqatzij Elib’al</button>
                    <a href="?action=patients" class="btn" style="background:var(--text-muted); color:var(--text-inverse);">Chatanab’a</a>
                </div>
            </form>
        </div>
    </div>
<?php
    showFooter();
}

function dischargePatient() {
    $id = $_POST['id'] ?? '';
    $s = trim($_POST['summary'] ?? '');
    $c = $_POST['condition'] ?? '';

    if (!$id || !$s || !$c) {
        header('Location: ?action=patients');
        exit;
    }

    $p = readJSONFile($GLOBALS['pF']);
    $r = readJSONFile($GLOBALS['rF']);
    $pi = array_search($id, array_column($p, 'id'));

    if ($pi === false || $p[$pi]['status'] !== 'admitted') {
        header('Location: ?action=patients');
        exit;
    }

    // Patient photos are kept at discharge so they stay visible under Discharged Patients
    $rid = $p[$pi]['room_id'];
    $roomNum = $p[$pi]['room_num'] ?? '';

    $p[$pi]['status'] = 'discharged';
    $p[$pi]['discharge_date'] = now();
    $rxItems = buildPrescriptionItemsFromPost();
    $rxNotes = trim($_POST['dmeds'] ?? '');
    $p[$pi]['discharge'] = [
        'summary' => $s,
        'follow' => trim($_POST['follow'] ?? ''),
        'meds' => prescriptionToText($rxItems, $rxNotes),
        'cond' => $c,
        'doctor_final_notes' => trim($_POST['doctor_final_notes'] ?? '')
    ];
    if ($rxItems) {
        $p[$pi]['discharge']['prescription'] = [
            'number'          => 'RX-' . date('Ymd') . '-' . substr(preg_replace('/[^A-Za-z0-9]/', '', $id), -4),
            'date'            => now(),
            'prescriber'      => $_SESSION['user']['name'] ?? $_SESSION['user']['user'] ?? 'unknown',
            'prescriber_role' => getRoleName($_SESSION['user']['role'] ?? ''),
            'items'           => $rxItems,
            'notes'           => $rxNotes
        ];
    }
    
    if (empty($p[$pi]['timeline'])) {
        $p[$pi]['timeline'] = [['time' => $p[$pi]['admit_date'] ?? now(), 'type' => 'admit', 'title' => 'Xok',
                                'detail' => "Room $roomNum", 'by' => '']];
    }
    addTimelineEvent($p[$pi], 'discharge', 'Xel', 'Pa Ja ' . $roomNum . ' - wachinem: ' . ($c ?? '') . ($rxItems ? ' - ' . count($rxItems) . ' kunab’al tz’ib’am' : ''));

    $ri = array_search($rid, array_column($r, 'id'));
    if ($ri !== false && $r[$ri]['occ'] > 0) $r[$ri]['occ']--;

    writeJSONFile($GLOBALS['pF'], $p);
    writeJSONFile($GLOBALS['rF'], $r);

    $d = $p[$pi]['department'];
    $gender = $p[$pi]['gender'] ?? 'prefer_not_to_say';
    updateStats('discharged', $d);
    logMsg("Xel: {$p[$pi]['name']} ($id) pa Ja $roomNum - Achi/Ixoq: " . getGenderName($gender) . " - kyakon na " . date(DATE_FORMAT, nextArchiveRun()));

    $_SESSION['success'] = "Yawab’: xel. Ri yawab’ kyakon na " . date('l d-m-Y H:i', nextArchiveRun()) . ".";
    if ($rxItems) {
        logMsg("Wujkunab’al (yo’om: {$p[$pi]['name']} ($id) - " . count($rxItems) . " kunab’al) - " . $p[$pi]['discharge']['prescription']['number']);
        $_SESSION['success'] .= " Wujkunab’al: wujkunab’al re elib’al xb’an.";
        // Open the prescription straight away (no extra click)
        header('Location: ?action=prescription&id=' . urlencode($id) . '&autoprint=1');
        exit;
    }
    header('Location: ?action=patients');
    exit;
}

function showEditForm() {
    $id = $_GET['id'] ?? '';
    if (!$id) {
        header('Location: ?action=patients');
        exit;
    }

    $p = readJSONFile($GLOBALS['pF']);
    $pi = array_search($id, array_column($p, 'id'));

    if ($pi === false || $p[$pi]['status'] !== 'admitted') {
        header('Location: ?action=patients');
        exit;
    }

    $pt = $p[$pi];
    showHeader();
?>
    <div class="container">
        <div class="form-container">
            <h2>Chutzirisaj: <?= htmlspecialchars($pt['name']) ?></h2>

            <form method="POST" action="?action=edit">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <input type="hidden" name="id" value="<?= $id ?>">

                <div class="form-group">
                    <label>Nima Oq’ej</label>
                    <textarea name="complaint"><?= htmlspecialchars($pt['complaint'] ?? '') ?></textarea>
                </div>

                <div class="form-group">
                    <label>Ojer Kunanik</label>
                    <textarea name="history"><?= htmlspecialchars($pt['history'] ?? '') ?></textarea>
                </div>

                <div class="form-group">
                    <label>Alergia</label>
                    <textarea name="allergies"><?= htmlspecialchars($pt['allergies'] ?? '') ?></textarea>
                </div>

                <div class="form-group">
                    <label>Retal re K’aslemal</label>
                    <textarea name="vital_signs"><?= htmlspecialchars($pt['vital_signs'] ?? '') ?></textarea>
                </div>

                <div class="form-group">
                    <label>Kunab’al Kamik</label>
                    <textarea name="current_meds"><?= htmlspecialchars($pt['current_meds'] ?? '') ?></textarea>
                </div>

                <div class="form-group">
                    <label>Kunab’al Tz’ib’am</label>
                    <textarea name="prescribed_meds"><?= htmlspecialchars($pt['prescribed_meds'] ?? '') ?></textarea>
                </div>

                <div class="form-group">
                    <label>Tz’ib’ Ajkun</label>
                    <textarea name="doctor_notes"><?= htmlspecialchars($pt['doctor_notes'] ?? '') ?></textarea>
                </div>

                <div class="form-group">
                    <label>Tz’ib’ Ajchajinel</label>
                    <textarea name="nurse_notes"><?= htmlspecialchars($pt['nurse_notes'] ?? '') ?></textarea>
                </div>

                <div style="display:flex;gap:15px;margin-top:30px;">
                    <button type="submit" class="btn btn-primary">Chak’ak’arisaj</button>
                    <a href="?action=view&id=<?= $id ?>" class="btn" style="background:var(--text-muted); color:var(--text-inverse);">Chatanab’a</a>
                </div>
            </form>
        </div>
    </div>
<?php
    showFooter();
}

function editPatient() {
    $id = $_POST['id'] ?? '';
    if (!$id) {
        header('Location: ?action=patients');
        exit;
    }

    $p = readJSONFile($GLOBALS['pF']);
    $pi = array_search($id, array_column($p, 'id'));

    if ($pi === false || $p[$pi]['status'] !== 'admitted') {
        header('Location: ?action=patients');
        exit;
    }

    $p[$pi]['complaint'] = trim($_POST['complaint'] ?? '');
    $p[$pi]['history'] = trim($_POST['history'] ?? '');
    $p[$pi]['allergies'] = trim($_POST['allergies'] ?? '');
    $p[$pi]['vital_signs'] = trim($_POST['vital_signs'] ?? '');
    $p[$pi]['current_meds'] = trim($_POST['current_meds'] ?? '');
    $p[$pi]['prescribed_meds'] = trim($_POST['prescribed_meds'] ?? '');
    $p[$pi]['doctor_notes'] = trim($_POST['doctor_notes'] ?? '');
    $p[$pi]['nurse_notes'] = trim($_POST['nurse_notes'] ?? '');

    writeJSONFile($GLOBALS['pF'], $p);
    logMsg("Xk’ak’arisaxik: {$p[$pi]['name']} ($id)");

    $_SESSION['success'] = 'Yawab’: retal xk’ak’arisax';
    header('Location: ?action=view&id=' . $id);
    exit;
}

function showChangeForm() {
    $id = $_GET['id'] ?? '';
    $id = preg_replace('/[^a-zA-Z0-9\-]/', '', $id);
    if (!$id || strlen($id) > 50) {
        header('Location: ?action=patients');
        exit;
    }

    $p = readJSONFile($GLOBALS['pF']);
    $r = readJSONFile($GLOBALS['rF']);
    
    if (!is_array($r)) {
        $r = [];
    }
    
    $pi = array_search($id, array_column($p, 'id'));

    if ($pi === false || $p[$pi]['status'] !== 'admitted') {
        header('Location: ?action=patients');
        exit;
    }

    $pt = $p[$pi];
    
    $chiefComplaint = isset($pt['complaint']) && !empty($pt['complaint']) ? $pt['complaint'] : '';
    
    $complaintDate = '';
    if (isset($pt['complaint_date']) && !empty($pt['complaint_date'])) {
        $complaintDate = $pt['complaint_date'];
    } elseif (isset($pt['admit_date']) && !empty($pt['admit_date'])) {
        $complaintDate = $pt['admit_date'];
    }
    
    $currentRoomIndex = array_search($pt['room_id'], array_column($r, 'id'));
    $currentRoom = $currentRoomIndex !== false ? $r[$currentRoomIndex] : null;
    
    if ($currentRoom) {
        $currentRoom['occ'] = $currentRoom['occ'] ?? 0;
        $currentRoom['beds'] = $currentRoom['beds'] ?? 1;
        $currentRoom['num'] = $currentRoom['num'] ?? 'Maja k’o';
        $currentRoom['dept'] = $currentRoom['dept'] ?? '';
        $currentRoom['is_full'] = ($currentRoom['occ'] >= $currentRoom['beds']);
        $currentRoom['available_beds'] = $currentRoom['beds'] - $currentRoom['occ'];
    }
    
    $currentDept = $currentRoom ? ($currentRoom['dept'] ?? '') : '';
    
    $roomsByDept = [];
    $roomPatients = [];
    
    foreach ($p as $patient) {
        if ($patient['status'] === 'admitted' && isset($patient['room_id'])) {
            if (!isset($roomPatients[$patient['room_id']])) {
                $roomPatients[$patient['room_id']] = [];
            }
            
            $patient['display_complaint'] = isset($patient['complaint']) ? $patient['complaint'] : '';
            $patient['display_gender'] = isset($patient['gender']) ? getGenderName($patient['gender']) : '';
            $roomPatients[$patient['room_id']][] = $patient;
        }
    }
    
    foreach ($r as $rm) {
        $rm['id'] = $rm['id'] ?? '';
        $rm['num'] = $rm['num'] ?? 'Maja k’o';
        $rm['dept'] = $rm['dept'] ?? '';
        $rm['beds'] = $rm['beds'] ?? 1;
        $rm['occ'] = $rm['occ'] ?? 0;
        
        $dept = $rm['dept'];
        if (!isset($roomsByDept[$dept])) {
            $roomsByDept[$dept] = [];
        }
        
        $rm['patient_count'] = isset($roomPatients[$rm['id']]) ? count($roomPatients[$rm['id']]) : 0;
        $rm['patients'] = isset($roomPatients[$rm['id']]) ? $roomPatients[$rm['id']] : [];
        $rm['available_beds'] = $rm['beds'] - $rm['occ'];
        $rm['is_full'] = ($rm['occ'] >= $rm['beds']);
        $rm['occupancy_percent'] = $rm['beds'] > 0 ? ($rm['occ'] / $rm['beds']) * 100 : 0;
        
        $roomsByDept[$dept][] = $rm;
    }

    ksort($roomsByDept);

    $photos = getPatientPhotos($id);
    $hasPhoto = !empty($photos);
    $photoCount = count($photos);
    $genderClass = isset($pt['gender']) ? str_replace('_', '-', $pt['gender']) : 'prefer-not';

    showHeader();
?>
    <style>
    .room-full {
        background-color: #f1f1f1 !important;
        border-color: #818181 !important;
        opacity: 0.8;
    }
    .room-available {
        background-color: #f0f0f0 !important;
        border-color: #878787 !important;
    }
    .room-limited {
        background-color: #f4f4f4 !important;
        border-color: #a5a5a5 !important;
    }
    .current-room {
        border-color: var(--primary) !important;
        border-width: 3px !important;
        background-color: #efefef !important;
    }
    .status-indicator {
        display: inline-block;
        width: 12px;
        height: 12px;
        border-radius: 50%;
        margin-right: 5px;
    }
    .status-full { background-color: #ef5350; }
    .status-available { background-color: #4caf50; }
    .status-limited { background-color: #ff9800; }
    .patient-thumbnail {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        object-fit: cover;
        border: 2px solid #fff;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        cursor: pointer;
        transition: transform 0.2s;
    }
    .patient-thumbnail:hover {
        transform: scale(1.1);
    }
    .patient-badge {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        background: #f5f5f5;
        padding: 3px 8px;
        border-radius: 20px;
        font-size: 0.75rem;
        margin: 2px;
        max-width: 220px;
    }
    .patient-badge-content {
        overflow: hidden;
        flex: 1;
    }
    .patient-badge-complaint {
        font-size: 0.65rem;
        color: #555;
        font-style: italic;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        max-width: 130px;
        background: #fff9c4;
        padding: 2px 8px;
        border-radius: 12px;
        margin-top: 2px;
        display: inline-block;
        border: 1px solid #ffe082;
    }
    .complaint-badge {
        display: inline-block;
        background: #fff3cd;
        color: #856404;
        padding: 2px 8px;
        border-radius: 12px;
        font-size: 0.7rem;
        margin-left: 5px;
        font-weight: normal;
        border: 1px solid #ffeeba;
    }
    .complaint-display {
        background: #fff9e6;
        border-left: 3px solid #ffc107;
        padding: 10px 15px;
        margin: 10px 0;
        border-radius: 0 var(--border-radius) var(--border-radius) 0;
        font-size: 0.95rem;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }
    .complaint-label {
        font-weight: bold;
        color: #856404;
        margin-right: 8px;
    }
    .complaint-text {
        color: #333;
        font-style: italic;
    }
    .complaint-empty {
        color: #999;
        font-style: italic;
    }
    .complaint-tooltip {
        position: relative;
        display: inline-block;
        cursor: help;
    }
    .complaint-tooltip .complaint-tooltip-text {
        visibility: hidden;
        width: 220px;
        background-color: #333;
        color: #fff;
        text-align: center;
        border-radius: 6px;
        padding: 8px;
        position: absolute;
        z-index: 100;
        bottom: 125%;
        left: 50%;
        margin-left: -110px;
        opacity: 0;
        transition: opacity 0.3s;
        font-size: 0.75rem;
        white-space: normal;
        word-wrap: break-word;
        box-shadow: 0 2px 10px rgba(0,0,0,0.2);
    }
    .complaint-tooltip:hover .complaint-tooltip-text {
        visibility: visible;
        opacity: 1;
    }
    .room-patient-list {
        max-height: 180px;
        overflow-y: auto;
        margin-top: 8px;
        padding: 8px;
        background: rgba(0,0,0,0.02);
        border-radius: 4px;
        border: 1px solid #eee;
    }
    .photo-gallery {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
        gap: 15px;
        margin: 20px 0;
    }
    .photo-item {
        border: 1px solid var(--border-color);
        border-radius: var(--border-radius);
        padding: 10px;
        background: white;
    }
    .photo-item img {
        width: 100%;
        height: 120px;
        object-fit: cover;
        border-radius: 4px;
        cursor: pointer;
    }
    .photo-id {
        font-size: 0.7rem;
        color: #666;
        margin-top: 5px;
        text-align: center;
        word-break: break-all;
    }
    .stats-card {
        background: white;
        border-radius: var(--border-radius);
        padding: 15px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .room-option {
        transition: all 0.3s ease;
        position: relative;
    }
    .room-option:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.15);
    }
    .filter-badge {
        display: inline-block;
        padding: 5px 10px;
        border-radius: 20px;
        font-size: 0.8rem;
        margin: 0 5px 5px 0;
        cursor: pointer;
        border: 1px solid transparent;
        background: #f0f0f0;
    }
    .filter-badge.active {
        border-color: var(--primary);
        background: var(--primary-light);
        font-weight: bold;
    }
    .filter-badge:hover {
        background: #e0e0e0;
    }
    .dept-header {
        background: var(--primary-dark);
        color: var(--text-inverse);
        padding: var(--spacing-sm);
        border-radius: var(--border-radius) var(--border-radius) 0 0;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .no-beds-badge {
        background: #ef5350;
        padding: 2px 8px;
        border-radius: 12px;
        font-size: 0.7rem;
        color: white;
    }
    .search-box {
        margin-bottom: 15px;
        width: 100%;
        padding: 10px;
        border: 1px solid var(--border-color);
        border-radius: var(--border-radius);
        font-size: 1rem;
    }
    .stat-item {
        padding: 10px;
        background: #f5f5f5;
        border-radius: var(--border-radius);
    }
    .warning-message {
        background: #fff3cd;
        color: #856404;
        padding: 10px;
        border-radius: var(--border-radius);
        margin-bottom: 15px;
        border-left: 4px solid #ffc107;
    }
    .gender-badge-sm {
        display: inline-block;
        padding: 1px 4px;
        border-radius: 10px;
        font-size: 0.6rem;
        font-weight: 500;
        margin-right: 3px;
    }
    </style>

    <div class="container">
        <div class="form-container" style="max-width:900px;">
            <h2>Chajalwachij Ja: <?= htmlspecialchars($pt['name']) ?></h2>
            
            <?php if (!$currentRoom): ?>
                <div class="warning-message">
                    <strong>Pixab’:</strong> Ri yawab’ xya pa jun ja maja k’o pa ri retal re taq ja. 
                    Chacha’ jun k’ak’ ja chuxe’.
                </div>
            <?php endif; ?>
            
            <div class="stats-card" style="margin-bottom:var(--spacing-xl);">
                <div style="display:flex; align-items:center; gap:20px; flex-wrap:wrap;">
                    <?php if ($hasPhoto): ?>
                        <img src="<?= htmlspecialchars($photos[0]['url']) ?>" 
                             alt="Wachib’al Yawab’" 
                             style="width:80px; height:80px; border-radius:50%; object-fit:cover; border:3px solid var(--primary);">
                    <?php endif; ?>
                    <div style="flex:1;">
                        <h3 style="margin:0; display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
                            <?= htmlspecialchars($pt['name']) ?>
                            <span class="gender-badge <?= $genderClass ?>">
                                <?= getGenderName($pt['gender'] ?? 'prefer_not_to_say') ?>
                            </span>
                            <?php if (!empty($chiefComplaint)): ?>
                                <span class="complaint-badge" title="Nima Oq’ej">Oq’ej</span>
                            <?php endif; ?>
                        </h3>
                        <p style="margin:5px 0;"><strong>ID Yawab’:</strong> <?= htmlspecialchars($pt['id']) ?></p>
                        <p style="margin:5px 0;"><strong>Junab’:</strong> <?= $pt['age'] ?? '?' ?></p>
                        <p style="margin:5px 0;"><strong>Ja Kamik:</strong> 
                            <?php if ($currentRoom): ?>
                                Ja <?= htmlspecialchars($currentRoom['num'] ?? 'Man etaman ta') ?> 
                                (<?= getDeptName($currentDept) ?>)
                            <?php else: ?>
                                <span style="color: #ef5350;">Ri yaik ja man utz ta (ID: <?= htmlspecialchars($pt['room_id'] ?? 'Maja k’o') ?>)</span>
                            <?php endif; ?>
                        </p>
                        
                        <div class="complaint-display">
                            <span class="complaint-label">Nima Oq’ej:</span>
                            <?php if (!empty($chiefComplaint)): ?>
                                <span class="complaint-text">"<?= htmlspecialchars($chiefComplaint) ?>"</span>
                                <?php if (!empty($complaintDate)): ?>
                                    <span style="font-size:0.8rem; color:#666; margin-left:10px;">
                                        (B’im: <?= formatDateShort($complaintDate) ?>)
                                    </span>
                                <?php endif; ?>
                            <?php else: ?>
                                <span class="complaint-empty">Maja k’o oq’ej tz’ib’am</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div style="text-align:right;">
                        <?php 
                        $roomStatus = 'Man etaman ta';
                        $statusClass = 'status-available';
                        
                        if ($currentRoom) {
                            $isRoomFull = $currentRoom['is_full'] ?? ($currentRoom['occ'] >= $currentRoom['beds']);
                            $roomStatus = $isRoomFull ? 'Nojinaq' : 'Tolon';
                            $statusClass = $isRoomFull ? 'status-full' : 'status-available';
                        }
                        ?>
                        <span class="status-indicator <?= $statusClass ?>"></span>
                        <strong>Wachinem Ja:</strong> 
                        <?= $roomStatus ?>
                    </div>
                </div>
            </div>

            <?php if ($hasPhoto): ?>
                <div class="stats-card" style="margin-bottom:var(--spacing-xl);">
                    <h3>Wachib’al Yawab’ (<?= $photoCount ?>)</h3>
                    <div class="photo-gallery">
                        <?php foreach ($photos as $index => $photo): ?>
                            <div class="photo-item">
                                <img src="<?= htmlspecialchars($photo['url']) ?>" 
                                     alt="Wachib’al Yawab’ <?= $index + 1 ?>"
                                     onclick="window.open(this.src, '_blank')">
                                <div class="photo-id">
                                    <strong>ID Wachib’al:</strong> <?= htmlspecialchars(basename($photo['url'])) ?><br>
                                    <small>Chapitz’a’ che unimarisaxik</small>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

            <form method="POST" action="?action=change<?= (($_GET['return'] ?? '') === 'view') ? '&return=view' : '' ?>" id="changeRoomForm">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">
                <input type="hidden" name="id" value="<?= htmlspecialchars($id) ?>">
                <input type="hidden" name="current_room" value="<?= htmlspecialchars($pt['room_id'] ?? '') ?>">

                <div class="stats-card" style="margin-bottom:var(--spacing-xl);">
                    <h4>Chach’ay Ja</h4>
                    <div style="display:flex; gap:15px; flex-wrap:wrap; margin-bottom:15px;">
                        <select id="deptFilter" class="form-control" style="flex:1;" onchange="filterRooms()">
                            <option value="">Ronoj K’olb’al</option>
                            <?php foreach ($GLOBALS['depts'] as $code => $name): ?>
                                <option value="<?= htmlspecialchars($code) ?>"><?= htmlspecialchars($name) ?></option>
                            <?php endforeach; ?>
                        </select>
                        
                        <select id="statusFilter" class="form-control" style="flex:1;" onchange="filterRooms()">
                            <option value="">Ronoj Ja</option>
                            <option value="available">Xa Tolon</option>
                            <option value="full">Ja Nojinaq</option>
                            <option value="limited">Xa jub’iq’ Warab’al (≤2 tolon)</option>
                        </select>
                    </div>
                    
                    <div style="margin-top:10px;">
                        <span class="filter-badge" onclick="quickFilter('available')">🟢 Xa Tolon</span>
                        <span class="filter-badge" onclick="quickFilter('full')">🔴 Ja Nojinaq</span>
                        <span class="filter-badge" onclick="quickFilter('limited')">🟠 Xa jub’iq’ Warab’al</span>
                        <span class="filter-badge" onclick="resetFilters()">🔄 Chi jun mul</span>
                    </div>
                </div>

                <input type="text" id="roomSearch" class="search-box" 
                       placeholder="Chatzukuj ja rumal ajilab’al, ub’i’ yawab’, achi/ixoq o oq’ej..." 
                       onkeyup="searchRooms()">

                <div class="form-group">
                    <label class="required">Chacha’ K’ak’ Ja:</label>
                    <div id="roomsContainer">
                        <?php if (empty($roomsByDept)): ?>
                            <div class="warning-message">Maja k’o ja tolon pa ri ucholajil.</div>
                        <?php endif; ?>
                        
                        <?php foreach ($roomsByDept as $deptCode => $rooms): 
                            $deptName = getDeptName($deptCode);
                            $isCurrentDept = ($deptCode == $currentDept);
                            
                            $deptHasAvailable = false;
                            $availableCount = 0;
                            foreach ($rooms as $rm) {
                                if (!$rm['is_full']) {
                                    $deptHasAvailable = true;
                                    $availableCount++;
                                }
                            }
                        ?>
                            <div class="dept-room-group" data-dept="<?= htmlspecialchars($deptCode) ?>" 
                                 data-has-available="<?= $deptHasAvailable ? 'true' : 'false' ?>"
                                 style="margin-bottom:var(--spacing-xl); <?= $isCurrentDept ? 'border-left:3px solid var(--primary);' : '' ?>">
                                
                                <div class="dept-header" style="background:<?= $isCurrentDept ? 'var(--primary)' : 'var(--primary-dark)'; ?>;">
                                    <div>
                                        <strong><?= htmlspecialchars($deptName) ?></strong>
                                        <?php if (!$deptHasAvailable): ?>
                                            <span class="no-beds-badge" style="margin-left:10px;">
                                                Maja k’o Warab’al Tolon
                                            </span>
                                        <?php else: ?>
                                            <span style="margin-left:10px; background:#4caf50; padding:2px 8px; border-radius:12px; font-size:0.7rem;">
                                                <?= $availableCount ?> ja tolon
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <?php if ($isCurrentDept): ?>
                                        <span>⬅ K’olb’al Kamik</span>
                                    <?php endif; ?>
                                </div>
                                
                                <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(320px,1fr)); gap:var(--spacing-md); padding:var(--spacing-md); background:#f9f9f9;">
                                    <?php foreach ($rooms as $rm):
                                        $isCurrentRoom = ($rm['id'] == $pt['room_id']);
                                        $roomClass = $rm['is_full'] ? 'room-full' : ($rm['available_beds'] <= 2 ? 'room-limited' : 'room-available');
                                        if ($isCurrentRoom) {
                                            $roomClass .= ' current-room';
                                        }
                                        $available = $rm['available_beds'];
                                    ?>
                                        <div class="room-option <?= $roomClass ?>" 
                                             data-status="<?= $rm['is_full'] ? 'full' : ($available <= 2 ? 'limited' : 'available') ?>"
                                             data-room-num="<?= strtolower(htmlspecialchars($rm['num'])) ?>"
                                             style="border:2px solid; padding:var(--spacing-md); border-radius:var(--border-radius); position:relative;">
                                            
                                            <?php if ($isCurrentRoom): ?>
                                                <div style="position:absolute; top:-10px; right:10px; background:var(--primary); color:white; padding:2px 10px; border-radius:12px; font-size:0.7rem; z-index:1;">
                                                    Ja kamik
                                                </div>
                                            <?php endif; ?>
                                            
                                            <label style="display:block; cursor:<?= $isCurrentRoom ? 'default' : 'pointer' ?>;">
                                                <input type="radio" name="new_room" value="<?= htmlspecialchars($rm['id']) ?>" 
                                                       <?= $isCurrentRoom ? 'checked disabled' : ($rm['is_full'] ? 'disabled' : '') ?>
                                                       style="margin-right:var(--spacing-xs);"
                                                       onchange="highlightSelection(this)">
                                                
                                                <div style="display:flex; justify-content:space-between; align-items:start;">
                                                    <div>
                                                        <strong style="font-size:1.1rem;">Ja <?= htmlspecialchars($rm['num']) ?></strong>
                                                        <div style="margin-top:5px;">
                                                            <span class="status-indicator <?= $rm['is_full'] ? 'status-full' : ($available <= 2 ? 'status-limited' : 'status-available') ?>"></span>
                                                            <span style="font-size:0.9rem;">
                                                                <?= max(0, $available) ?> re <?= $rm['beds'] ?> warab’al tolon
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <div style="text-align:right;">
                                                        <div style="font-size:0.8rem; color:#666;">
                                                            Okinaq: <?= round($rm['occupancy_percent']) ?>%
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="progress-bar" style="height:6px; margin:10px 0; background:#e0e0e0;">
                                                    <div class="progress-fill" style="width:<?= min(100, $rm['occupancy_percent']) ?>%; 
                                                         height:6px; background:<?= $rm['is_full'] ? '#818181' : ($available <= 2 ? '#a5a5a5' : '#878787') ?>;">
                                                    </div>
                                                </div>
                                                
                                                <?php if (!empty($rm['patients'])): ?>
                                                    <div class="room-patient-list">
                                                        <div style="font-size:0.8rem; font-weight:bold; margin-bottom:5px; display:flex; justify-content:space-between;">
                                                            <span>Yawab’ Kamik (<?= count($rm['patients']) ?>):</span>
                                                            <?php 
                                                            $patientsWithComplaint = count(array_filter($rm['patients'], function($p) {
                                                                return !empty($p['display_complaint']);
                                                            }));
                                                            if ($patientsWithComplaint > 0): ?>
                                                                <span style="color:#856404; font-size:0.7rem;">
                                                                     <?= $patientsWithComplaint ?> rachi’ oq’ej
                                                                </span>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div style="display:flex; flex-wrap:wrap; gap:5px;">
                                                            <?php foreach (array_slice($rm['patients'], 0, 4) as $patient): 
                                                                $patientPhotos = getPatientPhotos($patient['id']);
                                                                $hasComplaint = !empty($patient['display_complaint']);
                                                                $genderClass = isset($patient['gender']) ? str_replace('_', '-', $patient['gender']) : 'prefer-not';
                                                            ?>
                                                                <div class="patient-badge <?= $hasComplaint ? 'has-complaint' : '' ?>" 
                                                                     title="<?= htmlspecialchars($patient['name']) ?> (ID: <?= htmlspecialchars($patient['id']) ?>)">
                                                                    <?php if (!empty($patientPhotos)): ?>
                                                                        <img src="<?= htmlspecialchars($patientPhotos[0]['url']) ?>" 
                                                                             alt="Yawab’" 
                                                                             class="patient-thumbnail"
                                                                             onclick="event.stopPropagation(); window.open(this.src, '_blank')">
                                                                    <?php else: ?>
                                                                        <div style="width:40px; height:40px; border-radius:50%; background:#ccc; display:flex; align-items:center; justify-content:center; font-size:1.2rem;">
                                                                            👤
                                                                        </div>
                                                                    <?php endif; ?>
                                                                    <div class="patient-badge-content">
                                                                        <div style="display:flex; align-items:center; gap:5px; flex-wrap:wrap;">
                                                                            <span style="font-weight:500;"><?= htmlspecialchars(substr($patient['name'], 0, 10)) ?><?= strlen($patient['name']) > 10 ? '…' : '' ?></span>
                                                                            <span class="gender-badge-sm <?= $genderClass ?>">
                                                                                <?= getGenderName($patient['gender'] ?? 'prefer_not_to_say') ?>
                                                                            </span>
                                                                            <?php if ($hasComplaint): ?>
                                                                                <span class="complaint-tooltip">
                                                                                    <span style="background:#ffc107; color:#856404; padding:0 4px; border-radius:4px; font-size:0.6rem; font-weight:bold;">C</span>
                                                                                    <span class="complaint-tooltip-text">
                                                                                        <strong>Nima Oq’ej:</strong> <?= htmlspecialchars($patient['display_complaint']) ?>
                                                                                    </span>
                                                                                </span>
                                                                            <?php endif; ?>
                                                                        </div>
                                                                        <div style="font-size:0.6rem; color:#666;">ID: <?= htmlspecialchars(substr($patient['id'], 0, 6)) ?>…</div>
                                                                        <?php if ($hasComplaint): ?>
                                                                            <div class="patient-badge-complaint">
                                                                                "<?= htmlspecialchars(substr($patient['display_complaint'], 0, 20)) ?><?= strlen($patient['display_complaint']) > 20 ? '…' : '' ?>"
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                            <?php endforeach; ?>
                                                            <?php if (count($rm['patients']) > 4): ?>
                                                                <div class="patient-badge" style="background:#e0e0e0;">
                                                                    +<?= count($rm['patients']) - 4 ?> chik
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                <?php else: ?>
                                                    <div style="font-size:0.8rem; color:#999; text-align:center; margin-top:10px; padding:5px;">
                                                        Maja k’o yawab’ pa we ja ri’
                                                    </div>
                                                <?php endif; ?>
                                            </label>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="stats-card" style="margin:var(--spacing-lg) 0;">
                    <h4>Nab’e wuj re Wachinem Ja re Kunanik</h4>
                    <div style="display:grid; grid-template-columns:repeat(4,1fr); gap:var(--spacing-md); text-align:center; margin-bottom:20px;">
                        <?php 
                        $totalBeds = 0;
                        $occupiedBeds = 0;
                        $fullRooms = 0;
                        $totalRooms = 0;
                        
                        foreach ($r as $rm) {
                            $beds = $rm['beds'] ?? 1;
                            $occ = $rm['occ'] ?? 0;
                            $totalBeds += $beds;
                            $occupiedBeds += $occ;
                            if ($occ >= $beds) $fullRooms++;
                            $totalRooms++;
                        }
                        
                        $availableBeds = $totalBeds - $occupiedBeds;
                        $occupancyRate = $totalBeds > 0 ? ($occupiedBeds / $totalBeds) * 100 : 0;
                        ?>
                        
                        <div class="stat-item">
                            <div style="font-size:0.8rem; color:#666;">Ronoj Warab’al</div>
                            <div style="font-size:1.5rem; font-weight:bold;"><?= $totalBeds ?></div>
                        </div>
                        <div class="stat-item">
                            <div style="font-size:0.8rem; color:#666;">K’o winaq</div>
                            <div style="font-size:1.5rem; font-weight:bold; color:#ef5350;"><?= $occupiedBeds ?></div>
                        </div>
                        <div class="stat-item">
                            <div style="font-size:0.8rem; color:#666;">Tolon</div>
                            <div style="font-size:1.5rem; font-weight:bold; color:#4caf50;"><?= max(0, $availableBeds) ?></div>
                        </div>
                        <div class="stat-item">
                            <div style="font-size:0.8rem; color:#666;">Ja Nojinaq</div>
                            <div style="font-size:1.5rem; font-weight:bold; color:#ef5350;"><?= $fullRooms ?>/<?= $totalRooms ?></div>
                        </div>
                    </div>
                    
                    <div style="margin-top:15px;">
                        <div style="display:flex; justify-content:space-between; margin-bottom:5px;">
                            <span>Ronoj Okinaq: <?= round($occupancyRate) ?>%</span>
                            <span><?= $occupiedBeds ?> / <?= $totalBeds ?> warab’al</span>
                        </div>
                        <div class="progress-bar" style="height:10px; background:#e0e0e0;">
                            <div class="progress-fill" style="width:<?= min(100, $occupancyRate) ?>%; 
                                 height:10px; background:<?= $occupancyRate >= 90 ? '#818181' : ($occupancyRate >= 75 ? '#a5a5a5' : '#878787') ?>;">
                            </div>
                        </div>
                    </div>
                </div>

                <div style="display:flex;gap:15px;margin-top:30px;">
                    <button type="submit" class="btn btn-primary" onclick="return validateRoomSelection()">Chajalwachij Ja</button>
                    <a href="?action=patients" class="btn" style="background:var(--text-muted); color:var(--text-inverse);">Chatanab’a</a>
                </div>
            </form>
        </div>
    </div>

    <script>
    function filterRooms() {
        const selectedDept = document.getElementById('deptFilter').value;
        const selectedStatus = document.getElementById('statusFilter').value;
        const roomGroups = document.querySelectorAll('.dept-room-group');
        
        roomGroups.forEach(group => {
            const groupDept = group.getAttribute('data-dept');
            let groupVisible = selectedDept === '' || groupDept === selectedDept;
            
            if (groupVisible) {
                const rooms = group.querySelectorAll('.room-option');
                let hasVisibleRoom = false;
                
                rooms.forEach(room => {
                    const roomStatus = room.getAttribute('data-status');
                    let roomVisible = true;
                    
                    if (selectedStatus !== '') {
                        roomVisible = (roomStatus === selectedStatus);
                    }
                    
                    room.style.display = roomVisible ? 'block' : 'none';
                    if (roomVisible) hasVisibleRoom = true;
                });
                
                group.style.display = hasVisibleRoom ? 'block' : 'none';
            } else {
                group.style.display = 'none';
            }
        });
    }

    function searchRooms() {
        const searchText = document.getElementById('roomSearch').value.toLowerCase();
        const rooms = document.querySelectorAll('.room-option');
        let anyVisible = false;
        
        rooms.forEach(room => {
            const roomNumber = room.querySelector('strong')?.textContent.toLowerCase() || '';
            
            const patientInfo = Array.from(room.querySelectorAll('.patient-badge')).map(badge => {
                const nameElement = badge.querySelector('.patient-badge-content > div:first-child span');
                const name = nameElement ? nameElement.textContent.toLowerCase() : '';
                
                const genderElement = badge.querySelector('.gender-badge-sm');
                const gender = genderElement ? genderElement.textContent.toLowerCase() : '';
                
                const complaintElement = badge.querySelector('.patient-badge-complaint');
                const complaint = complaintElement ? complaintElement.textContent.toLowerCase() : '';
                
                const tooltipElement = badge.querySelector('.complaint-tooltip-text');
                const tooltipComplaint = tooltipElement ? tooltipElement.textContent.toLowerCase() : '';
                
                return { name, gender, complaint, tooltipComplaint };
            });
            
            let matches = roomNumber.includes(searchText);
            
            patientInfo.forEach(info => {
                if (info.name.includes(searchText) || 
                    info.gender.includes(searchText) ||
                    info.complaint.includes(searchText) || 
                    info.tooltipComplaint.includes(searchText)) {
                    matches = true;
                }
            });
            
            room.style.display = matches ? 'block' : 'none';
            if (matches) anyVisible = true;
        });
        
        document.querySelectorAll('.dept-room-group').forEach(group => {
            const visibleRooms = Array.from(group.querySelectorAll('.room-option')).some(room => room.style.display !== 'none');
            group.style.display = visibleRooms ? 'block' : 'none';
        });
        
        let noResultsMsg = document.getElementById('noSearchResults');
        if (!anyVisible && searchText !== '') {
            if (!noResultsMsg) {
                noResultsMsg = document.createElement('div');
                noResultsMsg.id = 'noSearchResults';
                noResultsMsg.className = 'warning-message';
                noResultsMsg.textContent = 'Maja k’o ja junam rik’in ri katzukuj.';
                document.getElementById('roomsContainer').prepend(noResultsMsg);
            }
        } else if (noResultsMsg) {
            noResultsMsg.remove();
        }
    }

    function quickFilter(status) {
        document.getElementById('statusFilter').value = status;
        filterRooms();
        
        document.querySelectorAll('.filter-badge').forEach(badge => {
            badge.classList.remove('active');
        });
        event.target.classList.add('active');
    }

    function resetFilters() {
        document.getElementById('deptFilter').value = '';
        document.getElementById('statusFilter').value = '';
        document.getElementById('roomSearch').value = '';
        filterRooms();
        searchRooms();
        
        document.querySelectorAll('.filter-badge').forEach(badge => {
            badge.classList.remove('active');
        });
    }

    function highlightSelection(radio) {
        document.querySelectorAll('.room-option').forEach(room => {
            room.style.borderWidth = '2px';
        });
        
        if (radio && !radio.disabled) {
            radio.closest('.room-option').style.borderWidth = '4px';
        }
    }

    function validateRoomSelection() {
        const selectedRoom = document.querySelector('input[name="new_room"]:checked:not(:disabled)');
        
        if (!selectedRoom) {
            alert('Chacha’ jun k’ak’ ja che rujalwachixik ri yawab’.');
            return false;
        }
        
        const selectedRoomDiv = selectedRoom.closest('.room-option');
        const isFull = selectedRoomDiv.classList.contains('room-full');
        
        if (isFull) {
            if (!confirm('Pixab’: We ja ri’ nojinaq kamik. We kajalwachix ri yawab’ waral kq’axtaj ri uchuq’ab’. Chab’ana’ na?')) {
                return false;
            }
        }
        
        const hasComplaint = <?= !empty($chiefComplaint) ? 'true' : 'false' ?>;
        const photoCount = <?= $photoCount ?>;
        
        let message = 'La qastzij kawaj kajalwachij rija re we yawab’ ri’?';
        if (hasComplaint && photoCount > 0) {
            message = 'We yawab’ ri’ k’o uoq’ej tz’ib’am rachi’ ' + photoCount + ' wachib’al. Chab’ana’ na ri jalwachinik ja?';
        } else if (hasComplaint) {
            message = 'We yawab’ ri’ k’o uoq’ej tz’ib’am. Chab’ana’ na ri jalwachinik ja?';
        } else if (photoCount > 0) {
            message = 'We yawab’ ri’ k’o ' + photoCount + ' uwachib’al. Chab’ana’ na ri jalwachinik ja?';
        }
        
        return confirm(message);
    }

    document.addEventListener('DOMContentLoaded', function() {
        let searchTimeout;
        const searchInput = document.getElementById('roomSearch');
        searchInput.addEventListener('keyup', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                searchRooms();
            }, 300);
        });
        
        console.log('Room change form initialized with Gender and Complaint fields');
    });
    </script>
<?php
    showFooter();
}

function changeRoom() {
    $id = $_POST['id'] ?? '';
    $nrid = intval($_POST['new_room'] ?? 0);

    if (!$id || !$nrid) {
        $_SESSION['error'] = 'Maja k’o ja cha’om';
        header('Location: ?action=patients');
        exit;
    }

    $p = readJSONFile($GLOBALS['pF']);
    $r = readJSONFile($GLOBALS['rF']);
    $pi = array_search($id, array_column($p, 'id'));

    if ($pi === false || $p[$pi]['status'] !== 'admitted') {
        $_SESSION['error'] = 'Man xriqitaj ta ri yawab’';
        header('Location: ?action=patients');
        exit;
    }

    $crid = (int)$p[$pi]['room_id'];
    if ($nrid === $crid) {
        $_SESSION['error'] = 'Man kajalwachix ta pa ri ja kamik';
        header('Location: ?action=change&id=' . $id);
        exit;
    }

    $nri = array_search($nrid, array_column($r, 'id'));
    if ($nri === false || $r[$nri]['occ'] >= $r[$nri]['beds']) {
        $_SESSION['error'] = 'Ri ja man tolon ta';
        header('Location: ?action=change&id=' . $id);
        exit;
    }

    $cri = array_search($crid, array_column($r, 'id'));
    if ($cri !== false && $r[$cri]['occ'] > 0) $r[$cri]['occ']--;

    $oldRoomNum = $p[$pi]['room_num'] ?? ($cri !== false ? $r[$cri]['num'] : 'Maja k’o');
    $newRoomNum = $r[$nri]['num'];
    
    $oldDept = $cri !== false ? ($r[$cri]['dept'] ?? '') : ($p[$pi]['department'] ?? '');
    $newDept = $r[$nri]['dept'] ?? '';
    $oldDeptName = getDeptName($oldDept);
    $newDeptName = getDeptName($newDept);

    $photoMoveResult = movePatientPhotos($id, $oldRoomNum, $newRoomNum);

    $p[$pi]['room_id'] = $nrid;
    $p[$pi]['room_num'] = $newRoomNum;
    $r[$nri]['occ']++;
    if (empty($p[$pi]['timeline'])) {
        // older patient: seed the timeline from what we know before adding this move
        $p[$pi]['timeline'] = [['time' => $p[$pi]['admit_date'] ?? now(), 'type' => 'admit', 'title' => 'Xok',
                                'detail' => "Room $oldRoomNum ($oldDeptName)", 'by' => '']];
    }
    addTimelineEvent($p[$pi], 'move', "Xjalwachixik pa Ja $newRoomNum",
        "Pa Ja $oldRoomNum ($oldDeptName) pa Ja $newRoomNum ($newDeptName)");

    writeJSONFile($GLOBALS['pF'], $p);
    writeJSONFile($GLOBALS['rF'], $r);

    $gender = $p[$pi]['gender'] ?? 'prefer_not_to_say';
    $logMessage = "Xjalwachixik: {$p[$pi]['name']} ($id) [Achi/Ixoq: " . getGenderName($gender) . "] pa Ja {$oldRoomNum} ({$oldDeptName}) pa Ja {$newRoomNum} ({$newDeptName})";
    if ($photoMoveResult['moved'] > 0) {
        $logMessage .= " - Xjalwachixik {$photoMoveResult['moved']} wachib’al";
    }
    logMsg($logMessage);

    $_SESSION['success'] = "Ri yawab’ utz xjalwachix pa {$oldDeptName} pa {$newDeptName}";
    if ($photoMoveResult['moved'] > 0) {
        $_SESSION['success'] .= " rachi’ {$photoMoveResult['moved']} wachib’al xjalwachix";
    }
    
    if (isset($_GET['return']) && $_GET['return'] === 'view') {
        header('Location: ?action=view&id=' . $id);
    } else {
        header('Location: ?action=patients');
    }
    exit;
}

function showManage() {
    global $depts;
    $r = readJSONFile($GLOBALS['rF']);

    showHeader();
?>
    <div class="container">
        <h2>Chajinik Ja</h2>

        <div class="form-container" style="max-width:600px; margin-bottom:var(--spacing-xl);">
            <h3>Chatz’aqatisaj K’ak’ Ja</h3>
            <form method="POST" action="?action=manage">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

                <div class="form-grid">
                    <div class="form-group">
                        <label>Ajilab’al re Ja</label>
                        <input type="text" name="num" required>
                    </div>
                    <div class="form-group">
                        <label>Ja</label>
                        <select name="dept" required>
                            <option value="">Chacha’ K’olb’al</option>
                            <?php foreach ($depts as $k => $v): ?>
                                <option value="<?= $k ?>"><?= $v ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Ajilab’al Warab’al</label>
                        <input type="number" name="beds" min="1" max="20" required>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Chatz’aqatisaj Ja</button>
            </form>
        </div>

        <div class="card">
            <h3>Ja K’o</h3>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Ajilab’al re Ja</th>
                            <th>Ja</th>
                            <th>Ronoj Warab’al</th>
                            <th>K’o winaq</th>
                            <th>Tolon</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($r as $rm):
                            $ab = $rm['beds'] - $rm['occ'];
                        ?>
                            <tr>
                                <td><strong><?= htmlspecialchars($rm['num']) ?></strong></td>
                                <td><?= getDeptName($rm['dept']) ?></td>
                                <td><?= $rm['beds'] ?></td>
                                <td><?= $rm['occ'] ?></td>
                                <td><?= $ab ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php
    showFooter();
}

function addRoom() {
    $rn = trim($_POST['num'] ?? '');
    $d = $_POST['dept'] ?? '';
    $b = intval($_POST['beds'] ?? 0);

    if (!$rn || !$d || $b <= 0) {
        $_SESSION['error'] = 'Retal man utz ta';
        header('Location: ?action=manage');
        exit;
    }

    $r = readJSONFile($GLOBALS['rF']);
    foreach ($r as $rm) {
        if ($rm['num'] === $rn) {
            $_SESSION['error'] = 'Ri ja k’o chi';
            header('Location: ?action=manage');
            exit;
        }
    }

    $rid = count($r) > 0 ? max(array_column($r, 'id')) + 1 : 1;
    $r[] = ['id' => $rid, 'num' => $rn, 'dept' => $d, 'beds' => $b, 'occ' => 0];

    writeJSONFile($GLOBALS['rF'], $r);
    logMsg("Xtz’aqatisaxik ja: $rn (" . getDeptName($d) . ") rachi’ $b warab’al");
    $_SESSION['success'] = 'Ja xtz’aqatisax';
    header('Location: ?action=manage');
    exit;
}

function printSummary() {
    $id = $_GET['id'] ?? '';
    $discharged = $_GET['discharged'] ?? 0;
    $ad = $_GET['date'] ?? '';

    if (!$id) {
        showError('Maja k’o yawab’');
        return;
    }

    if ($discharged) {
        if (!canViewDischarged()) {
            showError('Xq’ataj ri b’ixikil');
            return;
        }
        
        $patient = null;
        if ($ad) {
            $patients = getDischargedPatients($ad);
            foreach ($patients as $pt) {
                if ($pt['id'] == $id) {
                    $patient = $pt;
                    break;
                }
            }
        } else {
            $allDischarged = getDischargedPatients();
            foreach ($allDischarged as $pt) {
                if ($pt['id'] == $id) {
                    $patient = $pt;
                    break;
                }
            }
        }
        
        if (!$patient) {
            showError('Man xriqitaj ta ri yawab’');
            return;
        }
    } else {
        $p = readJSONFile($GLOBALS['pF']);
        $pi = array_search($id, array_column($p, 'id'));
        if ($pi === false || $p[$pi]['status'] !== 'discharged') {
            showError('Maja kel');
            return;
        }
        $patient = $p[$pi];
    }

    $currentUser = $_SESSION['user'] ?? null;
    $userName = $currentUser['name'] ?? $currentUser['user'] ?? 'Okisanel Man Etaman Ta';
    $userRole = $currentUser['role'] ?? 'unknown';
    
    $roleDisplay = getRoleName($userRole);

    $photoCount = getPatientPhotoCount($id);
    $photos = getPatientPhotos($id);
?>
    <!DOCTYPE html>
    <html lang="quc">
    <head>
        <title>Ch’utitzijob’al Elib’al - <?= htmlspecialchars($patient['name']) ?></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
    body {
        font-family: 'Courier New', Courier, monospace;
        line-height: 1.2;
        max-width: 700px;
        margin: 15px auto;
        padding: 12px;
        background: white;
        color: black;
        font-size: 9px;
    }
    
    .header {
        text-align: center;
        margin-bottom: 8px;
        padding-bottom: 3px;
        border-bottom: 1px solid #999;
    }
    
    .hospital-name {
        font-size: 10px;
        font-weight: normal;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 1px;
        color: #333;
    }
    
    .hospital-info {
        font-size: 7px;
        color: #666;
        line-height: 1.2;
    }
    
    .document-title {
        font-size: 10px;
        font-weight: bold;
        text-transform: uppercase;
        margin: 5px 0 3px 0;
        text-align: center;
        color: #333;
        letter-spacing: 0.3px;
    }
    
    .section {
        margin: 8px 0;
    }
    
    .section-title {
        font-weight: bold;
        text-transform: uppercase;
        border-bottom: 1px solid #999;
        margin-bottom: 4px;
        padding-bottom: 1px;
        font-size: 9px;
        color: #333;
        letter-spacing: 0.2px;
    }
    
    .info-line {
        margin: 2px 0;
        font-family: 'Courier New', Courier, monospace;
        font-size: 9px;
    }
    
    .label {
        font-weight: bold;
        display: inline-block;
        min-width: 120px;
        color: #444;
        font-size: 9px;
    }
    
    .value {
        display: inline-block;
        color: #333;
        font-size: 9px;
    }
    
    .notice {
        font-style: italic;
        margin: 4px 0;
        padding: 2px 4px;
        border-left: 2px solid #ccc;
        font-size: 8px;
        color: #555;
        background-color: #f9f9f9;
    }
    
    .photo-list {
        margin: 4px 0;
        padding-left: 12px;
        font-size: 9px;
    }
    
    .photo-item {
        margin: 1px 0;
        font-family: 'Courier New', Courier, monospace;
        color: #555;
        font-size: 8px;
    }
    
    .signature-block {
        margin-top: 12px;
        padding-top: 6px;
        border-top: 1px solid #999;
        font-size: 9px;
    }
    
    .signature-line {
        margin: 4px 0;
        font-size: 9px;
    }
    
    .signature-name {
        border-bottom: 1px solid #666;
        min-width: 220px;
        display: inline-block;
        margin-right: 10px;
        color: #333;
        font-size: 9px;
    }
    
    .footer {
        margin-top: 10px;
        text-align: center;
        font-size: 6px;
        border-top: 1px solid #ddd;
        padding-top: 5px;
        color: #777;
        line-height: 1.2;
    }
    
    .action-bar {
        text-align: center;
        margin-top: 10px;
        font-size: 9px;
    }
    
    button {
        background: white;
        border: 1px solid #666;
        padding: 3px 12px;
        font-family: 'Courier New', Courier, monospace;
        font-size: 8px;
        cursor: pointer;
        margin: 0 3px;
        color: #333;
        border-radius: 3px;
    }
    
    button:hover {
        background: #f0f0f0;
        color: #333;
        border-color: #333;
    }
    
    hr {
        border: none;
        border-top: 1px dashed #ccc;
        margin: 6px 0;
    }
    
    .info-row {
        display: flex;
        flex-wrap: wrap;
        margin-bottom: 1px;
    }
    
    .info-row .label {
        min-width: 110px;
    }
    
    .info-row .value {
        flex: 1;
    }
    
    .section p, .section div:not(.section-title):not(.info-line) {
        margin: 2px 0;
        line-height: 1.2;
    }
    
    @media print {
        body {
            margin: 0.15in;
            padding: 0;
            font-size: 9px;
        }
        .action-bar {
            display: none;
        }
        .header {
            border-bottom-color: #000;
            margin-bottom: 6px;
        }
        .hospital-name {
            font-size: 10px;
        }
        .hospital-info {
            font-size: 7px;
        }
        .document-title {
            font-size: 10px;
            margin: 4px 0 2px 0;
        }
        .section {
            margin: 6px 0;
        }
        .signature-block {
            margin-top: 10px;
        }
    }
</style>
    </head>
    <body>
        <div class="header">
            <div class="hospital-name"><?= HOSPITAL_NAME ?></div>
            <div class="hospital-info"><?= HOSPITAL_ADDRESS ?> · <?= HOSPITAL_PHONE ?> · <?= HOSPITAL_WEBSITE ?></div>
        </div>
        
        <div class="document-title">CH’UTITZIJOB’AL ELIB’AL</div>
        
        <div class="notice">
            <span style="color: #666;">REF: DS-<?= date('Ymd') ?>-<?= substr($patient['id'], -4) ?></span> · 
            Xb’an: <?= date(DATE_DISPLAY) ?> · 
            Rumal: <?= htmlspecialchars($userName) ?> (<?= $roleDisplay ?>)
            <?php if ($discharged): ?> · <span style="color: #996633;">TZ’IB’ YAKOM</span><?php endif; ?>
        </div>

        <div class="section">
            <div class="section-title">RETAL YAWAB’</div>
            <div class="info-line"><span class="label">Ronoj B’i’aj:</span> <span class="value"><?= htmlspecialchars($patient['name']) ?></span></div>
            <div class="info-line"><span class="label">ID Yawab’:</span> <span class="value"><?= htmlspecialchars($patient['id']) ?></span></div>
            <div class="info-line"><span class="label">Junab’:</span> <span class="value"><?= $patient['age'] ?> junab’</span></div>
            <div class="info-line"><span class="label">Achi/Ixoq:</span> <span class="value"><?= getGenderName($patient['gender'] ?? 'prefer_not_to_say') ?></span></div>
            <div class="info-line"><span class="label">Ja:</span> <span class="value"><?= getDeptName($patient['department']) ?></span></div>
            <div class="info-line"><span class="label">Ajilab’al re Ja:</span> <span class="value"><?= htmlspecialchars($patient['room_num'] ?? '—') ?></span></div>
            <div class="info-line"><span class="label">Q’ij re Okib’al:</span> <span class="value"><?= isset($patient['admit_date']) ? formatDate($patient['admit_date']) : '' ?></span></div>
            <div class="info-line"><span class="label">Q’ij re Elik:</span> <span class="value"><?= isset($patient['discharge_date']) ? formatDate($patient['discharge_date']) : '' ?></span></div>
            <div class="info-line"><span class="label">Ramaj re Xok’isik:</span> <span class="value">
                <?php 
                if (isset($patient['admit_date']) && isset($patient['discharge_date'])) {
                    $admit = new DateTime($patient['admit_date']);
                    $discharge = new DateTime($patient['discharge_date']);
                    $days = $admit->diff($discharge)->days;
                    echo $days . ' q’ij';
                }
                ?>
            </span></div>
        </div>

        <div class="section">
            <div class="section-title">CH’UTITZIJOB’AL ELIB’AL</div>
            <div><?= nl2br(htmlspecialchars($patient['discharge']['summary'] ?? 'Maja k’o ch’utitzijob’al yo’om')) ?></div>
        </div>

        <?php if ($patient['discharge']['cond'] ?? ''): ?>
        <div class="section">
            <div class="section-title">WACHINEM ARE XEL</div>
            <div><?= htmlspecialchars($patient['discharge']['cond']) ?></div>
        </div>
        <?php endif; ?>

        <?php if ($patient['discharge']['follow'] ?? ''): ?>
        <div class="section">
            <div class="section-title">PIXAB’ RE TERENIK</div>
            <div><?= nl2br(htmlspecialchars($patient['discharge']['follow'])) ?></div>
        </div>
        <?php endif; ?>

        <?php if ($patient['discharge']['meds'] ?? ''): ?>
        <div class="section">
            <div class="section-title">KUNAB’AL RE ELIB’AL</div>
            <div><?= nl2br(htmlspecialchars($patient['discharge']['meds'])) ?></div>
        </div>
        <?php endif; ?>

        <?php if ($patient['discharge']['doctor_final_notes'] ?? ''): ?>
        <div class="section">
            <div class="section-title">RUK’ISB’AL TZ’IB’ AJKUN</div>
            <div><?= nl2br(htmlspecialchars($patient['discharge']['doctor_final_notes'])) ?></div>
        </div>
        <?php endif; ?>

        <?php if ($photoCount > 0): ?>
        <div class="section">
            <div class="section-title">WACHIB’AL YAWAB’ (<?= $photoCount ?>)</div>
            <div class="photo-list">
                <?php foreach ($photos as $index => $photo): ?>
                <div class="photo-item">
                    [<?= str_pad($index + 1, 2, '0', STR_PAD_LEFT) ?>] 
                    Wachib’al: <?= htmlspecialchars(basename($photo['url'])) ?> 
                    (Xjotesax: <?= isset($photo['uploaded']) ? date(DATE_DISPLAY, $photo['uploaded']) : 'Man etaman ta' ?>)
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <hr>

        <div class="signature-block">
            <div class="signature-line">
                <span class="label">Ajkun Chajinel:</span>
                <span class="signature-name"><?= htmlspecialchars($userName) ?></span>
                <span class="value">(<?= $roleDisplay ?>)</span>
            </div>
            
            <div class="signature-line">
                <span class="label">Yawab’/Chajinel:</span>
                <span class="signature-name"><?= htmlspecialchars($patient['name']) ?></span>
            </div>
            
            <div class="signature-line">
                <span class="label">Q’ij re Juch’:</span>
                <span class="signature-name"><?= date(DATE_SHORT) ?></span>
                <span class="value"><?= date(TIME_FORMAT) ?></span>
            </div>
        </div>

        <div class="footer">
            <?= HOSPITAL_NAME ?> · <?= HOSPITAL_ADDRESS ?> · Tel <?= HOSPITAL_PHONE ?><br>
            Wa’ jun qas tz’ib’ re kunanik · DS-<?= date('Ymd') ?>-<?= substr($patient['id'], -4) ?>
        </div>

        <div class="action-bar">
            <button onclick="window.print()">🖨️ CHATZ’IB’AJ</button>
            <button onclick="window.close()">CHATZ’APIJ</button>
        </div>
    </body>
    </html>
<?php
}

// ==================== PREDEFINED DISCHARGE MEDICATIONS ====================
// Stored in data/medications.json, managed on the "Medications" tab and
// selected from a dropdown on the Discharge Patient form.
function getMedications($activeOnly = false) {
    $file = MEDICATIONS_FILE;
    if (!dbKvGet('medications_seeded') && !readJSONFile($file)) {
        // First use: seed from the starter list in config.php
        $seed = [];
        foreach (($GLOBALS['standardMeds'] ?? []) as $cat => $meds) {
            foreach ($meds as $name => $strengths) {
                $seed[] = [
                    'id' => 'M' . bin2hex(random_bytes(4)),
                    'category' => $cat,
                    'name' => $name,
                    'strength' => $strengths[0] ?? '',
                    'dose' => '', 'frequency' => '', 'duration' => '', 'instructions' => '',
                    'active' => 1,
                ];
            }
        }
        writeJSONFile($file, $seed);
        dbKvSet('medications_seeded', date(DATE_FORMAT));
    }
    $list = readJSONFile($file);
    if ($activeOnly) {
        $list = array_values(array_filter($list, function ($m) { return !empty($m['active']); }));
    }
    usort($list, function ($a, $b) {
        return [$a['category'] ?? '', $a['name'] ?? ''] <=> [$b['category'] ?? '', $b['name'] ?? ''];
    });
    return $list;
}

function handleMedicationPost() {
    // Supported operations: add a new medicine, edit an existing one, delete one.
    $list = readJSONFile(MEDICATIONS_FILE);
    $id = $_POST['id'] ?? '';

    if (($_POST['op'] ?? '') === 'delete') {
        $found = false;
        foreach ($list as $i => $m) {
            if (($m['id'] ?? '') === $id && $id !== '') {
                logMsg("Kunab’al xesax: " . ($m['name'] ?? '') . " " . ($m['strength'] ?? ''));
                unset($list[$i]);
                $found = true;
                break;
            }
        }
        if ($found) {
            writeJSONFile(MEDICATIONS_FILE, array_values($list));
            $_SESSION['success'] = 'Kunab’al xesax';
        } else {
            $_SESSION['error'] = 'Kunab’al man xriqitaj ta';
        }
        header('Location: ?action=medications');
        exit;
    }
    $idx = false;
    if ($id !== '') {
        foreach ($list as $i => $m) { if (($m['id'] ?? '') === $id) { $idx = $i; break; } }
        if ($idx === false) {
            $_SESSION['error'] = 'Kunab’al man xriqitaj ta';
            header('Location: ?action=medications');
            exit;
        }
    }

    $name = rxClean($_POST['name'] ?? '');
    if ($name === '') {
        $_SESSION['error'] = 'Kunab’al: rajawaxik ub’i’';
        header('Location: ?action=medications&' . ($idx !== false ? 'edit=' . urlencode($id) : 'mode=new'));
        exit;
    }

    $entry = [
        'id'           => $idx !== false ? $id : 'M' . bin2hex(random_bytes(4)),
        'category'     => rxClean($_POST['category'] ?? '', 60) ?: 'Jun chik',
        'name'         => $name,
        'strength'     => rxClean($_POST['strength'] ?? '', 60),
        'dose'         => rxClean($_POST['dose'] ?? '', 80),
        'frequency'    => rxClean($_POST['frequency'] ?? '', 80),
        'duration'     => rxClean($_POST['duration'] ?? '', 60),
        'instructions' => rxClean($_POST['instructions'] ?? '', 300),
        'active'       => isset($_POST['active']) ? 1 : 0,
    ];

    if ($idx !== false) {
        $list[$idx] = $entry;
        logMsg("Kunab’al xk’ak’arisax: {$entry['name']} {$entry['strength']}");
        $_SESSION['success'] = 'Kunab’al xk’ak’arisax';
    } else {
        if (count($list) >= 500) {
            $_SESSION['error'] = 'Kunab’al: cholb’al nojinaq (500)';
            header('Location: ?action=medications');
            exit;
        }
        $list[] = $entry;
        logMsg("Kunab’al xtz’aqatisax: {$entry['name']} {$entry['strength']}");
        $_SESSION['success'] = 'Kunab’al xtz’aqatisax pa ri cholb’al re elib’al';
    }

    writeJSONFile(MEDICATIONS_FILE, array_values($list));
    header('Location: ?action=medications');
    exit;
}

function showMedications() {
    $list = getMedications(false);
    $edit = null;
    $isNew = (($_GET['mode'] ?? '') === 'new');

    if (!empty($_GET['edit'])) {
        foreach ($list as $m) { if ($m['id'] === $_GET['edit']) { $edit = $m; break; } }
        if (!$edit) {
            $_SESSION['error'] = 'Kunab’al man xriqitaj ta';
            header('Location: ?action=medications');
            exit;
        }
    }

    showHeader();
    if ($isNew || $edit) {
        renderMedicationForm($list, $edit);
    } else {
        renderMedicationList($list);
    }
    showFooter();
}

function renderMedicationList($list) {
?>
    <div class="container med-page">
        <div class="med-header">
            <h2>Kunab’al re Elib’al</h2>
            <a href="?action=medications&amp;mode=new" class="btn btn-primary"><i class="fas fa-plus"></i> K’ak’ kunab’al</a>
        </div>
        <p class="text-muted">Kunab’al chojinaq che ri wujkunab’al re elib’al. Ri ajkun kakicha’ pa ri cholb’al pa ri wuj Chesaj Yawab’. Echab’al, jarupa rachi’ ramaj xa taq na’ojib’al rachi’ kejalwachix chi kijujunal yawab’.</p>

        <div class="log-wrap med-wrap">
            <table class="log-table med-table">
                <thead>
                    <tr>
                        <th>Ruk’ojlem</th><th>Kunab’al</th><th>Uchuq’ab’</th><th>Echab’al</th>
                        <th>Jarupa</th><th>Ramaj</th><th>Pixab’</th><th>Pa ri cholb’al</th><th></th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!$list): ?>
                    <tr><td colspan="9" class="log-empty">Maja k’o kunab’al chojinaq.</td></tr>
                <?php else: foreach ($list as $m): ?>
                    <tr class="<?= empty($m['active']) ? 'med-off' : '' ?>">
                        <td><?= htmlspecialchars($m['category'] ?? '') ?></td>
                        <td class="log-user"><?= htmlspecialchars($m['name'] ?? '') ?></td>
                        <td><?= htmlspecialchars($m['strength'] ?? '') ?></td>
                        <td><?= htmlspecialchars($m['dose'] ?? '') ?></td>
                        <td><?= htmlspecialchars($m['frequency'] ?? '') ?></td>
                        <td><?= htmlspecialchars($m['duration'] ?? '') ?></td>
                        <td class="med-instr" title="<?= htmlspecialchars($m['instructions'] ?? '') ?>"><?= htmlspecialchars($m['instructions'] ?? '') ?></td>
                        <td><span class="log-badge <?= !empty($m['active']) ? 'log-admit' : 'log-other' ?>"><?= !empty($m['active']) ? 'Je’' : 'Ewam' ?></span></td>
                        <td class="med-actions">
                            <a href="?action=medications&amp;edit=<?= urlencode($m['id']) ?>" class="btn btn-sm">Chutzirisaj</a>
                            <form method="POST" action="?action=medications" style="display:inline;" onsubmit="return confirm('Chesaj <?= htmlspecialchars(addslashes(($m['name'] ?? '') . ' ' . ($m['strength'] ?? '')), ENT_QUOTES) ?> junelik?');">
                                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                                <input type="hidden" name="op" value="delete">
                                <input type="hidden" name="id" value="<?= htmlspecialchars($m['id']) ?>">
                                <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i> Chesaj</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
        <div class="med-footer">
            <div class="log-count"><?= count($list) ?> kunab’al</div>
            <a href="?action=dashboard" class="btn">&larr; Chatzalij</a>
        </div>
    </div>
<?php
}

function renderMedicationForm($list, $edit) {
    $cats = array_values(array_unique(array_filter(array_column($list, 'category'))));
    $freq = $GLOBALS['standardFrequencies'] ?? [];
    $dur  = $GLOBALS['standardDurations'] ?? [];
    $v = function ($k) use ($edit) { return htmlspecialchars($edit[$k] ?? ''); };
?>
    <div class="container med-page">
        <h2><?= $edit ? 'Chutzirisaj kunab’al' : 'K’ak’ kunab’al' ?></h2>

        <div class="card med-form">
            <form method="POST" action="?action=medications">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <?php if ($edit): ?><input type="hidden" name="id" value="<?= $v('id') ?>"><?php endif; ?>
                <div class="med-grid">
                    <div class="form-group med-span2"><label class="required" for="medName">Kunab’al</label>
                        <input type="text" id="medName" name="name" required maxlength="120" value="<?= $v('name') ?>" placeholder="jas Paracetamol"></div>
                    <div class="form-group"><label for="medCategory">Ruk’ojlem</label>
                        <input type="text" id="medCategory" name="category" list="medCats" maxlength="60" value="<?= $v('category') ?>" placeholder="jas Q’axomal &amp; k’atanal">
                        <datalist id="medCats"><?php foreach ($cats as $c): ?><option value="<?= htmlspecialchars($c) ?>"><?php endforeach; ?></datalist></div>
                    <div class="form-group"><label for="medStrength">Uchuq’ab’ / ruk’ojlem</label>
                        <input type="text" id="medStrength" name="strength" maxlength="60" value="<?= $v('strength') ?>" placeholder="e.g. 500 mg kunab’al"></div>
                    <div class="form-group"><label for="medDose">Junelik echab’al</label>
                        <input type="text" id="medDose" name="dose" maxlength="80" value="<?= $v('dose') ?>" placeholder="e.g. 1 kunab’al"></div>
                    <div class="form-group"><label for="medFrequency">Jarupa</label>
                        <input type="text" id="medFrequency" name="frequency" list="medFreq" maxlength="80" value="<?= $v('frequency') ?>" placeholder="e.g. 3 mul pa jun q’ij">
                        <datalist id="medFreq"><?php foreach ($freq as $f): ?><option value="<?= htmlspecialchars($f) ?>"><?php endforeach; ?></datalist></div>
                    <div class="form-group"><label for="medDuration">Ramaj</label>
                        <input type="text" id="medDuration" name="duration" list="medDur" maxlength="60" value="<?= $v('duration') ?>" placeholder="e.g. 7 q’ij">
                        <datalist id="medDur"><?php foreach ($dur as $d): ?><option value="<?= htmlspecialchars($d) ?>"><?php endforeach; ?></datalist></div>
                    <div class="form-group med-span2"><label for="medInstructions">Pixab’</label>
                        <input type="text" id="medInstructions" name="instructions" maxlength="300" value="<?= $v('instructions') ?>" placeholder="jas chatija rachi’ wa"></div>
                    <div class="form-group med-check"><label><input type="checkbox" name="active" value="1" <?= (!$edit || !empty($edit['active'])) ? 'checked' : '' ?>> Chak’utu’ pa ri cholb’al re elib’al</label></div>
                </div>
                <div class="med-buttons">
                    <button type="submit" class="btn btn-primary"><?= $edit ? 'Chayaka’ jalwachinik' : 'Chatz’aqatisaj kunab’al' ?></button>
                    <a href="?action=medications" class="btn">Chatanab’a</a>
                </div>
            </form>
            <?php if ($edit): ?>
            <form method="POST" action="?action=medications" style="margin-top:12px;" onsubmit="return confirm('Chesaj we kunab’al ri’ junelik?');">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <input type="hidden" name="op" value="delete">
                <input type="hidden" name="id" value="<?= $v('id') ?>">
                <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i> Chesaj kunab’al</button>
            </form>
            <?php endif; ?>
        </div>
    </div>
<?php
}

function parseLogLine($line) {
    $line = trim($line);
    $e = ['time' => '', 'user' => '', 'ip' => '', 'msg' => $line, 'type' => 'other'];
    if (preg_match('/^\[([^\]]*)\]\s*\[([^\]@]*)@?([^\]]*)\]\s*(.*)$/s', $line, $m)) {
        $e['time'] = $m[1]; $e['user'] = $m[2]; $e['ip'] = $m[3]; $e['msg'] = $m[4];
    }
    $e['type'] = logType($e['msg']);
    return $e;
}

function showLogs() {
    $limit = defined('LOG_VIEW_LIMIT') ? (int)LOG_VIEW_LIMIT : 5000;
    $entries = getActivityLog($limit);
    $totalEntries = countActivityLog();
    $labels = [
        'admit' => 'Xok', 'discharge' => 'Xel', 'rx' => 'Wujkunab’al', 'login' => 'Okib’al/Elib’al',
        'move' => 'Xjalwachixik', 'edit' => 'Xk’ak’arisaxik', 'photo' => 'Wachib’al', 'system' => 'Ucholajil', 'admin' => 'Ajchak’',
        'alert' => 'Pixab’', 'other' => 'Jun chik',
    ];
    $counts = [];
    foreach ($entries as $e) $counts[$e['type']] = ($counts[$e['type']] ?? 0) + 1;

    showHeader();
?>
    <div class="container log-page">
        <h2>Tz’ib’ Ucholajil</h2>

        <div class="log-toolbar">
            <input type="search" id="logSearch" class="log-search" placeholder="Chatzukuj okisanel, yawab’, IP o tz’ib’..." autocomplete="off">
            <div class="log-filters" id="logFilters">
                <button type="button" class="log-chip active" data-type="all">Ronoj <span><?= count($entries) ?></span></button>
                <?php foreach ($labels as $k => $lab): if (empty($counts[$k])) continue; ?>
                    <button type="button" class="log-chip log-<?= $k ?>" data-type="<?= $k ?>"><?= $lab ?> <span><?= $counts[$k] ?></span></button>
                <?php endforeach; ?>
            </div>
            <div class="log-count"><span id="logShown"><?= count($entries) ?></span> re <?= count($entries) ?> tz’ib’<?= $totalEntries > count($entries) ? ' (k’ak’ ' . count($entries) . ' re ' . $totalEntries . ' pa activity_log)' : '' ?></div>
        </div>

        <div class="log-wrap">
            <table class="log-table">
                <thead>
                    <tr><th>Q’ij</th><th>Ramaj</th><th>Ruk’ojlem</th><th>Okisanel</th><th>Rutzijoxik</th><th>IP</th></tr>
                </thead>
                <tbody id="logBody">
                <?php if (empty($entries)): ?>
                    <tr><td colspan="6" class="log-empty">Maja k’o tz’ib’ xriqitaj.</td></tr>
                <?php else: foreach ($entries as $e):
                    $ts = strtotime($e['time']);
                    $d = $ts ? date('Y-m-d', $ts) : htmlspecialchars($e['time']);
                    $t = $ts ? date('H:i:s', $ts) : '';
                    $hay = strtolower($e['time'] . ' ' . $e['user'] . ' ' . $e['ip'] . ' ' . $e['msg']);
                ?>
                    <tr data-type="<?= htmlspecialchars($e['type']) ?>" data-hay="<?= htmlspecialchars($hay) ?>">
                        <td class="log-date"><?= $d ?></td>
                        <td class="log-time"><?= $t ?></td>
                        <td><span class="log-badge log-<?= htmlspecialchars($e['type']) ?>"><?= $labels[$e['type']] ?? 'Jun chik' ?></span></td>
                        <td class="log-user"><?= htmlspecialchars($e['user']) ?></td>
                        <td class="log-msg"><?= htmlspecialchars($e['msg']) ?></td>
                        <td class="log-ip"><?= htmlspecialchars($e['ip']) ?></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
            <div class="log-empty" id="logNone" style="display:none;">Maja k’o tz’ib’ junam rik’in ri ach’ayb’al.</div>
        </div>

        <a href="?action=dashboard" class="btn" style="margin-top:20px;">&larr; Chatzalij</a>
    </div>
    <script>
    (function () {
        var rows = document.querySelectorAll('#logBody tr[data-type]');
        var search = document.getElementById('logSearch');
        var chips = document.querySelectorAll('#logFilters .log-chip');
        var type = 'all';
        function apply() {
            var q = search.value.trim().toLowerCase(), n = 0;
            rows.forEach(function (r) {
                var ok = (type === 'all' || r.dataset.type === type) && (!q || r.dataset.hay.indexOf(q) !== -1);
                r.style.display = ok ? '' : 'none';
                if (ok) n++;
            });
            document.getElementById('logShown').textContent = n;
            document.getElementById('logNone').style.display = (n === 0 && rows.length) ? 'block' : 'none';
        }
        chips.forEach(function (c) {
            c.onclick = function () {
                chips.forEach(function (x) { x.classList.remove('active'); });
                c.classList.add('active'); type = c.dataset.type; apply();
            };
        });
        search.oninput = apply;
    })();
    </script>
<?php
    showFooter();
}

function showTelephone() {
    if (!can('telephone')) {
        showError('Xq’ataj ri b’ixikil');
        exit;
    }

    $ph = readJSONFile($GLOBALS['tF']);
    $r = readJSONFile($GLOBALS['rF']);
    $rm = [];
    foreach ($r as $room) {
        $rm[$room['id']] = $room['num'];
    }

    $s = $_SESSION['tel_search'] ?? '';
    $fp = $ph;

    if ($s) {
        $fp = array_filter($ph, function ($p) use ($s, $rm) {
            return stripos($p['number'], $s) !== false ||
                stripos($p['ext'], $s) !== false ||
                stripos($p['purpose'], $s) !== false ||
                stripos($p['notes'], $s) !== false ||
                stripos($rm[$p['room_id']] ?? '', $s) !== false;
        });
    }

    showHeader();
?>
    <div class="container">
        <div class="card">
            <h2>Ub’i’ Ch’awib’al</h2>

            <div class="grid grid-3" style="margin-bottom:var(--spacing-lg);">
                <div class="card">
                    <div class="card-label">Ronoj Ajilab’al</div>
                    <div class="card-stats"><?= count($ph) ?></div>
                </div>
                <div class="card">
                    <div class="card-label">Ja rachi’ Ch’awib’al</div>
                    <div class="card-stats"><?= count(array_unique(array_column($ph, 'room_id'))) ?></div>
                </div>
                <div class="card">
                    <div class="card-label">Kak’ut</div>
                    <div class="card-stats"><?= count($fp) ?></div>
                </div>
            </div>

            <div class="filter-bar" style="margin-bottom:var(--spacing-lg);">
                <form method="POST" style="flex:1; display:flex; gap:10px;">
                    <div class="search-box" style="flex:1;">
                        <input type="text" name="search_query" placeholder="Chatzukuj rumal ajilab’al, ajilab’al pa uwi’, uchak, ja..." value="<?= htmlspecialchars($s) ?>">
                    </div>
                    <button type="submit" name="search_telephone" class="btn btn-primary">Chatzukuj</button>
                </form>
                <?php if ($s): ?>
                    <a href="?action=telephone&clear_tel_search=1" class="btn" style="background:var(--text-muted); color:var(--text-inverse);">Chesaj</a>
                <?php endif; ?>
                <a href="?action=add_tel" class="btn btn-success">➕ Chatz’aqatisaj Ajilab’al</a>
            </div>

            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Ja</th>
                            <th>Ajilab’al</th>
                            <th>Ajilab’al Pa Uwi’</th>
                            <th>Uchak</th>
                            <th>Tz’ib’</th>
                            <th>Chak</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($fp as $p): ?>
                            <tr>
                                <td><?= $p['id'] ?></td>
                                <td>Ja <?= htmlspecialchars($rm[$p['room_id']] ?? $p['room_id']) ?></td>
                                <td><strong><?= htmlspecialchars($p['number']) ?></strong></td>
                                <td><?= htmlspecialchars($p['ext']) ?></td>
                                <td><?= htmlspecialchars($p['purpose']) ?></td>
                                <td><?= htmlspecialchars($p['notes']) ?></td>
                                <td>
                                    <div class="btn-group">
                                        <a href="?action=edit_tel&id=<?= $p['id'] ?>" class="btn btn-sm">Chutzirisaj</a>
                                        <form method="POST" style="display:inline;">
                                            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                                            <input type="hidden" name="delete_telephone" value="1">
                                            <input type="hidden" name="id" value="<?= $p['id'] ?>">
                                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('La qastzij kawaj kesaj we ajilab’al ch’awib’al ri’?')">Chesaj</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($fp)): ?>
                            <tr>
                                <td colspan="7" style="text-align:center; padding:var(--spacing-xl);">
                                    Maja k’o ajilab’al ch’awib’al xriqitaj.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <a href="?action=dashboard" class="btn" style="background:var(--text-muted); color:var(--text-inverse); margin-top:var(--spacing-lg);">Chatzalij</a>
        </div>
    </div>
<?php
    showFooter();
}

function showAddTelForm() {
    if (!can('telephone')) {
        showError('Xq’ataj ri b’ixikil');
        exit;
    }
    $r = readJSONFile($GLOBALS['rF']);

    showHeader();
?>
    <div class="container">
        <div class="form-container">
            <h2>Chatz’aqatisaj Ajilab’al Ch’awib’al</h2>
            <form method="POST" action="?action=add_tel">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

                <div class="form-group">
                    <label class="required">Ja</label>
                    <select name="room_id" required>
                        <option value="">Chacha’ Ja</option>
                        <?php foreach ($r as $rm): ?>
                            <option value="<?= $rm['id'] ?>">Ja <?= htmlspecialchars($rm['num']) ?> (<?= getDeptName($rm['dept']) ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="required">Ajilab’al Ch’awib’al</label>
                    <input type="text" name="number" required placeholder="jas +1-555-123-4567">
                </div>

                <div class="form-group">
                    <label>Ajilab’al Pa Uwi’</label>
                    <input type="text" name="ext" placeholder="jas 123">
                </div>

                <div class="form-group">
                    <label>Uchak</label>
                    <input type="text" name="purpose" placeholder="jas K’olb’al Ajchajinel">
                </div>

                <div class="form-group">
                    <label>Tz’ib’</label>
                    <textarea name="notes" rows="3"></textarea>
                </div>

                <div style="display:flex;gap:15px;">
                    <button type="submit" name="add_telephone" class="btn btn-primary">Chatz’aqatisaj Ajilab’al</button>
                    <a href="?action=telephone" class="btn" style="background:var(--text-muted); color:var(--text-inverse);">Chatanab’a</a>
                </div>
            </form>
        </div>
    </div>
<?php
    showFooter();
}

function showEditTelForm() {
    if (!can('telephone')) {
        showError('Xq’ataj ri b’ixikil');
        exit;
    }

    $id = intval($_GET['id'] ?? 0);
    if (!$id) {
        header('Location: ?action=telephone');
        exit;
    }

    $ph = readJSONFile($GLOBALS['tF']);
    $p = null;
    foreach ($ph as $phn) {
        if ($phn['id'] == $id) {
            $p = $phn;
            break;
        }
    }

    if (!$p) {
        header('Location: ?action=telephone');
        exit;
    }

    showHeader();
?>
    <div class="container">
        <div class="form-container">
            <h2>Chutzirisaj Ajilab’al Ch’awib’al</h2>

            <div class="patient-info">
                <strong>Ja:</strong> Ja <?= htmlspecialchars($p['room_num']) ?>
            </div>

            <form method="POST" action="?action=edit_tel">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <input type="hidden" name="id" value="<?= $id ?>">

                <div class="form-group">
                    <label class="required">Ajilab’al Ch’awib’al</label>
                    <input type="text" name="number" value="<?= htmlspecialchars($p['number']) ?>" required>
                </div>

                <div class="form-group">
                    <label>Ajilab’al Pa Uwi’</label>
                    <input type="text" name="ext" value="<?= htmlspecialchars($p['ext']) ?>">
                </div>

                <div class="form-group">
                    <label>Uchak</label>
                    <input type="text" name="purpose" value="<?= htmlspecialchars($p['purpose']) ?>">
                </div>

                <div class="form-group">
                    <label>Tz’ib’</label>
                    <textarea name="notes" rows="3"><?= htmlspecialchars($p['notes']) ?></textarea>
                </div>

                <div style="display:flex;gap:15px;">
                    <button type="submit" name="edit_telephone" class="btn btn-primary">Chak’ak’arisaj</button>
                    <a href="?action=telephone" class="btn" style="background:var(--text-muted); color:var(--text-inverse);">Chatanab’a</a>
                </div>
            </form>
        </div>
    </div>
<?php
    showFooter();
}

// ==================== LOGIN BUSYNESS INDICATOR ====================
// Shows how busy the hospital is right now on the login screen.
// Only aggregated numbers are used (no names, IDs or other patient data),
// because this is visible before anyone has logged in.
// Set define('LOGIN_SHOW_BUSYNESS', false); in config.php to switch it off.
function getLoginBusyness() {
    $patients = readJSONFile($GLOBALS['pF']);
    $rooms = readJSONFile($GLOBALS['rF']);

    $admitted = 0;
    if (is_array($patients)) {
        foreach ($patients as $pt) {
            if (is_array($pt) && ($pt['status'] ?? '') === 'admitted') $admitted++;
        }
    }

    $beds = 0;
    $occ = 0;
    if (is_array($rooms)) {
        foreach ($rooms as $rm) {
            if (!is_array($rm)) continue;
            $beds += (int)($rm['beds'] ?? 0);
            $occ += (int)($rm['occ'] ?? 0);
        }
    }

    $pct = $beds > 0 ? (int)round(min($occ, $beds) / $beds * 100) : 0;

    if ($pct >= 95)     { $level = 'very-busy'; $label = 'Sib’alaj k’i chak'; }
    elseif ($pct >= 80) { $level = 'busy';      $label = 'K’i chak'; }
    elseif ($pct >= 50) { $level = 'normal';    $label = 'Junam'; }
    else                { $level = 'quiet';     $label = 'Ch’uch’ujil'; }

    return [
        'patients' => $admitted,
        'beds'     => $beds,
        'occupied' => $occ,
        'free'     => max(0, $beds - $occ),
        'percent'  => $pct,
        'level'    => $level,
        'label'    => $label,
    ];
}

function showLogin() {
    $e = $_SESSION['error'] ?? '';
    unset($_SESSION['error']);
    $busy = (SOFTTOKEN_ONLY && (!defined('LOGIN_SHOW_BUSYNESS') || LOGIN_SHOW_BUSYNESS)) ? getLoginBusyness() : null;
?>
    <!DOCTYPE html>
    <html lang="quc">
    <head>
        <title><?= HOSPITAL_NAME ?> - Login</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <link rel="stylesheet" href="hospital.css">
        <link rel="stylesheet" href="style.css">
        <style>
            .login-wrap { max-width: 420px; margin: 8vh auto 0; }
            .login-wrap .app-container { padding: 0 0 22px; }
            .login-wrap .header { margin: 0 0 18px; border-radius: 5px 5px 0 0; justify-content: center; }
            .login-body { padding: 0 24px; }
            .login-body .form-group { margin-bottom: 14px; }
            .login-body .btn { width: 100%; justify-content: center; }
            .login-body .error { background: var(--danger-bg); border: 1px solid var(--border); border-left: 4px solid var(--navy);
                padding: 8px 12px; margin-bottom: 14px; border-radius: var(--radius); font-weight: 600; }
            .busy-box { margin-bottom: 16px; padding: 10px 12px; background: #000; color: #fff; border: 1px solid #000; border-radius: var(--radius); }
            .busy-head { display: flex; justify-content: space-between; align-items: center; gap: 10px; font-size: 13px; margin-bottom: 8px; }
            .busy-title { text-transform: uppercase; letter-spacing: .5px; font-weight: 600; color: #fff; font-size: 11px; }
            .busy-title i { color: #fff; }
            .busy-badge { font-weight: 700; padding: 2px 10px; border-radius: 999px; border: 1px solid #fff; color: #fff; font-size: 12px; }
            .busy-bar { height: 8px; background: #555; border-radius: 999px; overflow: hidden; }
            .busy-fill { height: 100%; border-radius: 999px; background: #fff; }
            .busy-meta { display: flex; justify-content: space-between; margin-top: 8px; font-size: 12px; color: #ccc; }
            .busy-meta strong { color: #fff; }
            .login-body .demo, .login-body .note { margin-top: 16px; padding: 10px 12px; font-size: 12px; color: var(--muted);
                background: var(--surface-alt); border: 1px solid var(--border-soft); border-radius: var(--radius); }
        </style>
    </head>
    <body>
        <div class="login-wrap">
          <div class="app-container">
            <div class="header">
                <div>
                    <h1>
                        <?php if (file_exists(HOSPITAL_LOGO)): ?><img src="<?= HOSPITAL_LOGO ?>" class="header-logo" alt=""><?php endif; ?>
                        <?= HOSPITAL_NAME ?> <small>Login</small>
                    </h1>
                </div>
            </div>
            <div class="login-body">
                <?php if ($e): ?>
                    <div class="error"><?= htmlspecialchars($e) ?></div>
                <?php endif; ?>

                <?php if ($busy): ?>
                <div class="busy-box busy-<?= $busy['level'] ?>">
                    <div class="busy-head">
                        <span class="busy-title"><i class="fas fa-procedures"></i>&nbsp;Yawab’ kamik</span>
                        <span class="busy-badge"><?= $busy['label'] ?></span>
                    </div>
                    <div class="busy-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="<?= $busy['percent'] ?>" aria-label="Okinaq warab’al">
                        <div class="busy-fill" style="width:<?= $busy['percent'] ?>%;"></div>
                    </div>
                    <div class="busy-meta">
                        <span><strong><?= $busy['patients'] ?></strong> yawab’ xok</span>
                        <span><strong><?= $busy['occupied'] ?>/<?= $busy['beds'] ?></strong> warab’al &middot; <?= $busy['percent'] ?>%</span>
                        <span><strong><?= $busy['free'] ?></strong> tolon</span>
                    </div>
                </div>
                <?php endif; ?>

                <form method="POST" action="">
                    <input type="hidden" name="login" value="1">
                    <?php if (SOFTTOKEN_ONLY): ?>
                    <div class="form-group">
                        <label>6-ajilab’al kod pa ri aplicacion re qatzijinik</label>
                        <input type="text" name="code" class="mfa-code" maxlength="6" pattern="\d{6}" inputmode="numeric" autocomplete="one-time-code" placeholder="123456" required autofocus style="width:100%;box-sizing:border-box;font-size:2rem;letter-spacing:10px;text-align:center;padding:10px 6px;">
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-sign-in-alt"></i>&nbsp;Login</button>
                    <script>
                    (function () {
                        var input = document.querySelector('.mfa-code'), form = input.form, sent = false;
                        input.addEventListener('input', function () {
                            input.value = input.value.replace(/\D/g, '').slice(0, 6);
                            if (input.value.length === 6 && !sent) { sent = true; input.readOnly = true; form.submit(); }
                        });
                        window.addEventListener('pageshow', function (e) {
                            if (e.persisted) { sent = false; input.readOnly = false; input.value = ''; input.focus(); }
                        });
                    })();
                    </script>
                    <?php else: ?>
                    <div class="form-group">
                        <label>Ub’i’ Okisanel</label>
                        <input type="text" name="username" required autofocus>
                    </div>
                    <div class="form-group">
                        <label>Ewal tzij</label>
                        <input type="password" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-sign-in-alt"></i>&nbsp;Login</button>
                    <?php endif; ?>
                </form>
            </div>
          </div>
        </div>
    </body>
    </html>
<?php
    exit;
}

function showMFAPrompt() {
    $e = $_SESSION['error'] ?? '';
    unset($_SESSION['error']);
    $user = $_SESSION['temp_user']['name'] ?? ($_SESSION['temp_user']['user'] ?? 'Okisanel');
?>
    <!DOCTYPE html>
    <html lang="quc">
    <head>
        <title><?= HOSPITAL_NAME ?> - Kaib’ Qatzijinik</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <link rel="stylesheet" href="hospital.css">
        <link rel="stylesheet" href="style.css">
        <style>
            .login-wrap { max-width: 420px; margin: 8vh auto 0; }
            .login-wrap .app-container { padding: 0 0 22px; }
            .login-wrap .header { margin: 0 0 18px; border-radius: 5px 5px 0 0; justify-content: center; }
            .login-body { padding: 0 24px; }
            .login-body h2 { margin: 0 0 8px; font-size: 1.1rem; text-transform: uppercase; letter-spacing: .5px; }
            .login-body p { margin: 0 0 10px; }
            .login-body .form-group { margin-bottom: 14px; }
            .login-body .btn { width: 100%; justify-content: center; box-sizing: border-box; }
            .login-body .error { background: var(--danger-bg); border: 1px solid var(--border); border-left: 4px solid var(--navy);
                padding: 8px 12px; margin-bottom: 14px; border-radius: var(--radius); font-weight: 600; }
            .login-body .mfa-code { width: 100%; box-sizing: border-box; font-size: 2rem; letter-spacing: 10px; text-align: center; padding: 10px 6px; }
            .login-body .back-link { display: block; text-align: center; margin-top: 14px; font-size: 13px; color: var(--muted); }
        </style>
    </head>
    <body>
        <div class="login-wrap">
          <div class="app-container">
            <div class="header">
                <div>
                    <h1>
                        <?php if (file_exists(HOSPITAL_LOGO)): ?><img src="<?= HOSPITAL_LOGO ?>" class="header-logo" alt=""><?php endif; ?>
                        <?= HOSPITAL_NAME ?> <small>Kaib’ Qatzijinik</small>
                    </h1>
                </div>
            </div>
            <div class="login-body">
                <p>Saqarik, <strong><?= htmlspecialchars($user) ?></strong></p>
                <p>Chaya 6-ajilab’al kod pa ri aplicacion re qatzijinik:</p>
                <?php if ($e): ?>
                    <div class="error"><?= htmlspecialchars($e) ?></div>
                <?php endif; ?>
                <form method="POST" action="">
                    <input type="hidden" name="mfa_verify" value="1">
                    <div class="form-group">
                        <input type="text" name="code" class="mfa-code" maxlength="6" pattern="\d{6}" inputmode="numeric" autocomplete="one-time-code" placeholder="123456" required autofocus>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-shield-alt"></i>&nbsp;Chaqatzij</button>
                </form>
                <script>
                // Auto-login: submit as soon as the 6th digit is entered (no Enter / Verify click needed)
                (function () {
                    var input = document.querySelector('.mfa-code');
                    var form = input.form;
                    var sent = false;
                    input.addEventListener('input', function () {
                        input.value = input.value.replace(/\D/g, '').slice(0, 6);
                        if (input.value.length === 6 && !sent) {
                            sent = true;
                            input.readOnly = true;
                            form.submit();
                        }
                    });
                    // Back button / bfcache: allow typing again
                    window.addEventListener('pageshow', function (e) {
                        if (e.persisted) { sent = false; input.readOnly = false; input.value = ''; input.focus(); }
                    });
                })();
                </script>
                <a href="?cancel_mfa=1" class="back-link">&larr; Chatzalij pa login</a>
            </div>
          </div>
        </div>
    </body>
    </html>
<?php
    exit;
}

function showMFASetup() {
    if (!isset($_SESSION['user']) || !isset($_SESSION['setup_secret'])) {
        header('Location: ?action=security');
        exit;
    }
    $s = $_SESSION['setup_secret'];

    showHeader();
?>
    <div class="container">
        <div class="form-container">
            <h2>Chab’ana’ Kaib’ Qatzijinik</h2>

            <div class="card" style="text-align:center;">
                <p>Chatzukuj we kod QR rik’in ri aplicacion re qatzijinik:</p>
                <?php $qr = "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=" . urlencode("otpauth://totp/" . MFA_ISSUER . ":" . $_SESSION['user']['user'] . "?secret=$s&issuer=" . MFA_ISSUER); ?>
                <img src="<?= htmlspecialchars($qr) ?>" alt="QR Kod" style="border:1px solid var(--border-color); border-radius:var(--border-radius); margin:var(--spacing-md) 0;">
            </div>

            <div class="card" style="text-align:center;">
                <p>O chaya we lawe ri’ rik’in aq’ab’:</p>
                <div style="background:var(--bg-tertiary); border:1px solid var(--border-color); padding:var(--spacing-md); font-family:monospace; letter-spacing:2px; border-radius:var(--border-radius);">
                    <?= htmlspecialchars($s) ?>
                </div>
            </div>

            <div class="card">
                <p>Chaqatzij ri kod pa ri aplicacion:</p>
                <form method="POST" action="">
                    <input type="hidden" name="verify_setup" value="1">
                    <div class="form-group">
                        <input type="text" name="code" maxlength="6" pattern="\d{6}" placeholder="000000" required style="font-size:2rem; letter-spacing:10px; text-align:center;">
                    </div>
                    <div style="display:flex;gap:15px;">
                        <button type="submit" class="btn btn-primary">Chachaplej MFA</button>
                        <a href="?action=security" class="btn" style="background:var(--text-muted); color:var(--text-inverse);">Chatanab’a</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php
    showFooter();
}

function showSecurity() {
    if (!isset($_SESSION['user'])) {
        header('Location: ./');
        exit;
    }
    $u = $_SESSION['user'];
    $m = $u['mfa'] ?? 0;

    showHeader();
?>
    <div class="container">
        <div class="form-container">
            <h2>Ub’antajik Chajinik</h2>

            <div class="card" style="background:var(--bg-secondary);">
                <h3>Kaib’ Qatzijinik</h3>
                <p>Wachinem: <strong><?= $m ? 'Xchaplex' : 'Xchuplix' ?></strong></p>
                <p><?= $m ? 'Ri okisab’al chajim rumal MFA' : 'Chatz’aqatisaj jun chik chajinik pa ri okisab’al' ?>.</p>
            </div>

            <form method="POST" action="">
                <input type="hidden" name="mfa_action" value="1">
                <?php if (!$m): ?>
                    <input type="hidden" name="action" value="enable">
                    <button type="submit" class="btn btn-primary">Chachaplej MFA</button>
                <?php else: ?>
                    <input type="hidden" name="action" value="disable">
                    <button type="submit" class="btn btn-danger">Chachuplij MFA</button>
                <?php endif; ?>
            </form>

            <a href="?action=dashboard" class="btn" style="background:var(--text-muted); color:var(--text-inverse); margin-top:var(--spacing-md);">Chatzalij</a>
        </div>
    </div>
<?php
    showFooter();
}

function showMFAAdmin() {
    if (!can('mfa_admin')) {
        showError('Xq’ataj ri b’ixikil');
        exit;
    }
    $users = readJSONFile($GLOBALS['uF']);
    $msg = $_SESSION['admin_message'] ?? '';
    unset($_SESSION['admin_message']);

    showHeader();
?>
    <div class="container">
        <div class="card">
            <h2>📱 MFA Ajchak’il</h2>
            <?php if ($msg): ?>
                <div class="alert alert-success"><?= htmlspecialchars($msg) ?></div>
            <?php endif; ?>

            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Ub’i’ Okisanel</th>
                            <th>Chak</th>
                            <th>MFA Wachinem</th>
                            <th>Chak</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $u): ?>
                            <tr>
                                <td><?= htmlspecialchars($u['user']) ?></td>
                                <td><?= getRoleName($u['role']) ?></td>
                                <td>
                                    <span class="status-badge <?= $u['mfa'] ? 'status-admitted' : 'status-discharged' ?>">
                                        <?= $u['mfa'] ? 'Xchaplex' : 'Xchuplix' ?>
                                    </span>
                                </td>
                                <td>
                                    <form method="POST" class="form-inline">
                                        <input type="hidden" name="admin_mfa_action" value="1">
                                        <input type="hidden" name="target_user" value="<?= htmlspecialchars($u['user']) ?>">
                                        <div class="btn-group">
                                            <select name="admin_action" style="min-width:150px; padding:var(--spacing-xs);">
                                                <option value="">Chacha’ Chak</option>
                                                <option value="enable">Chachaplej MFA</option>
                                                <option value="disable">Chachuplij MFA</option>
                                                <option value="reset_secret">Chajalwachij ri ewal</option>
                                                <option value="view_secret">Chawila ri ewal</option>
                                            </select>
                                            <button type="submit" class="btn btn-sm">Chab’ana’</button>
                                        </div>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div style="margin-top:var(--spacing-xl);">
                <a href="?action=dashboard" class="btn" style="background:var(--text-muted); color:var(--text-inverse);">Chatzalij</a>
                <a href="?action=user_manage" class="btn btn-primary">Chajinik Okisanelab’</a>
            </div>
        </div>
    </div>
<?php
    showFooter();
}

function showUserManage() {
    if (!can('user_admin')) {
        showError('Xq’ataj ri b’ixikil');
        exit;
    }
    global $roles;
    $users = readJSONFile($GLOBALS['uF']);
    $msg = $_SESSION['admin_message'] ?? '';
    unset($_SESSION['admin_message']);
    $e = $_SESSION['error'] ?? '';
    unset($_SESSION['error']);

    showHeader();
?>
    <div class="container">
        <div class="card">
            <h2>👥 Chajinik Okisanelab’</h2>

            <?php if ($msg): ?>
                <div class="alert alert-success"><?= htmlspecialchars($msg) ?></div>
            <?php endif; ?>
            <?php if ($e): ?>
                <div class="alert alert-error"><?= htmlspecialchars($e) ?></div>
            <?php endif; ?>

            <div class="grid grid-2">
                <div>
                    <div class="card">
                        <h3>Chatz’aqatisaj K’ak’ Okisanel</h3>
                        <form method="POST" action="">
                            <input type="hidden" name="add_new_user" value="1">

                            <div class="form-group">
                                <label>Ub’i’ Okisanel:</label>
                                <input type="text" name="new_username" required>
                            </div>

                            <div class="form-group">
                                <label>Ronoj B’i’aj:</label>
                                <input type="text" name="new_name">
                            </div>

                            <div class="form-group">
                                <label>Correo:</label>
                                <input type="email" name="new_email">
                            </div>

                            <div class="form-group">
                                <label>Ewal tzij (xa ch’uti 8 tz’ib’, nim, ch’uti, ajilab’al, jun wi’):</label>
                                <input type="text" name="new_password" required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9]).{8,}" title="Rajawaxik k’o 8 tz’ib’, jun nim tz’ib’, jun ch’uti tz’ib’, jun ajilab’al rachi’ jun wi’ retal">
                            </div>

                            <div class="form-group">
                                <label>Chak:</label>
                                <select name="new_role" required>
                                    <option value="">Chacha’ Chak</option>
                                    <?php foreach ($roles as $k => $v): ?>
                                        <option value="<?= $k ?>"><?= $v['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div style="display:flex; align-items:center; gap:10px; margin:10px 0;">
                                <input type="checkbox" name="new_mfa" id="new_mfa">
                                <label for="new_mfa" style="margin-bottom:0;">Chachaplej MFA che we okisanel ri’</label>
                            </div>

                            <button type="submit" class="btn btn-primary">Chab’ana’ Okisanel</button>
                        </form>
                    </div>

                    <div class="card" style="margin-top:var(--spacing-xl);">
                        <h3>Chajalwachij Ewal tzij</h3>
                        <form method="POST" action="">
                            <input type="hidden" name="reset_user_password" value="1">

                            <div class="form-group">
                                <label>Chacha’ Okisanel:</label>
                                <select name="target_user" required>
                                    <option value="">Chacha’ Okisanel</option>
                                    <?php foreach ($users as $u): ?>
                                        <option value="<?= htmlspecialchars($u['user']) ?>"><?= htmlspecialchars($u['user']) ?> (<?= getRoleName($u['role']) ?>)</option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label>K’ak’ Ewal tzij (xa ch’uti 8 tz’ib’, nim, ch’uti, ajilab’al, jun wi’):</label>
                                <input type="text" name="new_password" required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9]).{8,}" title="Rajawaxik k’o 8 tz’ib’, jun nim tz’ib’, jun ch’uti tz’ib’, jun ajilab’al rachi’ jun wi’ retal">
                            </div>

                            <button type="submit" class="btn btn-danger">Chajalwachij Ewal tzij</button>
                        </form>
                    </div>
                </div>

                <div>
                    <div class="card">
                        <h3>Ronoj Okisanelab’</h3>
                        <div class="table-container">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Ub’i’ Okisanel</th>
                                        <th>B’i’aj</th>
                                        <th>Chak</th>
                                        <th>MFA</th>
                                        <th>Chak</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($users as $u): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($u['user']) ?></td>
                                            <td><?= htmlspecialchars($u['name'] ?? '') ?></td>
                                            <td><?= getRoleName($u['role']) ?></td>
                                            <td>
                                                <span class="status-badge <?= $u['mfa'] ? 'status-admitted' : 'status-discharged' ?>">
                                                    <?= $u['mfa'] ? 'Xchaplex' : 'Xchuplix' ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if ($u['user'] != 'admin'): ?>
                                                    <form method="POST" style="display:inline;">
                                                        <input type="hidden" name="delete_user" value="1">
                                                        <input type="hidden" name="target_user" value="<?= htmlspecialchars($u['user']) ?>">
                                                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Chesaj <?= htmlspecialchars($u['user']) ?>?')">Chesaj</button>
                                                    </form>
                                                <?php else: ?>
                                                    <span style="color:var(--text-muted);">Ajchak’</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div style="margin-top:var(--spacing-xl);">
                <a href="?action=mfa_admin" class="btn" style="background:var(--text-muted); color:var(--text-inverse);">MFA Ajchak’</a>
                <a href="?action=dashboard" class="btn btn-primary">Nab’e wuj</a>
            </div>
        </div>
    </div>
<?php
    showFooter();
}

function showAdminPanel() {
    if (!can('admin')) {
        showError('Xq’ataj ri b’ixikil');
        exit;
    }
    
    $dbInfo = db()->query("SELECT
            (SELECT COUNT(*) FROM patients) AS patients,
            (SELECT COUNT(*) FROM patients WHERE status = 'discharged') AS awaiting,
            (SELECT COUNT(*) FROM detached_patients) AS detached,
            (SELECT COUNT(*) FROM activity_log) AS log_rows,
            (SELECT ROUND(SUM(data_length + index_length) / 1024, 1) FROM information_schema.tables
              WHERE table_schema = DATABASE()) AS size_kb,
            VERSION() AS version,
            @@event_scheduler AS scheduler")->fetch();
    $lastRun = db()->query("SELECT run_at, moved, source FROM detach_runs ORDER BY run_id DESC LIMIT 1")->fetch();

    $dischargedDir = DISCHARGED_DIR;
    $dischargedCount = count(getArchiveKeys());
    $pdfCount = file_exists($dischargedDir) ? count(glob($dischargedDir . '*.pdf')) : 0;

    $genderCounts = [
        'male' => 0,
        'female' => 0,
        'transgender_mtf' => 0,
        'transgender_ftm' => 0,
        'non_binary' => 0,
        'genderqueer' => 0,
        'intersex' => 0,
        'other' => 0,
        'prefer_not_to_say' => 0
    ];
    
    $patients = readJSONFile($GLOBALS['pF']);
    if (is_array($patients)) {
        foreach ($patients as $pt) {
            if (is_array($pt) && isset($pt['gender'])) {
                $gender = $pt['gender'];
                if (isset($genderCounts[$gender])) {
                    $genderCounts[$gender]++;
                } else {
                    $genderCounts['other']++;
                }
            }
        }
    }

    showHeader();
?>
    <div class="container">
        <div class="card">
            <h2>🔧 Wuj re Ajchak’</h2>
            
            <div class="grid grid-2">
                <div class="card">
                    <h3>Yakb’al Retal</h3>
                    <p><strong>Servidor:</strong> MySQL <?= htmlspecialchars($dbInfo['version']) ?> &middot; <?= htmlspecialchars(DB_NAME) ?>@<?= htmlspecialchars(DB_HOST) ?></p>
                    <p><strong>patients:</strong> <?= (int)$dbInfo['patients'] ?> cholaj, <?= (int)$dbInfo['awaiting'] ?> xeel ke’oyob’ej yakb’al</p>
                    <p><strong>detached_patients:</strong> <?= (int)$dbInfo['detached'] ?> (cholaj)</p>
                    <p><strong>Nimal Yakb’al Retal:</strong> <?= htmlspecialchars((string)$dbInfo['size_kb']) ?> KB</p>
                    <p><strong>Ewanik:</strong> ROT47 (ucholaj data_rot47)</p>
                    <p><strong>Ajcholonel k’ulmatajem:</strong> <?= htmlspecialchars($dbInfo['scheduler']) ?><?= strtoupper($dbInfo['scheduler']) !== 'ON' ? ' &mdash; ri yakb’al kachakun pa ri nab’e wuj chi rij Domingo 00:00' : '' ?></p>
                    <p><strong>activity_log:</strong> <?= (int)$dbInfo['log_rows'] ?> tz’ib’<?= (defined('LOG_RETENTION_DAYS') && (int)LOG_RETENTION_DAYS > 0) ? ' (kyakon ' . (int)LOG_RETENTION_DAYS . ' q’ij)' : '' ?></p>
                    <p><strong>Ruk’isb’al yakb’al:</strong> <?= $lastRun ? htmlspecialchars($lastRun['run_at'] . ' (' . $lastRun['source'] . ', ' . $lastRun['moved'] . ' xjalwachixik)') : 'majun mul' ?></p>
                </div>
                
                <div class="card">
                    <h3>Yawab’ Yakom</h3>
                    <p><strong>Tabla Yakb’al:</strong> detached_patients</p>
                    <p><strong>Wuqq q’ij re Yakb’al:</strong> <?= $dischargedCount ?></p>
                    <p><strong>PDF Wuj:</strong> <?= $pdfCount ?></p>
                    <p><strong>Ramaj re Yakb’al:</strong> <?= ucfirst(archiveScheduleText()) ?></p>
                    <p><strong>Chak kepe:</strong> <?= date('d-m-Y H:i', nextArchiveRun()) ?></p>
                    <p><strong>Wachib’al pa Yakb’al:</strong> <?= PHOTO_DELETE_ON_ARCHIVE ? 'Xesax' : 'Yakom' ?></p>
                </div>
                
                <?php if (shouldIncludeGenderInStats() && array_sum($genderCounts) > 0): ?>
                <div class="card">
                    <h3>Ajilab’al Achi/Ixoq</h3>
                    <?php 
                    $total = array_sum($genderCounts);
                    foreach ($genderCounts as $gender => $count): 
                        if ($count == 0) continue;
                        $percentage = round(($count / $total) * 100, 1);
                        $genderClass = str_replace('_', '-', $gender);
                    ?>
                        <div style="margin-bottom:5px;">
                            <span class="gender-badge <?= $genderClass ?>" style="margin-right:5px;"><?= getGenderName($gender) ?></span>
                            <?= $count ?> (<?= $percentage ?>%)
                        </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
                
                <div class="card">
                    <h3>Aninaq Chak</h3>
                    <div style="display:flex; flex-direction:column; gap:10px;">
                        <form method="POST">
                            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                            <input type="hidden" name="manual_detach" value="1">
                            <button type="submit" class="btn btn-danger" style="width:100%;" onclick="return confirm('Chayaka’ ronoj yawab’ xeel kamik? Ri kiwachib’al kesax we xchaplex ri PHOTO_DELETE_ON_ARCHIVE.')">
                                ⏰ Chayaka’ Yawab’ Xeel Kamik
                            </button>
                        </form>
                        <form method="POST">
                            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                            <input type="hidden" name="toggle_encryption" value="1">
                            <button type="submit" class="btn btn-warning" style="width:100%;" onclick="return confirm('Chak’ewaj chi jun mul ronoj tz’ib’ re yawab’ rik’in ROT47?')">
                                🔒 Chak’ewaj chi jun mul Retal Yawab’ (ROT47)
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <h3>Retal Ucholajil</h3>
                <p><strong>PHP Uk’ak’al:</strong> <?= phpversion() ?></p>
                <p><strong>Software re Servidor:</strong> <?= $_SERVER['SERVER_SOFTWARE'] ?? 'Man etaman ta' ?></p>
                <p><strong>Uxe’ Wuj:</strong> <?= $_SERVER['DOCUMENT_ROOT'] ?></p>
                <p><strong>Ub’e Yakik Sesion:</strong> <?= session_save_path() ?: 'Junam' ?></p>
                <p><strong>Nim Nimal Wuj Kajotesax:</strong> <?= ini_get('upload_max_filesize') ?></p>
                <p><strong>Nim Nimal POST:</strong> <?= ini_get('post_max_size') ?></p>
                <p><strong>GD Ja re Wuj:</strong> <?= extension_loaded('gd') ? 'Yakom' : 'Man Yakom Ta' ?> (Rajawaxik che rub’anik PDF)</p>
            </div>
            
            <div style="margin-top:var(--spacing-xl);">
                <a href="?action=dashboard" class="btn">← Chatzalij</a>
                <a href="?action=debug_photos" class="btn btn-primary">Debug Ucholajil Wachib’al</a>
                <a href="?action=logs" class="btn btn-primary">Tz’ib’ Ucholajil</a>
                <a href="?action=forecast" class="btn btn-primary">Nab’e ilik</a>
                <a href="?action=editor&history=1" class="btn btn-primary">Ub’e Tzukunik Ajutzirisanel</a>
                <a href="?action=discharged" class="btn btn-primary">Yawab’ Yakom</a>
            </div>
        </div>
    </div>
<?php
    showFooter();
}

// ==================== ADMIN DATA EDITOR ====================
// Administrator-only editor for the complete JSON record of every patient (active patients in
// `patients` and de-attached patients in `detached_patients`) and for the other data sets
// (rooms, telephones, medications, statistics). Every save is checked against the version
// that was opened (so two admins cannot silently overwrite each other) and written to the log.

function editorJson($v) {
    return json_encode($v, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function editorHash($v) {
    return sha1(json_encode($v, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
}

// Data sets that can be edited as one JSON list. Users are left out on purpose:
// passwords and MFA secrets are managed under Users / MFA Admin.
function editorDatasets() {
    return [
        'rooms'       => ['file' => ROOMS_FILE,       'label' => 'Taq ja'],
        'telephones'  => ['file' => TELEPHONES_FILE,  'label' => 'Ch’awib’al'],
        'medications' => ['file' => MEDICATIONS_FILE, 'label' => 'Kunab’al'],
        'statistics'  => ['file' => STATISTICS_FILE,  'label' => 'Ajilanik'],
    ];
}

// Raw de-attached rows for one patient id: [['row' => db row, 'data' => decoded record], ...]
function editorDetachedRows($id) {
    $stmt = db()->prepare("SELECT * FROM detached_patients WHERE id = ?");
    $stmt->execute([$id]);
    $out = [];
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $data = json_decode(str_rot47((string)($row['data_rot47'] ?? '')), true);
        if (is_array($data)) $out[] = ['row' => $row, 'data' => $data];
    }
    return $out;
}

// Finds a record. $src = 'live' | 'archive'; $ref = sha1 of data_rot47 for archive rows.
// Returns ['data' => record, 'ref' => ..., 'row' => db row (archive only)] or null.
function editorLoad($src, $id, $ref = '') {
    if ($src === 'live') {
        foreach (readJSONFile($GLOBALS['pF']) as $pt) {
            if (is_array($pt) && (string)($pt['id'] ?? '') === (string)$id) {
                return ['data' => $pt, 'ref' => '', 'row' => null];
            }
        }
        return null;
    }
    foreach (editorDetachedRows($id) as $r) {
        $h = sha1((string)$r['row']['data_rot47']);
        if ($ref === '' || $ref === $h) return ['data' => $r['data'], 'ref' => $h, 'row' => $r['row']];
    }
    return null;
}

function editorRedirect($qs) {
    header('Location: ?action=editor' . ($qs !== '' ? '&' . $qs : ''));
    exit;
}

function editorDecodePosted() {
    $raw = (string)($_POST['json'] ?? '');
    $data = json_decode($raw, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        return [null, 'JSON man utz ta: ' . json_last_error_msg()];
    }
    return [$data, null];
}

// Recalculates rooms.occ from the admitted patients in the `patients` table
function editorRecalcOccupancy() {
    $patients = readJSONFile($GLOBALS['pF']);
    $rooms = readJSONFile($GLOBALS['rF']);
    if (!is_array($rooms)) return;
    $count = [];
    foreach ($patients as $pt) {
        if (is_array($pt) && ($pt['status'] ?? '') === 'admitted' && isset($pt['room_id'])) {
            $count[(string)$pt['room_id']] = ($count[(string)$pt['room_id']] ?? 0) + 1;
        }
    }
    $changed = false;
    foreach ($rooms as &$rm) {
        $n = $count[(string)($rm['id'] ?? '')] ?? 0;
        if ((int)($rm['occ'] ?? 0) !== $n) { $rm['occ'] = $n; $changed = true; }
    }
    unset($rm);
    if ($changed) writeJSONFile($GLOBALS['rF'], $rooms);
}

// Top-level keys that differ between two records (for the log)
function editorChangedKeys($old, $new) {
    $keys = array_unique(array_merge(array_keys($old), array_keys($new)));
    $changed = [];
    foreach ($keys as $k) {
        if (!array_key_exists($k, $old) || !array_key_exists($k, $new) || $old[$k] !== $new[$k]) $changed[] = $k;
    }
    return $changed;
}

function editorSavePatient() {
    $src = ($_POST['src'] ?? '') === 'archive' ? 'archive' : 'live';
    $id = (string)($_POST['id'] ?? '');
    $ref = (string)($_POST['ref'] ?? '');
    $hash = (string)($_POST['hash'] ?? '');
    $back = 'src=' . $src . '&id=' . urlencode($id) . ($ref !== '' ? '&ref=' . urlencode($ref) : '');

    list($new, $err) = editorDecodePosted();
    if ($err === null && (!is_array($new) || ($new !== [] && array_keys($new) === range(0, count($new) - 1)))) $err = 'Ri tz’ib’ re yawab’ rajawaxik JSON jastaq { ... }';
    if ($err === null && trim((string)($new['id'] ?? '')) === '') $err = 'Ri tz’ib’ rajawaxik "id"';
    if ($err === null && trim((string)($new['name'] ?? '')) === '') $err = 'Ri tz’ib’ rajawaxik "name"';
    if ($err !== null) {
        $_SESSION['editor_draft'] = (string)($_POST['json'] ?? '');
        $_SESSION['error'] = $err;
        editorRedirect($back);
    }

    $cur = editorLoad($src, $id, $ref);
    if (!$cur) {
        $_SESSION['error'] = 'Man xriqitaj ta ri tz’ib’ re yawab’ (rajawaxik xyak o xesax pa ri ramaj ri’)';
        editorRedirect('');
    }
    if ($hash !== editorHash($cur['data'])) {
        $_SESSION['editor_draft'] = (string)($_POST['json'] ?? '');
        $_SESSION['error'] = 'Jun chik winaq xujalwachij we tz’ib’ ri’ chi rij xajaqo. Ri atz’ib’ yakom chuxe’; chajotesaj chi jun mul che rilik ri k’ak’.';
        editorRedirect($back);
    }

    $newId = (string)$new['id'];
    $changed = editorChangedKeys($cur['data'], $new);
    if (!$changed) {
        $_SESSION['info'] = 'Maja k’o jalwachinik';
        editorRedirect($back);
    }

    // No edit without an audit trail: stop before anything is written if editor_audit is unavailable
    try {
        editorAuditEnsure();
    } catch (Throwable $e) {
        $_SESSION['editor_draft'] = (string)$_POST['json'];
        $_SESSION['error'] = 'Maja k’o yakom: ri tabla tzukunik editor_audit man katz’ib’ax ta (' . $e->getMessage() . ')';
        editorRedirect($back);
    }
    $sideEffects = [];

    if ($src === 'live') {
        $patients = readJSONFile($GLOBALS['pF']);
        $pi = null;
        foreach ($patients as $i => $pt) {
            if (is_array($pt) && (string)($pt['id'] ?? '') === $id) { $pi = $i; continue; }
            if ($newId !== $id && is_array($pt) && (string)($pt['id'] ?? '') === $newId) {
                $_SESSION['editor_draft'] = (string)$_POST['json'];
                $_SESSION['error'] = "ID yawab’ $newId kokisax chi";
                editorRedirect($back);
            }
        }
        if ($pi === null) { $_SESSION['error'] = 'Man xriqitaj ta ri tz’ib’ re yawab’'; editorRedirect(''); }

        if (!empty($_POST['sync_room']) && isset($new['room_id'])) {
            foreach (readJSONFile($GLOBALS['rF']) as $rm) {
                if ((string)($rm['id'] ?? '') === (string)$new['room_id']) {
                    if (($new['room_num'] ?? null) !== $rm['num']) {
                        $sideEffects['room_num_synced'] = ['from' => $new['room_num'] ?? null, 'to' => $rm['num']];
                    }
                    $new['room_num'] = $rm['num'];
                    break;
                }
            }
        }
        $patients[$pi] = $new;
        try {
            writeJSONFile($GLOBALS['pF'], $patients);
            if ($newId !== $id) {
                // Make sure no row is left behind under the old id
                db()->prepare("DELETE FROM patients WHERE id = ?")->execute([$id]);
            }
            if (!empty($_POST['recalc_occ'])) {
                $occBefore = editorRoomOccupancySnapshot();
                editorRecalcOccupancy();
                $occAfter = editorRoomOccupancySnapshot();
                $occChanges = [];
                foreach ($occAfter as $rid => $r) {
                    $was = $occBefore[$rid]['occ'] ?? null;
                    if ($was !== $r['occ']) $occChanges[] = ['room_id' => $rid, 'room' => $r['num'], 'occ_before' => $was, 'occ_after' => $r['occ']];
                }
                if ($occChanges) $sideEffects['room_occupancy_recalculated'] = $occChanges;
            }
        } catch (Throwable $e) {
            $_SESSION['editor_draft'] = (string)$_POST['json'];
            $_SESSION['error'] = 'Ri yakik man xel ta: ' . $e->getMessage();
            editorRedirect($back);
        }
        $newRef = '';
    } else {
        try {
            $newRef = editorUpdateDetached($cur['row'], $new);
        } catch (Throwable $e) {
            $_SESSION['editor_draft'] = (string)$_POST['json'];
            $_SESSION['error'] = 'Ri yakik man xel ta: ' . $e->getMessage();
            editorRedirect($back);
        }
    }

    $label = $src === 'live' ? 'patients' : 'detached_patients';
    if ($src === 'archive' && $cur['row']) {
        $sideEffects['archive_week'] = $cur['row']['archive_week'] ?? null;
    }
    $auditNote = editorWriteAudit('patient', $label, $newId, $id, (string)$new['name'], $cur['data'], $new, $sideEffects);
    logMsg("Admin ajutzirisanel: xk’ak’arisax {$new['name']} ($newId) pa $label" . ($newId !== $id ? " (ID xjalwachix pa $id)" : '') .
           " - ucholaj: " . implode(', ', $changed) . $auditNote);
    $_SESSION['success'] = 'Ri tz’ib’ re yawab’ yakom (' . count($changed) . ' ucholaj' . ' xjalwachix: ' . implode(', ', $changed) . ')';
    if ($newId !== $id) $_SESSION['warning'] = 'Ri ID yawab’ xjalwachix. Ri wachib’al yakom pa ri ojer ID (' . $id . ') rachi’ man k’o ta chi rachi’il.';
    editorRedirect('src=' . $src . '&id=' . urlencode($newId) . ($newRef !== '' ? '&ref=' . urlencode($newRef) : ''));
}

// Writes an edited record back into its own row in `detached_patients`. Besides data_rot47,
// every plain column whose name matches a top-level field (name, discharge_date, ...) is kept
// in sync, so lists and filters that read those columns show the new values.
function editorUpdateDetached($row, $new) {
    $pdo = db();
    $cols = [];
    foreach ($pdo->query("SHOW COLUMNS FROM detached_patients")->fetchAll(PDO::FETCH_ASSOC) as $c) {
        $cols[$c['Field']] = $c;
    }
    $encoded = str_rot47(json_encode($new, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    $set = ['data_rot47 = ?'];
    $vals = [$encoded];
    foreach ($cols as $name => $c) {
        if ($name === 'data_rot47' || ($c['Extra'] ?? '') !== '' && stripos($c['Extra'], 'auto_increment') !== false) continue;
        if (!array_key_exists($name, $new)) continue;
        $v = $new[$name];
        if (is_array($v)) continue;
        if (is_bool($v)) $v = (int)$v;
        if (($v === '' || $v === null) && preg_match('/date|time|int|decimal|float|double/i', $c['Type'])) {
            if (($c['Null'] ?? '') !== 'YES') continue;
            $v = null;
        }
        $set[] = "`$name` = ?";
        $vals[] = $v;
    }
    // Keep the archive week in step with the discharge date
    if (isset($cols['archive_week']) && !array_key_exists('archive_week', $new) && !empty($new['discharge_date'])
        && ($ts = strtotime($new['discharge_date']))) {
        $set[] = '`archive_week` = ?';
        $vals[] = archiveWeekKey($ts);
    }
    $vals[] = $row['id'];
    $vals[] = $row['data_rot47'];
    $stmt = $pdo->prepare("UPDATE detached_patients SET " . implode(', ', $set) . " WHERE id = ? AND data_rot47 = ?");
    $stmt->execute($vals);
    if ($stmt->rowCount() !== 1) throw new RuntimeException('ri cholaj re yakb’al xjalwachix pa ri ramaj ri’, maja k’o yakom');
    return sha1($encoded);
}

// ==================== ADMIN EDITOR AUDIT TRAIL (MySQL table editor_audit) ====================
// Every save in the Admin editor writes one row: who, when, from which IP, which table and
// record, every changed field (old -> new, nested paths such as discharge.prescription.items[0].dose)
// and the COMPLETE record before and after the edit. Patient data is stored ROT47-encoded, the same
// way as patients.data_rot47. Rows are never updated or purged by the application (unlike
// activity_log, which is purged after LOG_RETENTION_DAYS). The table is created automatically;
// the same DDL (plus optional append-only triggers) is in sql/editor_audit.sql.

function editorAuditEnsure() {
    static $done = false;
    if ($done) return;
    db()->exec("CREATE TABLE IF NOT EXISTS editor_audit (
        id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        edited_at       DATETIME        NOT NULL,
        username        VARCHAR(60)     NOT NULL,
        user_name       VARCHAR(120)    NULL,
        user_role       VARCHAR(40)     NULL,
        ip              VARCHAR(45)     NULL,
        user_agent      VARCHAR(255)    NULL,
        target_type     VARCHAR(20)     NOT NULL,
        target_table    VARCHAR(40)     NOT NULL,
        record_id       VARCHAR(64)     NOT NULL,
        old_record_id   VARCHAR(64)     NULL,
        record_name     VARCHAR(200)    NULL,
        change_count    INT UNSIGNED    NOT NULL DEFAULT 0,
        changed_fields  TEXT            NOT NULL,
        changes_rot47   MEDIUMTEXT      NOT NULL,
        before_rot47    MEDIUMTEXT      NOT NULL,
        after_rot47     MEDIUMTEXT      NOT NULL,
        before_sha1     CHAR(40)        NOT NULL,
        after_sha1      CHAR(40)        NOT NULL,
        side_effects    MEDIUMTEXT      NULL,
        KEY idx_record (record_id, edited_at),
        KEY idx_old_record (old_record_id),
        KEY idx_time (edited_at),
        KEY idx_user (username, edited_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $done = true;
}

// Lists of objects that all carry a unique "id" are compared by id instead of position,
// so deleting room #2 is logged as one removal, not as every following room "changing".
function editorAuditIdMap($list) {
    if (!is_array($list) || $list === [] || array_keys($list) !== range(0, count($list) - 1)) return null;
    $map = [];
    foreach ($list as $item) {
        if (!is_array($item) || !isset($item['id']) || is_array($item['id']) || isset($map[(string)$item['id']])) return null;
        $map[(string)$item['id']] = $item;
    }
    return $map;
}

// Full recursive difference: [['path' => ..., 'op' => added|removed|changed, 'old' => ..., 'new' => ...], ...]
function editorDiff($old, $new, $path = '', array &$out = []) {
    if (count($out) >= 5000) return $out;
    if (is_array($old) && is_array($new)) {
        $om = editorAuditIdMap($old);
        $nm = editorAuditIdMap($new);
        $byId = $om !== null && $nm !== null;
        if ($byId) { $old = $om; $new = $nm; }
        $isList = !$byId && (array_keys($old) === range(0, count($old) - 1) || $old === [])
                          && (array_keys($new) === range(0, count($new) - 1) || $new === []);
        foreach (array_unique(array_merge(array_keys($old), array_keys($new))) as $k) {
            if ($byId)       $p = $path . '[id=' . $k . ']';
            elseif ($isList) $p = $path . '[' . $k . ']';
            else             $p = $path === '' ? (string)$k : $path . '.' . $k;
            if (!array_key_exists($k, $old))      $out[] = ['path' => $p, 'op' => 'added', 'old' => null, 'new' => $new[$k]];
            elseif (!array_key_exists($k, $new))  $out[] = ['path' => $p, 'op' => 'removed', 'old' => $old[$k], 'new' => null];
            else editorDiff($old[$k], $new[$k], $p, $out);
        }
    } elseif ($old !== $new) {
        $out[] = ['path' => $path === '' ? '(ronoj tz’ib’)' : $path, 'op' => 'changed', 'old' => $old, 'new' => $new];
    }
    return $out;
}

function editorAuditEncode($v) {
    return str_rot47(json_encode($v, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR));
}

function editorAuditDecode($s) {
    return json_decode(str_rot47((string)$s), true);
}

// Writes one audit row. Returns the new audit id.
function editorAudit($type, $table, $recordId, $oldRecordId, $name, $before, $after, array $sideEffects = []) {
    editorAuditEnsure();
    $changes = editorDiff($before, $after);
    $fields = [];
    foreach ($changes as $c) {
        $top = preg_split('/[.\[]/', $c['path'], 2)[0];
        $fields[$top === '' ? $c['path'] : $top] = true;
    }
    $u = $_SESSION['user'] ?? [];
    $stmt = db()->prepare("INSERT INTO editor_audit
        (edited_at, username, user_name, user_role, ip, user_agent, target_type, target_table, record_id, old_record_id,
         record_name, change_count, changed_fields, changes_rot47, before_rot47, after_rot47, before_sha1, after_sha1, side_effects)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        date('Y-m-d H:i:s'),
        substr((string)($u['user'] ?? 'unknown'), 0, 60),
        substr((string)($u['name'] ?? ''), 0, 120),
        substr((string)($u['role'] ?? ''), 0, 40),
        substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45),
        substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255),
        $type, $table,
        substr((string)$recordId, 0, 64),
        ($oldRecordId !== null && (string)$oldRecordId !== (string)$recordId) ? substr((string)$oldRecordId, 0, 64) : null,
        substr((string)$name, 0, 200),
        count($changes),
        implode(', ', array_keys($fields)),
        editorAuditEncode($changes),
        editorAuditEncode($before),
        editorAuditEncode($after),
        editorHash($before),
        editorHash($after),
        $sideEffects ? editorAuditEncode($sideEffects) : null,
    ]);
    return (int)db()->lastInsertId();
}

// Room occupancy before/after a recalculation, for the audit row
function editorRoomOccupancySnapshot() {
    $out = [];
    foreach ((array)readJSONFile($GLOBALS['rF']) as $rm) {
        if (is_array($rm) && isset($rm['id'])) $out[(string)$rm['id']] = ['num' => $rm['num'] ?? '', 'occ' => (int)($rm['occ'] ?? 0)];
    }
    return $out;
}

function editorSaveDataset() {
    $key = (string)($_POST['dataset'] ?? '');
    $sets = editorDatasets();
    if (!isset($sets[$key])) editorRedirect('');
    list($new, $err) = editorDecodePosted();
    if ($err === null && !is_array($new)) $err = 'Ri mulam retal rajawaxik JSON cholb’al [ ... ] o jastaq { ... }';
    $cur = readJSONFile($sets[$key]['file']);
    if ($err === null && (string)($_POST['hash'] ?? '') !== editorHash($cur)) {
        $err = 'Jun chik winaq xujalwachij we mulam retal ri’ chi rij xajaqo. Ri atz’ib’ yakom chuxe’; chajotesaj chi jun mul che rilik ri k’ak’.';
    }
    if ($err === null && editorHash($cur) === editorHash($new)) {
        $_SESSION['info'] = 'Maja k’o jalwachinik';
        editorRedirect('dataset=' . $key);
    }
    if ($err === null) {
        try {
            editorAuditEnsure();
        } catch (Throwable $e) {
            $err = 'Maja k’o yakom: ri tabla tzukunik editor_audit man katz’ib’ax ta (' . $e->getMessage() . ')';
        }
    }
    if ($err !== null) {
        $_SESSION['editor_draft'] = (string)($_POST['json'] ?? '');
        $_SESSION['error'] = $err;
        editorRedirect('dataset=' . $key);
    }
    try {
        writeJSONFile($sets[$key]['file'], $new);
    } catch (Throwable $e) {
        $_SESSION['editor_draft'] = (string)$_POST['json'];
        $_SESSION['error'] = 'Ri yakik man xel ta: ' . $e->getMessage();
        editorRedirect('dataset=' . $key);
    }
    $auditNote = editorWriteAudit('dataset', $key, $key, $key, $sets[$key]['label'], $cur, $new);
    logMsg("Admin ajutzirisanel: mulam retal {$sets[$key]['label']} yakom (" . count($cur) . " -> " . count($new) . " tz’ib’)" . $auditNote);
    $_SESSION['success'] = $sets[$key]['label'] . ' yakom (' . count($new) . ' tz’ib’)';
    editorRedirect('dataset=' . $key);
}

// Writes the audit row after a save. The save itself already happened, so if MySQL fails here the
// full entry goes to data/editor_audit_fallback.log (ROT47 JSON lines) and is imported on the next
// editor page load. Returns a suffix for the activity log line.
function editorWriteAudit($type, $table, $recordId, $oldRecordId, $name, $before, $after, array $sideEffects = []) {
    try {
        $aid = editorAudit($type, $table, $recordId, $oldRecordId, $name, $before, $after, $sideEffects);
        return " - tzukunik #$aid";
    } catch (Throwable $e) {
        $entry = [
            'edited_at' => date('Y-m-d H:i:s'), 'user' => $_SESSION['user'] ?? [], 'ip' => $_SERVER['REMOTE_ADDR'] ?? '',
            'ua' => $_SERVER['HTTP_USER_AGENT'] ?? '', 'type' => $type, 'table' => $table, 'record_id' => $recordId,
            'old_record_id' => $oldRecordId, 'name' => $name, 'before' => $before, 'after' => $after, 'side' => $sideEffects,
        ];
        unset($entry['user']['pass'], $entry['user']['secret']);
        @file_put_contents(DATA_DIR . 'editor_audit_fallback.log', editorAuditEncode($entry) . PHP_EOL, FILE_APPEND | LOCK_EX);
        $_SESSION['warning'] = 'Yakom, are k’u ri cholaj tzukunik man xtz’ib’ax ta pa MySQL (' . $e->getMessage() . '). Yakom pa jun chik wuj kok na rumal.';
        return ' - TZUKUNIK man xel ta, yakom pa jun chik wuj';
    }
}

// Imports entries from the fallback file (written while MySQL was failing) into editor_audit
function editorAuditImportFallback() {
    $file = DATA_DIR . 'editor_audit_fallback.log';
    if (!is_file($file) || filesize($file) === 0) return;
    $work = $file . '.importing-' . bin2hex(random_bytes(4));
    if (!@rename($file, $work)) return;
    $left = [];
    foreach (file($work, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [] as $line) {
        $e = editorAuditDecode($line);
        if (!is_array($e)) continue;
        try {
            $saved = $_SESSION['user'] ?? null;
            $savedIp = $_SERVER['REMOTE_ADDR'] ?? null;
            $_SESSION['user'] = $e['user'];
            $_SERVER['REMOTE_ADDR'] = $e['ip'];
            $aid = editorAudit($e['type'], $e['table'], $e['record_id'], $e['old_record_id'], $e['name'], $e['before'], $e['after'],
                               array_merge((array)$e['side'], ['imported_from_fallback' => true, 'original_time' => $e['edited_at']]));
            db()->prepare("UPDATE editor_audit SET edited_at = ? WHERE id = ?")->execute([$e['edited_at'], $aid]);
        } catch (Throwable $ex) {
            $left[] = $line;
        } finally {
            $_SESSION['user'] = $saved;
            $_SERVER['REMOTE_ADDR'] = $savedIp;
        }
    }
    if ($left) @file_put_contents($file, implode(PHP_EOL, $left) . PHP_EOL, FILE_APPEND | LOCK_EX);
    @unlink($work);
}

function editorAuditValue($v) {
    if ($v === null) return '<span class="text-muted">null</span>';
    if (is_bool($v)) return $v ? 'true' : 'false';
    if (is_string($v)) return nl2br(htmlspecialchars($v));
    return '<code>' . htmlspecialchars(json_encode($v, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) . '</code>';
}

// ?action=editor&audit_json=ID&which=before|after|changes  - downloads one audit blob as JSON
function editorAuditDownload() {
    $which = in_array($_GET['which'] ?? '', ['before', 'after', 'changes'], true) ? $_GET['which'] : 'after';
    $stmt = db()->prepare("SELECT id, record_id, edited_at, {$which}_rot47 AS blob FROM editor_audit WHERE id = ?");
    $stmt->execute([(int)$_GET['audit_json']]);
    $r = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$r) { showError('Man xriqitaj ta ri tz’ib’ tzukunik'); exit; }
    logMsg("Admin ajutzirisanel: tzukunik xqasax #{$r['id']} ($which) re tz’ib’ {$r['record_id']}");
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="audit_' . $r['id'] . '_' . preg_replace('/[^A-Za-z0-9_-]/', '', $r['record_id']) . '_' . $which . '.json"');
    echo json_encode(editorAuditDecode($r['blob']), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

// ?action=editor&history=1 [&rid=record id] [&user=] [&table=] [&from=&to=] [&page=]
function showEditorHistory() {
    $rid = trim((string)($_GET['rid'] ?? ''));
    $user = trim((string)($_GET['user'] ?? ''));
    $table = (string)($_GET['table'] ?? '');
    $from = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['from'] ?? '') ? $_GET['from'] : '';
    $to = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['to'] ?? '') ? $_GET['to'] : '';
    $page = max(1, (int)($_GET['page'] ?? 1));
    $per = 50;

    $where = [];
    $args = [];
    if ($rid !== '')   { $where[] = '(record_id = ? OR old_record_id = ? OR record_name LIKE ?)'; array_push($args, $rid, $rid, '%' . addcslashes($rid, '%_\\') . '%'); }
    if ($user !== '')  { $where[] = '(username LIKE ? OR user_name LIKE ?)'; $l = '%' . addcslashes($user, '%_\\') . '%'; array_push($args, $l, $l); }
    if ($table !== '') { $where[] = 'target_table = ?'; $args[] = $table; }
    if ($from !== '')  { $where[] = 'edited_at >= ?'; $args[] = $from . ' 00:00:00'; }
    if ($to !== '')    { $where[] = 'edited_at <= ?'; $args[] = $to . ' 23:59:59'; }
    $sqlWhere = $where ? ' WHERE ' . implode(' AND ', $where) : '';

    $rows = [];
    $total = 0;
    $tables = [];
    $error = '';
    try {
        editorAuditEnsure();
        $c = db()->prepare("SELECT COUNT(*) FROM editor_audit" . $sqlWhere);
        $c->execute($args);
        $total = (int)$c->fetchColumn();
        $s = db()->prepare("SELECT id, edited_at, username, user_name, user_role, ip, user_agent, target_type, target_table, record_id,
                                   old_record_id, record_name, change_count, changed_fields, changes_rot47, side_effects
                              FROM editor_audit" . $sqlWhere . " ORDER BY edited_at DESC, id DESC LIMIT $per OFFSET " . (($page - 1) * $per));
        $s->execute($args);
        $rows = $s->fetchAll(PDO::FETCH_ASSOC);
        $tables = db()->query("SELECT DISTINCT target_table FROM editor_audit ORDER BY target_table")->fetchAll(PDO::FETCH_COLUMN);
    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
    $pages = max(1, (int)ceil($total / $per));
    $qs = http_build_query(array_filter(['action' => 'editor', 'history' => 1, 'rid' => $rid, 'user' => $user, 'table' => $table, 'from' => $from, 'to' => $to], 'strlen'));

    showHeader();
?>
    <style>
        .au-diff { width:100%; border-collapse:collapse; font-size:13px; margin-top:8px; }
        .au-diff th, .au-diff td { border-bottom:1px solid #eee; padding:5px 8px; vertical-align:top; text-align:left; }
        .au-diff th { font-size:11px; text-transform:uppercase; color:#666; }
        .au-diff td.p { font-family:Consolas,Menlo,monospace; white-space:nowrap; }
        .au-diff td.o { background:#fbeaea; } .au-diff td.n { background:#e9f6ec; }
        .au-diff code { white-space:pre-wrap; font-size:12px; }
        .au-op { font-size:11px; padding:1px 6px; border-radius:8px; border:1px solid #999; }
        .au-entry { border:1px solid #ddd; border-radius:6px; margin-bottom:10px; padding:8px 12px; }
        .au-entry > summary { cursor:pointer; display:flex; gap:14px; flex-wrap:wrap; align-items:baseline; }
        .au-meta { font-size:12px; color:#666; margin-top:8px; }
    </style>
    <div class="container">
        <div style="margin-bottom:10px;"><a href="?action=editor" class="btn btn-sm">← Ajutzirisanel</a></div>
        <div class="card" style="margin-bottom:20px;">
            <h2><i class="fas fa-history"></i> Ub’e tzukunik ajutzirisanel</h2>
            <p class="text-muted">Chi jujun yakik pa ri ajutzirisanel Admin, rachi’ ronoj tz’ib’ nab’e rachi’ chi rij. Yakom pa jun tabla MySQL <code>editor_audit</code> rachi’ majun mul kesaj ri aplicacion.</p>
            <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;">
                <input type="hidden" name="action" value="editor">
                <input type="hidden" name="history" value="1">
                <div><label>ID / ub’i’ tz’ib’</label><br><input type="text" name="rid" value="<?= htmlspecialchars($rid) ?>"></div>
                <div><label>Xutzirisaj</label><br><input type="text" name="user" value="<?= htmlspecialchars($user) ?>"></div>
                <div><label>Tabla</label><br>
                    <select name="table"><option value="">Ronoj</option>
                        <?php foreach ($tables as $t): ?><option value="<?= htmlspecialchars($t) ?>" <?= $t === $table ? 'selected' : '' ?>><?= htmlspecialchars($t) ?></option><?php endforeach; ?>
                    </select></div>
                <div><label>Pa</label><br><input type="date" name="from" value="<?= htmlspecialchars($from) ?>"></div>
                <div><label>K’a</label><br><input type="date" name="to" value="<?= htmlspecialchars($to) ?>"></div>
                <button class="btn btn-primary" type="submit"><i class="fas fa-search"></i> Chach’ay</button>
                <?php if ($qs !== 'action=editor&history=1'): ?><a class="btn" href="?action=editor&history=1">Chesaj</a><?php endif; ?>
            </form>
            <p style="margin-top:10px;"><strong><?= $total ?></strong> utzirisanik</p>
        </div>

        <?php if ($error !== ''): ?><div class="alert alert-error">Ri tabla tzukunik maja k’o: <?= htmlspecialchars($error) ?></div><?php endif; ?>

        <?php foreach ($rows as $r):
            $changes = editorAuditDecode($r['changes_rot47']) ?: [];
            $side = $r['side_effects'] ? editorAuditDecode($r['side_effects']) : null;
            $editUrl = $r['target_type'] === 'dataset' ? '?action=editor&dataset=' . urlencode($r['target_table'])
                     : '?action=editor&src=' . ($r['target_table'] === 'patients' ? 'live' : 'archive') . '&id=' . urlencode($r['record_id']);
        ?>
            <details class="au-entry" <?= count($rows) <= 3 ? 'open' : '' ?>>
                <summary>
                    <strong>#<?= (int)$r['id'] ?></strong>
                    <span><?= htmlspecialchars($r['edited_at']) ?></span>
                    <span><i class="fas fa-user"></i> <?= htmlspecialchars($r['user_name'] ?: $r['username']) ?> <span class="text-muted">(<?= htmlspecialchars($r['username']) ?>)</span></span>
                    <span><code><?= htmlspecialchars($r['target_table']) ?></code></span>
                    <span><strong><?= htmlspecialchars($r['record_name'] ?? '') ?></strong> <span class="text-muted"><?= htmlspecialchars($r['record_id']) ?></span>
                        <?php if ($r['old_record_id']): ?><span class="au-op">Nab’e ID <?= htmlspecialchars($r['old_record_id']) ?></span><?php endif; ?></span>
                    <span class="text-muted"><?= (int)$r['change_count'] ?> jalwachinik: <?= htmlspecialchars($r['changed_fields']) ?></span>
                </summary>
                <table class="au-diff">
                    <thead><tr><th>Ucholaj</th><th></th><th>Nab’e</th><th>Chi rij</th></tr></thead>
                    <tbody>
                    <?php foreach ($changes as $ch): ?>
                        <tr>
                            <td class="p"><?= htmlspecialchars($ch['path']) ?></td>
                            <td><span class="au-op"><?= htmlspecialchars($ch['op']) ?></span></td>
                            <td class="o"><?= $ch['op'] === 'added' ? '' : editorAuditValue($ch['old']) ?></td>
                            <td class="n"><?= $ch['op'] === 'removed' ? '' : editorAuditValue($ch['new']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <?php if ($side): ?>
                    <div class="au-meta"><strong>Jun chik xk’ulmataj:</strong> <?= editorAuditValue($side) ?></div>
                <?php endif; ?>
                <div class="au-meta">
                    IP <?= htmlspecialchars((string)$r['ip']) ?> &middot; chak <?= htmlspecialchars(getRoleName((string)$r['user_role'])) ?>
                    &middot; <span title="<?= htmlspecialchars((string)$r['user_agent']) ?>">browser</span>
                </div>
                <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px;">
                    <a class="btn btn-sm" href="?action=editor&audit_json=<?= (int)$r['id'] ?>&which=before"><i class="fas fa-download"></i> Nab’e (JSON)</a>
                    <a class="btn btn-sm" href="?action=editor&audit_json=<?= (int)$r['id'] ?>&which=after"><i class="fas fa-download"></i> Chi rij (JSON)</a>
                    <a class="btn btn-sm" href="?action=editor&audit_json=<?= (int)$r['id'] ?>&which=changes"><i class="fas fa-download"></i> Jalwachinik (JSON)</a>
                    <a class="btn btn-sm" href="?action=editor&history=1&rid=<?= urlencode($r['record_id']) ?>">Ronoj utzirisanik pa we tz’ib’ ri’</a>
                    <a class="btn btn-sm btn-primary" href="<?= htmlspecialchars($editUrl) ?>"><i class="fas fa-pen"></i> Chajaqa pa ajutzirisanel</a>
                </div>
            </details>
        <?php endforeach; ?>
        <?php if (!$rows && $error === ''): ?><div class="card text-muted">Maja k’o utzirisanik tz’ib’am<?= $where ? ' che we ch’ayb’al ri’' : ' k’a kamik' ?>.</div><?php endif; ?>

        <?php if ($pages > 1): ?>
            <div class="pagination">
                <?php for ($i = 1; $i <= $pages; $i++): ?>
                    <a href="?<?= htmlspecialchars($qs) ?>&page=<?= $i ?>" class="page-link <?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
                <?php endfor; ?>
            </div>
        <?php endif; ?>
    </div>
<?php
    showFooter();
}

// Number of audited edits for one record (shown on the record editor)
function editorAuditCount($recordId) {
    try {
        editorAuditEnsure();
        $s = db()->prepare("SELECT COUNT(*) FROM editor_audit WHERE record_id = ? OR old_record_id = ?");
        $s->execute([$recordId, $recordId]);
        return (int)$s->fetchColumn();
    } catch (Throwable $e) {
        return 0;
    }
}

function handleEditorPost() {
    if (!can('admin')) { showError('Xq’ataj ri b’ixikil'); exit; }
    if (isset($_POST['editor_save_patient'])) editorSavePatient();
    if (isset($_POST['editor_save_dataset'])) editorSaveDataset();
    editorRedirect('');
}

function showEditor() {
    if (!can('admin')) { showError('Xq’ataj ri b’ixikil'); exit; }
    try { editorAuditEnsure(); editorAuditImportFallback(); } catch (Throwable $e) { /* shown on the history page */ }
    if (isset($_GET['audit_json'])) { editorAuditDownload(); return; }
    if (!empty($_GET['history'])) { showEditorHistory(); return; }
    $src = $_GET['src'] ?? '';
    $id = (string)($_GET['id'] ?? '');
    $dataset = (string)($_GET['dataset'] ?? '');
    $draft = $_SESSION['editor_draft'] ?? null;
    unset($_SESSION['editor_draft']);

    if ($id !== '' && in_array($src, ['live', 'archive'], true)) {
        $rec = editorLoad($src, $id, (string)($_GET['ref'] ?? ''));
        if (!$rec) { $_SESSION['error'] = 'Man xriqitaj ta ri tz’ib’ re yawab’'; editorRedirect(''); }
        showEditorRecord('patient', $rec['data'], $draft, [
            'src' => $src, 'id' => $id, 'ref' => $rec['ref'],
            'title' => ($rec['data']['name'] ?? $id) . ' (' . $id . ')',
            'where' => $src === 'live' ? 'Tabla patients' : 'Tabla detached_patients (wuqq q’ij re yakb’al ' . ($rec['row']['archive_week'] ?? '?') . ')',
        ]);
        return;
    }
    $sets = editorDatasets();
    if (isset($sets[$dataset])) {
        showEditorRecord('dataset', readJSONFile($sets[$dataset]['file']), $draft, [
            'dataset' => $dataset, 'title' => $sets[$dataset]['label'], 'where' => 'Mulam retal ' . $sets[$dataset]['label'],
        ]);
        return;
    }
    showEditorList();
}

function showEditorList() {
    $q = trim((string)($_GET['q'] ?? ''));
    $scope = $_GET['scope'] ?? 'all';
    $rows = [];
    if ($scope !== 'archive') {
        foreach (readJSONFile($GLOBALS['pF']) as $pt) {
            if (is_array($pt)) $rows[] = ['src' => 'live', 'ref' => '', 'p' => $pt];
        }
    }
    if ($scope !== 'live') {
        foreach (db()->query("SELECT id, data_rot47 FROM detached_patients") as $r) {
            $pt = json_decode(str_rot47((string)$r['data_rot47']), true);
            if (is_array($pt)) $rows[] = ['src' => 'archive', 'ref' => sha1((string)$r['data_rot47']), 'p' => $pt];
        }
    }
    if ($q !== '') {
        $rows = array_values(array_filter($rows, function ($r) use ($q) {
            return stripos((string)($r['p']['id'] ?? ''), $q) !== false || stripos((string)($r['p']['name'] ?? ''), $q) !== false;
        }));
    }
    usort($rows, function ($a, $b) {
        return strcmp((string)($b['p']['admit_date'] ?? ''), (string)($a['p']['admit_date'] ?? ''));
    });
    $total = count($rows);
    $rows = array_slice($rows, 0, 300);
    showHeader();
?>
    <div class="container">
        <div class="card" style="margin-bottom:20px;">
            <h2><i class="fas fa-code"></i> Ajutzirisanel</h2>
            <p class="text-muted">Chutzirisaj ronoj tz’ib’ JSON re jun yawab’ - b’i’aj, q’ij re alaxik, ja, wachinem, retal elib’al, ub’e q’ij, wujkunab’al, ronojel.
                Ri yawab’ kechakun yakom pa <code>patients</code>, ri yakom pa <code>detached_patients</code>. Ronoj jalwachinik katz’ib’ax.</p>
            <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
                <input type="hidden" name="action" value="editor">
                <input type="text" name="q" value="<?= htmlspecialchars($q) ?>" placeholder="Chatzukuj ID o b’i’aj" style="flex:1;min-width:200px;">
                <select name="scope">
                    <option value="all" <?= $scope === 'all' ? 'selected' : '' ?>>Kechakun + yakom</option>
                    <option value="live" <?= $scope === 'live' ? 'selected' : '' ?>>Kechakun (patients)</option>
                    <option value="archive" <?= $scope === 'archive' ? 'selected' : '' ?>>Yakom (detached_patients)</option>
                </select>
                <button class="btn btn-primary" type="submit"><i class="fas fa-search"></i> Chatzukuj</button>
                <?php if ($q !== '' || $scope !== 'all'): ?><a class="btn" href="?action=editor">Chesaj</a><?php endif; ?>
                <a class="btn" href="?action=editor&history=1"><i class="fas fa-history"></i> Ub’e tzukunik</a>
            </form>
        </div>

        <div class="card" style="margin-bottom:20px;">
            <h3>Yawab’ <small class="text-muted">(<?= $total ?><?= $total > 300 ? ', kak’ut ri nab’e 300 - chach’uti’ ri tzukunik' : '' ?>)</small></h3>
            <div style="overflow-x:auto;">
            <table class="table" style="width:100%;">
                <thead><tr><th>ID</th><th>B’i’aj</th><th>Wachinem</th><th>Ja</th><th>Xok</th><th>Xel</th><th>Yakon pa</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($rows as $r): $p = $r['p']; ?>
                    <tr>
                        <td><code><?= htmlspecialchars((string)($p['id'] ?? '')) ?></code></td>
                        <td><?= htmlspecialchars((string)($p['name'] ?? '')) ?></td>
                        <td><?= htmlspecialchars((string)($p['status'] ?? '')) ?></td>
                        <td><?= htmlspecialchars((string)($p['room_num'] ?? '')) ?></td>
                        <td><?= htmlspecialchars((string)($p['admit_date'] ?? '')) ?></td>
                        <td><?= htmlspecialchars((string)($p['discharge_date'] ?? '')) ?></td>
                        <td><?= $r['src'] === 'live' ? 'patients' : 'yakb’al' ?></td>
                        <td><a class="btn btn-sm btn-primary" href="?action=editor&src=<?= $r['src'] ?>&id=<?= urlencode((string)($p['id'] ?? '')) ?><?= $r['ref'] !== '' ? '&ref=' . $r['ref'] : '' ?>"><i class="fas fa-pen"></i> Chutzirisaj</a></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$rows): ?><tr><td colspan="8" class="text-muted">Maja k’o yawab’ xriqitaj</td></tr><?php endif; ?>
                </tbody>
            </table>
            </div>
        </div>

        <div class="card">
            <h3>Jun chik mulam retal</h3>
            <p class="text-muted">Chutzirisaj ronoj mulam retal jas jun JSON cholb’al. Ri okisanelab’ (ewal tzij, ewal MFA) kechajix pa Okisanelab’ rachi’ MFA Admin.</p>
            <div style="display:flex;gap:10px;flex-wrap:wrap;">
                <?php foreach (editorDatasets() as $k => $d): ?>
                    <a class="btn" href="?action=editor&dataset=<?= $k ?>"><i class="fas fa-database"></i> <?= htmlspecialchars($d['label']) ?></a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
<?php
    showFooter();
}

function showEditorRecord($kind, $data, $draft, $meta) {
    $json = $draft !== null ? $draft : editorJson($data);
    $rooms = $kind === 'patient' ? readJSONFile($GLOBALS['rF']) : [];
    showHeader();
?>
    <style>
        .ed-wrap { display:grid; grid-template-columns: minmax(0,1fr) 260px; gap:20px; }
        @media (max-width: 900px) { .ed-wrap { grid-template-columns: 1fr; } }
        .ed-modes { display:flex; gap:6px; margin:10px 0; flex-wrap:wrap; }
        .ed-modes button.active { background:#000; color:#fff; }
        #edJson { width:100%; min-height:560px; font-family:Consolas,Menlo,monospace; font-size:13px; line-height:1.45; tab-size:2; white-space:pre; }
        #edStatus { font-size:13px; margin-left:8px; }
        #edStatus.ok { color:#1a7f37; } #edStatus.bad { color:#c00; }
        .ed-node { border-left:2px solid #ddd; margin:4px 0 4px 6px; padding-left:10px; }
        .ed-node > summary { cursor:pointer; font-weight:600; padding:3px 0; }
        .ed-row { display:flex; gap:6px; align-items:flex-start; margin:4px 0; flex-wrap:wrap; }
        .ed-key { min-width:150px; max-width:220px; font-family:monospace; font-size:13px; padding-top:6px; word-break:break-all; }
        .ed-row input.ed-keyin { width:150px; font-family:monospace; }
        .ed-val { flex:1; min-width:180px; }
        .ed-val textarea { width:100%; min-height:60px; }
        .ed-val input[type=text], .ed-val input[type=number] { width:100%; }
        .ed-type { width:85px; font-size:12px; }
        .ed-x { background:none; border:1px solid #ccc; border-radius:4px; cursor:pointer; padding:2px 8px; color:#c00; }
        .ed-add { font-size:12px; margin:4px 0; }
        .ed-side .card { margin-bottom:15px; font-size:13px; }
        .ed-side table td { padding:2px 6px; }
    </style>
    <div class="container">
        <div style="margin-bottom:10px;"><a href="?action=editor" class="btn btn-sm">← Ajutzirisanel</a>
            <?php $auditRid = $kind === 'patient' ? $meta['id'] : $meta['dataset']; $auditN = editorAuditCount($auditRid); ?>
            <a href="?action=editor&history=1&rid=<?= urlencode($auditRid) ?>" class="btn btn-sm"><i class="fas fa-history"></i> Ojer re utzirisanik (<?= $auditN ?>)</a>
            <?php if ($kind === 'patient' && $meta['src'] === 'live'): ?>
                <a href="?action=view&id=<?= urlencode($meta['id']) ?>" class="btn btn-sm">Chawila yawab’</a>
            <?php elseif ($kind === 'patient'): ?>
                <a href="?action=view_discharged&id=<?= urlencode($meta['id']) ?>" class="btn btn-sm">Chawila yawab’ yakom</a>
            <?php endif; ?>
        </div>
        <div class="ed-wrap">
        <div class="card">
            <h2><i class="fas fa-code"></i> <?= htmlspecialchars($meta['title']) ?></h2>
            <p class="text-muted"><?= htmlspecialchars($meta['where']) ?></p>
            <?php if ($draft !== null): ?><div class="alert alert-warning">Kak’ut ri tz’ib’ xatäq, man are ta ri yakom.</div><?php endif; ?>

            <form method="POST" action="?action=editor" id="edForm">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <input type="hidden" name="hash" value="<?= editorHash($data) ?>">
                <?php if ($kind === 'patient'): ?>
                    <input type="hidden" name="editor_save_patient" value="1">
                    <input type="hidden" name="src" value="<?= htmlspecialchars($meta['src']) ?>">
                    <input type="hidden" name="id" value="<?= htmlspecialchars($meta['id']) ?>">
                    <input type="hidden" name="ref" value="<?= htmlspecialchars($meta['ref']) ?>">
                <?php else: ?>
                    <input type="hidden" name="editor_save_dataset" value="1">
                    <input type="hidden" name="dataset" value="<?= htmlspecialchars($meta['dataset']) ?>">
                <?php endif; ?>

                <div class="ed-modes">
                    <button type="button" class="btn btn-sm active" data-mode="form"><i class="fas fa-list"></i> Wuj</button>
                    <button type="button" class="btn btn-sm" data-mode="json"><i class="fas fa-code"></i> JSON</button>
                    <button type="button" class="btn btn-sm" id="edFormat">Ucholajil JSON</button>
                    <span id="edStatus"></span>
                </div>

                <div id="edTree"></div>
                <textarea name="json" id="edJson" spellcheck="false" style="display:none;"><?= htmlspecialchars($json) ?></textarea>

                <?php if ($kind === 'patient' && $meta['src'] === 'live'): ?>
                    <div style="margin-top:15px;">
                        <label style="display:block;"><input type="checkbox" name="sync_room" value="1" checked> Chaya <code>room_num</code> re <code>room_id</code></label>
                        <label style="display:block;"><input type="checkbox" name="recalc_occ" value="1" checked> Chajilaj chi jun mul ri okinaq ja (warab’al kokisax) chi rij ri yakik</label>
                    </div>
                <?php elseif ($kind === 'patient'): ?>
                    <p class="text-muted" style="margin-top:15px;">Ri tz’ib’ kk’oji pa ri yakb’al. Che ub’anik chi jun mul jun yawab’ kachakun chakuj <a href="?action=readmit&id=<?= urlencode($meta['id']) ?>">Chatzalij pa yawab’</a>.</p>
                <?php endif; ?>

                <div style="display:flex;gap:10px;margin-top:20px;">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Chayaka’</button>
                    <a href="" class="btn">Chajotesaj chi jun mul</a>
                    <a href="?action=editor" class="btn">Chatanab’a</a>
                </div>
            </form>
        </div>

        <div class="ed-side">
            <div class="card">
                <strong>Pixab’</strong>
                <ul style="padding-left:18px;margin:6px 0;">
                    <li><b>Wuj</b> kutzirisaj chi jujun ucholaj; chakuj ri cholb’al ruk’ojlem che rujalwachixik ri ajilab’al pa tz’ib’, ajilab’al, je’/man, cholb’al, jastaq o maja k’o (null).</li>
                    <li><b>JSON</b> kuk’ut ri tz’ib’ jas k’o wi; ronojel kajalwachix chila’.</li>
                    <li>Ri q’ij kakokisaj <code>YYYY-MM-DD HH:MM:SS</code>.</li>
                    <?php if ($kind === 'patient'): ?><li>Jalwachinik <code>id</code> kujach ri wachib’al yawab’.</li><?php endif; ?>
                </ul>
            </div>
            <?php if ($kind === 'patient' && $rooms): ?>
            <div class="card">
                <strong>Taq ja (room_id → num)</strong>
                <table>
                    <?php foreach ($rooms as $rm): ?>
                        <tr><td><?= htmlspecialchars((string)$rm['id']) ?></td><td><?= htmlspecialchars((string)$rm['num']) ?></td>
                            <td class="text-muted"><?= htmlspecialchars(getDeptName($rm['dept'] ?? '')) ?></td>
                            <td class="text-muted"><?= (int)($rm['occ'] ?? 0) ?>/<?= (int)($rm['beds'] ?? 0) ?></td></tr>
                    <?php endforeach; ?>
                </table>
            </div>
            <div class="card">
                <strong>Kod</strong>
                <p style="margin:6px 0 2px;">wachinem: <code>admitted</code>, <code>discharged</code></p>
                <p style="margin:6px 0 2px;">achi/ixoq:</p>
                <div><?php foreach (getGenderOptions() as $c => $n): ?><code><?= htmlspecialchars($c) ?></code> <?php endforeach; ?></div>
                <p style="margin:6px 0 2px;">k’olb’al:</p>
                <div><?php foreach ($GLOBALS['depts'] as $c => $n): ?><code><?= htmlspecialchars($c) ?></code> <?php endforeach; ?></div>
            </div>
            <?php endif; ?>
        </div>
        </div>
    </div>

<script>
(function () {
    var ta = document.getElementById('edJson'), tree = document.getElementById('edTree'),
        status = document.getElementById('edStatus'), form = document.getElementById('edForm');
    var mode = 'form', model;

    function setStatus(msg, ok) { status.textContent = msg; status.className = ok ? 'ok' : 'bad'; }
    function parse() {
        try { var v = JSON.parse(ta.value); setStatus('JSON utz', true); return { ok: true, v: v }; }
        catch (e) { setStatus('JSON man utz ta: ' + e.message, false); return { ok: false }; }
    }
    function typeOf(v) {
        if (v === null) return 'null';
        if (Array.isArray(v)) return 'array';
        if (typeof v === 'object') return 'object';
        if (typeof v === 'boolean') return 'bool';
        if (typeof v === 'number') return 'number';
        return 'text';
    }
    function convert(v, t) {
        var cur = typeOf(v);
        if (cur === t) return v;
        if (t === 'null') return null;
        if (t === 'bool') return v === 'true' || v === 1 || v === '1' || v === true;
        if (t === 'number') { var n = Number(v); return isNaN(n) ? 0 : n; }
        if (t === 'array') return [];
        if (t === 'object') return {};
        return (cur === 'object' || cur === 'array') ? '' : (v === null ? '' : String(v));
    }
    function sync() { ta.value = JSON.stringify(model, null, 4); }

    function typeSelect(v, onChange) {
        var s = document.createElement('select'); s.className = 'ed-type';
        ['text', 'number', 'bool', 'null', 'object', 'array'].forEach(function (t) {
            var o = document.createElement('option'); o.value = t; o.textContent = {text: 'tz’ib’', number: 'ajilab’al', bool: 'je’/man', null: 'maja k’o', object: 'jastaq', array: 'cholb’al'}[t] || t; s.appendChild(o);
        });
        s.value = typeOf(v);
        s.onchange = function () { onChange(s.value); };
        return s;
    }

    function valueEditor(v, set) {
        var box = document.createElement('div'); box.className = 'ed-val';
        var t = typeOf(v), el;
        if (t === 'text') {
            if (v.length > 60 || v.indexOf('\n') !== -1) { el = document.createElement('textarea'); el.rows = Math.min(10, Math.max(2, v.split('\n').length)); }
            else { el = document.createElement('input'); el.type = 'text'; }
            el.value = v; el.oninput = function () { set(el.value); };
        } else if (t === 'number') {
            el = document.createElement('input'); el.type = 'number'; el.step = 'any'; el.value = v;
            el.oninput = function () { set(el.value === '' ? 0 : Number(el.value)); };
        } else if (t === 'bool') {
            el = document.createElement('label'); var cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = v;
            cb.onchange = function () { set(cb.checked); }; el.appendChild(cb); el.appendChild(document.createTextNode(' je’'));
        } else {
            el = document.createElement('span'); el.className = 'text-muted'; el.textContent = 'null (maja k’o)';
        }
        box.appendChild(el);
        return box;
    }

    // Renders one container (object or array) into parentEl
    function renderContainer(obj, parentEl, path) {
        var isArr = Array.isArray(obj);
        var keys = isArr ? obj.map(function (_, i) { return i; }) : Object.keys(obj);
        keys.forEach(function (k) {
            var v = obj[k], t = typeOf(v);
            var set = function (nv) { obj[k] = nv; sync(); };
            var del = document.createElement('button'); del.type = 'button'; del.className = 'ed-x'; del.textContent = '×';
            del.title = 'Chesaj';
            del.onclick = function () {
                if (!confirmRemove(k)) return;
                if (isArr) obj.splice(k, 1); else delete obj[k];
                sync(); render();
            };
            var label = isArr ? '#' + (k + 1) : k;
            if (t === 'object' || t === 'array') {
                var d = document.createElement('details'); d.className = 'ed-node';
                d.open = path.length < 1 || openPaths[path.concat(k).join('/')] === true;
                d.ontoggle = function () { openPaths[path.concat(k).join('/')] = d.open; };
                var sm = document.createElement('summary');
                sm.textContent = label + (t === 'array' ? '  [' + v.length + ']' : '  {' + Object.keys(v).length + '}') + '  ';
                var ts = typeSelect(v, function (nt) { obj[k] = convert(v, nt); sync(); render(); });
                ts.onclick = function (e) { e.stopPropagation(); };
                sm.appendChild(ts); sm.appendChild(document.createTextNode(' ')); sm.appendChild(del);
                d.appendChild(sm);
                renderContainer(v, d, path.concat(k));
                parentEl.appendChild(d);
            } else {
                var row = document.createElement('div'); row.className = 'ed-row';
                var kl = document.createElement('div'); kl.className = 'ed-key'; kl.textContent = label;
                row.appendChild(kl);
                row.appendChild(valueEditor(v, set));
                row.appendChild(typeSelect(v, function (nt) { obj[k] = convert(v, nt); sync(); render(); }));
                row.appendChild(del);
                parentEl.appendChild(row);
            }
        });
        // add controls
        var add = document.createElement('div'); add.className = 'ed-row ed-add';
        if (isArr) {
            var b = document.createElement('button'); b.type = 'button'; b.className = 'btn btn-sm'; b.textContent = '+ jastaq';
            b.onclick = function () {
                var tpl = obj.length && typeOf(obj[obj.length - 1]) === 'object' ? blankLike(obj[obj.length - 1]) : '';
                obj.push(tpl); openPaths[path.concat(obj.length - 1).join('/')] = true; sync(); render();
            };
            add.appendChild(b);
        } else {
            var ki = document.createElement('input'); ki.type = 'text'; ki.placeholder = 'ub’i’ k’ak’ ucholaj'; ki.className = 'ed-keyin';
            var tsel = typeSelect('', function () {});
            var b2 = document.createElement('button'); b2.type = 'button'; b2.className = 'btn btn-sm'; b2.textContent = '+ ucholaj';
            b2.onclick = function () {
                var name = ki.value.trim();
                if (!name) { ki.focus(); return; }
                if (Object.prototype.hasOwnProperty.call(obj, name)) { alertInline(add, 'Ucholaj "' + name + '" k’o chi'); return; }
                obj[name] = convert('', tsel.value); openPaths[path.concat(name).join('/')] = true; sync(); render();
            };
            add.appendChild(ki); add.appendChild(tsel); add.appendChild(b2);
        }
        parentEl.appendChild(add);
    }
    function blankLike(o) {
        var n = {}; Object.keys(o).forEach(function (k) {
            var t = typeOf(o[k]); n[k] = t === 'object' ? {} : t === 'array' ? [] : t === 'number' ? 0 : t === 'bool' ? false : t === 'null' ? null : '';
        }); return n;
    }
    function alertInline(el, msg) {
        var s = document.createElement('span'); s.style.color = '#c00'; s.textContent = ' ' + msg; el.appendChild(s);
        setTimeout(function () { s.remove(); }, 2500);
    }
    var pendingRemove = null;
    function confirmRemove(k) {
        // second click within 3 s confirms (no browser dialogs)
        if (pendingRemove === k) { pendingRemove = null; return true; }
        pendingRemove = k; setStatus('Chapitz’a’ × chi jun mul che resaxik "' + k + '"', false);
        setTimeout(function () { if (pendingRemove === k) { pendingRemove = null; setStatus('', true); } }, 3000);
        return false;
    }

    var openPaths = {};
    function render() {
        tree.innerHTML = '';
        if (typeOf(model) !== 'object' && typeOf(model) !== 'array') {
            tree.innerHTML = '<p class="text-muted">We ajilab’al ri’ man kak’ut ta jas wuj; chakuj JSON.</p>'; return;
        }
        renderContainer(model, tree, []);
    }

    function setMode(m) {
        if (m === 'form') {
            var r = parse(); if (!r.ok) return;
            model = r.v; render(); tree.style.display = ''; ta.style.display = 'none';
        } else {
            if (mode === 'form') sync();
            tree.style.display = 'none'; ta.style.display = '';
        }
        mode = m;
        document.querySelectorAll('.ed-modes [data-mode]').forEach(function (b) { b.classList.toggle('active', b.dataset.mode === m); });
    }
    document.querySelectorAll('.ed-modes [data-mode]').forEach(function (b) { b.onclick = function () { setMode(b.dataset.mode); }; });
    document.getElementById('edFormat').onclick = function () {
        if (mode === 'form') sync();
        var r = parse(); if (r.ok) ta.value = JSON.stringify(r.v, null, 4);
    };
    ta.addEventListener('input', parse);
    form.addEventListener('submit', function (e) {
        if (mode === 'form') sync();
        if (!parse().ok) { e.preventDefault(); setMode('json'); }
    });

    var first = parse();
    if (first.ok) { model = first.v; render(); } else { setMode('json'); }
})();
</script>
<?php
    showFooter();
}

function showError($m) {
    showHeader();
?>
    <div class="container">
        <div style="max-width:600px; margin:50px auto;">
            <div class="card" style="text-align:center; border-color:var(--primary);">
                <h2>Sach</h2>
                <p style="margin:var(--spacing-xl) 0;"><?= htmlspecialchars($m) ?></p>
                <a href="./" class="btn btn-primary">Chatzalij pa Ja</a>
            </div>
        </div>
    </div>
<?php
    showFooter();
}
?>