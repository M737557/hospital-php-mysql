<?php
// ==================== HOSPITAL PATIENT MANAGEMENT SYSTEM ====================
// CONFIGURATION FILE - Version 2.1 (Õnnõ võro keelen)
// ============================================================================

// ==================== HOSPITAL INFORMATION ====================
define('HOSPITAL_NAME', 'LINNA ÜLDINE HAIGÕMAJA');
define('HOSPITAL_ADDRESS', '123 Medical Center Blvd, Tervüselinn');
define('HOSPITAL_PHONE', '+1 (555) 123-4567');
define('HOSPITAL_WEBSITE', 'www.citygeneral.org');
define('HOSPITAL_LOGO', 'logo.png');

// ==================== APPLICATION SETTINGS ====================
define('APP_NAME', 'Haigidõ juhtmisõ süsteem');
define('APP_VERSION', '2.1.0');
define('DATE_FORMAT', 'Y-m-d H:i:s');
define('DATE_SHORT', 'Y-m-d');
define('DATE_DISPLAY', 'M d, Y H:i');
define('TIME_FORMAT', 'H:i:s');
define('LOG_DATE_FORMAT', 'Y-m-d H:i:s');

// Time zone for PHP AND the MySQL session (db.php sets the same offset on every connection).
// The MySQL event scheduler uses the server's own time zone, so set that to the same zone:
//   my.cnf: default-time-zone = 'Europe/Amsterdam'   (needs the tz tables: mysql_tzinfo_to_sql)
define('APP_TIMEZONE', 'Europe/Amsterdam');
date_default_timezone_set(APP_TIMEZONE);

// ==================== GENDER CONFIGURATION ====================
// Configure gender options for the system
// Format: 'code' => 'Display Name'
$genders = [
    'male' => 'Mii’s',
    'female' => 'Naane',
    'transgender_mtf' => 'Transgender (MTF)',
    'transgender_ftm' => 'Transgender (FTM)',
    'non_binary' => 'Mittebinaarnõ',
    'genderqueer' => 'Genderqueer',
    'intersex' => 'Intersex',
    'other' => 'Muu',
    'prefer_not_to_say' => 'Ei taha üteldä'
];

// Set which gender options are enabled by default
define('DEFAULT_GENDER', 'prefer_not_to_say');

// Gender display settings
define('GENDER_REQUIRED', true);                    // Make gender selection required
define('GENDER_SHOW_IN_PATIENT_LIST', true);        // Show gender in patient lists
define('GENDER_SHOW_IN_STATISTICS', true);          // Include gender in statistics

// Additional patient demographics (optional)
define('COLLECT_ETHNICITY', false);                  // Enable ethnicity collection
define('COLLECT_OCCUPATION', false);                 // Enable occupation collection
define('COLLECT_MARITAL_STATUS', false);              // Enable marital status collection

// ==================== MYSQL DATABASE ====================
// All application data (patients, de-attached patients, rooms, users, telephones,
// medications, statistics) is stored in MySQL. Create the tables with sql/schema.sql,
// or run `php migrate.php` once to create them AND import the old data/*.json files.
define('DB_HOST', getenv('HOSPITAL_DB_HOST') ?: '127.0.0.1');
define('DB_PORT', (int)(getenv('HOSPITAL_DB_PORT') ?: 3306));
define('DB_NAME', getenv('HOSPITAL_DB_NAME') ?: 'hospital');
define('DB_USER', getenv('HOSPITAL_DB_USER') ?: 'root');
define('DB_PASS', getenv('HOSPITAL_DB_PASS') ?: '');   // set a real password (or the env var)
define('DB_CHARSET', 'utf8mb4');

// ==================== FILE PATHS ====================
// The *_FILE constants below are kept as identifiers: index.php still passes them to
// readJSONFile()/writeJSONFile(), which db.php maps to the matching MySQL table.
// Only the activity log, rate limit file, photos and PDFs are still real files.
define('DATA_DIR', __DIR__ . '/data/');
define('PATIENTS_FILE', DATA_DIR . 'patients.json');
define('ROOMS_FILE', DATA_DIR . 'rooms.json');
define('USERS_FILE', DATA_DIR . 'users.json');
define('TELEPHONES_FILE', DATA_DIR . 'telephones.json');
define('MEDICATIONS_FILE', DATA_DIR . 'medications.json');
define('STATISTICS_FILE', DATA_DIR . 'statistics.json');
define('ACTIVITY_LOG', DATA_DIR . 'activity.log');
define('RATE_LIMIT_FILE', DATA_DIR . 'rate_limit.json');
define('LAST_DETACH_FILE', DATA_DIR . 'last_detach.txt');
define('DISCHARGED_DIR', DATA_DIR . 'discharged/');
define('PHOTO_DIR', DATA_DIR . 'patient_photos/');

// ==================== CREATE DATA DIRECTORY ====================
if (!file_exists(DATA_DIR)) {
    mkdir(DATA_DIR, 0755, true);
}

// Default rooms: inserted into the MySQL table `rooms` when it is empty (first start)
function defaultRooms() {
    return [
        ['id' => 1, 'num' => '101', 'dept' => 'emergency', 'beds' => 4, 'occ' => 0],
        ['id' => 2, 'num' => '102', 'dept' => 'emergency', 'beds' => 4, 'occ' => 0],
        ['id' => 3, 'num' => '201', 'dept' => 'cardiology', 'beds' => 3, 'occ' => 0],
        ['id' => 4, 'num' => '202', 'dept' => 'cardiology', 'beds' => 3, 'occ' => 0],
        ['id' => 5, 'num' => '301', 'dept' => 'pediatrics', 'beds' => 4, 'occ' => 0],
        ['id' => 6, 'num' => '302', 'dept' => 'pediatrics', 'beds' => 4, 'occ' => 0],
        ['id' => 7, 'num' => '401', 'dept' => 'icu', 'beds' => 2, 'occ' => 0],
        ['id' => 8, 'num' => '402', 'dept' => 'icu', 'beds' => 2, 'occ' => 0],
        ['id' => 9, 'num' => '501', 'dept' => 'surgery', 'beds' => 3, 'occ' => 0],
        ['id' => 10, 'num' => '502', 'dept' => 'surgery', 'beds' => 3, 'occ' => 0],
    ];
}

// Default users: inserted into the MySQL table `users` when it is empty (first start)
function defaultUsers() {
    return [
        [
            'user' => 'admin',
            'pass' => password_hash('admin123', PASSWORD_DEFAULT, ['cost' => 12]),
            'role' => 'admin',
            'mfa' => 0,
            'secret' => '',
            'name' => 'Süsteemi administraator',
            'email' => 'admin@hospital.org',
            'created' => date('Y-m-d H:i:s'),
            'last_login' => null,
            'active' => 1
        ],
        [
            'user' => 'doctor',
            'pass' => password_hash('doctor123', PASSWORD_DEFAULT, ['cost' => 12]),
            'role' => 'doctor',
            'mfa' => 0,
            'secret' => '',
            'name' => 'John Smith, MD',
            'email' => 'doctor@hospital.org',
            'created' => date('Y-m-d H:i:s'),
            'last_login' => null,
            'active' => 1
        ],
        [
            'user' => 'nurse',
            'pass' => password_hash('nurse123', PASSWORD_DEFAULT, ['cost' => 12]),
            'role' => 'nurse',
            'mfa' => 0,
            'secret' => '',
            'name' => 'Sarah Johnson, RN',
            'email' => 'nurse@hospital.org',
            'created' => date('Y-m-d H:i:s'),
            'last_login' => null,
            'active' => 1
        ],
        [
            'user' => 'reception',
            'pass' => password_hash('reception123', PASSWORD_DEFAULT, ['cost' => 12]),
            'role' => 'reception',
            'mfa' => 0,
            'secret' => '',
            'name' => 'Maria Garcia',
            'email' => 'reception@hospital.org',
            'created' => date('Y-m-d H:i:s'),
            'last_login' => null,
            'active' => 1
        ]
    ];
}

// ==================== ENCRYPTION SETTINGS ====================
// Patient records (tables `patients` and `detached_patients`) are ALWAYS stored ROT47-encoded
// in MySQL (column data_rot47). These flags are kept for older code paths.
define('ENCRYPT_PATIENTS', true);
define('ENCRYPT_ARCHIVES', true);

// ==================== AUTO ARCHIVE SETTINGS ====================
define('AUTO_ARCHIVE_ENABLED', true);
// Weekly de-attach: every DETACHMENT_WEEKDAY at DETACHMENT_HOUR:00 (0 = Sunday ... 6 = Saturday).
// All discharged patients are moved from the MySQL table `patients` to `detached_patients`.
// The MySQL event `ev_weekly_detach` does this on Sunday 00:00 (needs event_scheduler=ON).
// As a safety net, index.php runs the same procedure on the first page load after that
// moment when the event did not run. If you change these values, also change the event's
// schedule in sql/schema.sql.
define('DETACHMENT_WEEKDAY', 0);
define('DETACHMENT_HOUR', 0);
// Delete the patient photos of archived patients in the same weekly run
define('PHOTO_DELETE_ON_ARCHIVE', true);

// ==================== PHOTO SETTINGS ====================
define('MAX_PHOTO_SIZE', 5 * 1024 * 1024);
define('PHOTO_RETENTION_DAYS', 365);
define('PHOTO_CREATE_THUMBNAIL', true);
define('PHOTO_THUMB_SIZE', 150);
define('ALLOWED_PHOTO_TYPES', ['image/png', 'image/jpeg', 'image/webp']);  // non-PNG is converted to PNG on upload

// ==================== SECURITY SETTINGS ====================
define('SESSION_TIMEOUT', 3600);
define('SESSION_REGENERATE', 1800);
define('CSRF_TOKEN_LENGTH', 32);
define('BCRYPT_COST', 12);
define('PASSWORD_MIN_LENGTH', 8);
define('PASSWORD_REQUIRE_UPPER', true);
define('PASSWORD_REQUIRE_LOWER', true);
define('PASSWORD_REQUIRE_NUMBER', true);
define('PASSWORD_REQUIRE_SPECIAL', true);
define('RATE_LIMIT_ATTEMPTS', 5);
define('RATE_LIMIT_WINDOW', 900);
define('MFA_ISSUER', 'CityGeneral');
define('MFA_ENFORCE', false);
// Soft-token login: when true, the login page asks ONLY for the 6-digit authenticator
// (TOTP) code. No username or password. The code is matched against every active user's
// secret in the MySQL users table. Set to false to restore username + password login.
define('SOFTTOKEN_ONLY', true);

// ==================== LOGGING SETTINGS ====================
define('LOG_MAX_SIZE', 10 * 1024 * 1024);
define('LOG_RETENTION_DAYS', 30);

// ==================== PAGINATION SETTINGS ====================
define('MAX_PATIENTS_PER_PAGE', 20);
define('MAX_PHOTOS_PER_PAGE', 50);

// ==================== DEPARTMENT DEFINITIONS ====================
$depts = [
    'emergency' => 'Hädäabi osakund',
    'cardiology' => 'Kardioloogia',
    'neurology' => 'Neuroloogia',
    'pediatrics' => 'Pediaatria',
    'oncology' => 'Onkoloogia',
    'orthopedics' => 'Ortopeedia',
    'surgery' => 'Üldine kirurgia',
    'icu' => 'Intensiivravi osakund',
    'nicu' => 'Vahtsõst sündünü latsõq ICU',
    'radiology' => 'Radioloogia',
    'psychiatry' => 'Psühhiaatria',
    'obgyn' => 'Sünnütüs & günekoloogia',
    'nephrology' => 'Nefroloogia',
    'pulmonology' => 'Pulmonoloogia',
    'gastroenterology' => 'Gastroenteroloogia',
    'endocrinology' => 'Endokrinoloogia',
    'hematology' => 'Hematoloogia',
    'infectious' => 'Nakkushaigusõq',
    'rheumatology' => 'Reumatoloogia',
    'dermatology' => 'Dermatoloogia',
    'ophthalmology' => 'Oftalmoloogia',
    'ent' => 'Kõrvaq, nõna & kurk',
    'urology' => 'Uroloogia',
    'general' => 'Üldine meditsiin',
    'rehab' => 'Taastusravi',
    'palliative' => 'Palliatiivravi'
];

// ==================== STANDARD DISCHARGE MEDICATIONS (SEED LIST) ====================
// Only used ONCE to fill data/medications.json the first time. After that the list is
// managed in the app (tab "Medications") and the discharge form reads it from that file.
// Format: 'Category' => [ 'Medication' => ['available strengths/forms', ...], ... ]
// Add or remove entries here; the dropdown updates automatically.
// NOTE: only name + available strengths are suggested. Dose, frequency and duration
// are always entered by the prescriber (patients range from infants to adults).
$standardMeds = [
    'Kipõ & palavik' => [
        'Paracetamol'   => ['500 mg tablett', '1000 mg tablett', '120 mg/5 ml suspensioon', '125 mg küünlak'],
        'Ibuprofen'     => ['200 mg tablett', '400 mg tablett', '100 mg/5 ml suspensioon'],
        'Diclofenac'    => ['25 mg tablett', '50 mg tablett', '75 mg tablettt SR'],
        'Naproxen'      => ['250 mg tablett', '500 mg tablett'],
        'Tramadol'      => ['50 mg kapsel', '100 mg tablettt SR'],
        'Morphine'      => ['10 mg tablett', '10 mg/5 ml juuas lahus'],
    ],
    'Antibiootikumiq' => [
        'Amoxicillin'                 => ['250 mg kapsel', '500 mg kapsel', '250 mg/5 ml suspensioon'],
        'Amoxicillin/Clavulanic acid' => ['500/125 mg tablett', '875/125 mg tablett'],
        'Flucloxacillin'              => ['500 mg kapsel', '250 mg/5 ml suspensioon'],
        'Doxycycline'                 => ['100 mg kapsel'],
        'Azithromycin'                => ['250 mg tablett', '500 mg tablett'],
        'Nitrofurantoin'              => ['50 mg tablett', '100 mg kapsel MR'],
        'Ciprofloxacin'               => ['250 mg tablett', '500 mg tablett'],
    ],
    'Süä ja verisoonõq' => [
        'Acetylsalicylic acid (Aspirin)' => ['80 mg tablett', '100 mg tablett'],
        'Clopidogrel'    => ['75 mg tablett'],
        'Metoprolol'     => ['50 mg tablett', '100 mg tablett', '100 mg tablettt SR'],
        'Bisoprolol'     => ['2.5 mg tablett', '5 mg tablett', '10 mg tablett'],
        'Lisinopril'     => ['5 mg tablett', '10 mg tablett', '20 mg tablett'],
        'Amlodipine'     => ['5 mg tablett', '10 mg tablett'],
        'Furosemide'     => ['20 mg tablett', '40 mg tablett'],
        'Atorvastatin'   => ['10 mg tablett', '20 mg tablett', '40 mg tablett'],
        'Simvastatin'    => ['20 mg tablett', '40 mg tablett'],
        'Apixaban'       => ['2.5 mg tablett', '5 mg tablett'],
        'Nitroglycerin (GTN) spray' => ['0.4 mg/annus spray'],
    ],
    'Kõtt ja suulõq' => [
        'Omeprazole'     => ['20 mg kapsel', '40 mg kapsel'],
        'Pantoprazole'   => ['20 mg tablett', '40 mg tablett'],
        'Metoclopramide' => ['10 mg tablett'],
        'Ondansetron'    => ['4 mg tablett', '8 mg tablett'],
        'Lactulose'      => ['667 mg/ml siirup'],
        'Macrogol'       => ['kotikõnõ'],
    ],
    'Hingämine & allergia' => [
        'Salbutamol inhaler' => ['100 mcg/annus'],
        'Budesonide inhaler' => ['200 mcg/annus'],
        'Prednisolone'       => ['5 mg tablett', '20 mg tablett'],
        'Cetirizine'         => ['10 mg tablett', '5 mg/5 ml lahus'],
        'Loratadine'         => ['10 mg tablett'],
    ],
    'Diabeet & endokriin' => [
        'Metformin'       => ['500 mg tablett', '850 mg tablett', '1000 mg tablett'],
        'Gliclazide'      => ['30 mg tablettt MR', '80 mg tablett'],
        'Insuliin (kirotõdu perrä)' => ['100 IU/ml'],
        'Levothyroxine'   => ['25 mcg tablett', '50 mcg tablett', '100 mcg tablett'],
    ],
    'Närviq & psühhika' => [
        'Diazepam'      => ['2 mg tablett', '5 mg tablett'],
        'Lorazepam'     => ['1 mg tablett'],
        'Levetiracetam' => ['500 mg tablett', '1000 mg tablett'],
        'Sertraline'    => ['50 mg tablett', '100 mg tablett'],
    ],
    'Muu' => [
        'Potassium chloride' => ['600 mg tablettt SR'],
        'Folic acid'         => ['0.4 mg tablett', '5 mg tablett'],
        'Vitamin D3'         => ['800 IU tablett', '25.000 IU ampoule'],
        'Iron (ferrous fumarate)' => ['200 mg tablett'],
    ],
];

// Common choices offered as suggestions (the field stays editable)
$standardFrequencies = ['Üts kõrd päävän', 'Kats kõrda päävän', '3 kõrda päävän', '4 kõrda päävän', 'Egä 4 tunni', 'Egä 6 tunni', 'Egä 8 tunni', 'Egä 12 tunni', 'Üüse', 'Hummogu', 'Ku vaia (PRN)', 'Üts annus'];
$standardDurations   = ['1 päiv', '3 päävä', '5 päävä', '7 päävä', '10 päävä', '14 päävä', '1 kuu', '3 kuuq', 'Lõpuni', 'Järgmädse kontrolli niipiten', 'Kestüs / krooniline'];

function getStandardMeds() {
    global $standardMeds;
    return $standardMeds;
}

// ==================== ROLE DEFINITIONS ====================
$roles = [
    'admin' => [
        'name' => 'Administraator',
        'perms' => ['view', 'admit', 'discharge', 'edit', 'move', 'manage', 'logs', 'admin', 'stats', 'telephone', 'mfa_admin', 'user_admin', 'meds']
    ],
    'doctor' => [
        'name' => 'Tohtri',
        'perms' => ['view', 'admit', 'discharge', 'edit', 'move', 'logs', 'stats', 'telephone', 'meds']
    ],
    'nurse' => [
        'name' => 'Hoitja',
        'perms' => ['view', 'admit', 'edit', 'move', 'logs', 'telephone']
    ],
    'reception' => [
        'name' => 'Registraator',
        'perms' => ['view', 'admit', 'telephone']
    ],
    'manager' => [
        'name' => 'Osakunna juht',
        'perms' => ['view', 'admit', 'discharge', 'edit', 'move', 'stats', 'logs', 'meds']
    ],
    'tech' => [
        'name' => 'Tehnik',
        'perms' => ['view', 'telephone']
    ],
    'auditor' => [
        'name' => 'Audiitor',
        'perms' => ['view', 'logs', 'stats']
    ]
];

// ==================== GENDER HELPER FUNCTION ====================
function getGenderName($code) {
    global $genders;
    return $genders[$code] ?? $code;
}

function getGenderOptions() {
    global $genders;
    return $genders;
}

function getDefaultGender() {
    return DEFAULT_GENDER;
}

function isGenderRequired() {
    return GENDER_REQUIRED;
}

function shouldShowGenderInList() {
    return GENDER_SHOW_IN_PATIENT_LIST;
}

function shouldIncludeGenderInStats() {
    return GENDER_SHOW_IN_STATISTICS;
}

// Helper functions for common lookups
function getDeptName($code) {
    global $depts;
    return $depts[$code] ?? $code;
}

function getRoleName($role) {
    global $roles;
    return $roles[$role]['name'] ?? $role;
}

function generatePatientId() {
    return 'P' . strtoupper(substr(uniqid(), -7));
}

function now() {
    return date(DATE_FORMAT);
}

function formatDate($date) {
    return date(DATE_DISPLAY, strtotime($date));
}

function formatDateShort($date) {
    return date(DATE_SHORT, strtotime($date));
}

function shouldRunAutoArchive() {
    return AUTO_ARCHIVE_ENABLED && (int)date('w') == DETACHMENT_WEEKDAY && (int)date('G') == DETACHMENT_HOUR;
}

// Human readable schedule, e.g. "every Sunday at 00:00"
function archiveScheduleText() {
    $days = ['Pühäpäiv', 'Iispäiv', 'Tõõsõpäiv', 'Kolmapäiv', 'Nelläpäiv', 'Riidi', 'Puulpäiv'];
    return 'egä ' . $days[DETACHMENT_WEEKDAY % 7] . ' aol ' . sprintf('%02d:00', DETACHMENT_HOUR);
}

// Most recent scheduled archive moment at or before $now
function lastArchiveBoundary($now = null) {
    $now = $now ?? time();
    $back = ((int)date('w', $now) - DETACHMENT_WEEKDAY + 7) % 7;
    $b = mktime(DETACHMENT_HOUR, 0, 0, (int)date('n', $now), (int)date('j', $now) - $back, (int)date('Y', $now));
    if ($b > $now) {
        $b = mktime(DETACHMENT_HOUR, 0, 0, (int)date('n', $now), (int)date('j', $now) - $back - 7, (int)date('Y', $now));
    }
    return $b;
}

// Next scheduled archive moment after $now
function nextArchiveRun($now = null) {
    $b = lastArchiveBoundary($now);
    return mktime(DETACHMENT_HOUR, 0, 0, (int)date('n', $b), (int)date('j', $b) + 7, (int)date('Y', $b));
}

function iniBytes($v) {
    $v = trim((string)$v);
    if ($v === '') return 0;
    $unit = strtolower(substr($v, -1));
    $n = (float)$v;
    if ($unit === 'g') $n *= 1073741824;
    elseif ($unit === 'm') $n *= 1048576;
    elseif ($unit === 'k') $n *= 1024;
    return (int)$n;
}

// The real limit is the smallest of MAX_PHOTO_SIZE and the PHP server limits
// (upload_max_filesize / post_max_size). Uploads above the PHP limits are dropped silently by PHP.
function getEffectiveUploadLimit() {
    $limit = MAX_PHOTO_SIZE;
    $u = iniBytes(ini_get('upload_max_filesize'));
    $p = iniBytes(ini_get('post_max_size'));
    if ($u > 0) $limit = min($limit, $u);
    if ($p > 0) $limit = min($limit, (int)($p * 0.8));
    return max($limit, 100 * 1024);
}

function getMaxUploadSize() {
    $size = getEffectiveUploadLimit();
    if ($size >= 1048576) {
        return round($size / 1048576, 1) . ' MB';
    } elseif ($size >= 1024) {
        return round($size / 1024, 1) . ' KB';
    }
    return $size . ' bytes';
}

// ==================== MYSQL STORAGE LAYER ====================
require_once __DIR__ . '/db.php';

// ==================== ROT47 ENCRYPTION FUNCTIONS (TEMPORARY) ====================
function rot47_encrypt($text) {
    return str_rot47($text);
}

function rot47_decrypt($text) {
    return str_rot47($text);
}

if (!function_exists('str_rot47')) {
    function str_rot47($str) {
        return strtr($str, 
            '!"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~',
            'PQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~!"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNO'
        );
    }
}
?>